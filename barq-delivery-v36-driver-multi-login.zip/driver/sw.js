const CACHE = 'barq-driver-v36-username-login-20261116';
const FILES = ['./', './index.html', './manifest.webmanifest', './icons/barq-driver-v22-brands-20261114-192.png', './icons/barq-driver-v22-brands-20261114-512.png', './icons/barq-driver-v22-brands-20261114-180.png', './branding/barq-driver-identity-v22-brands-20261114.png'];
self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(FILES)));
  self.skipWaiting();
});
self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => (k.startsWith('delivery-driver-') || k.startsWith('barq-driver-')) && k !== CACHE).map(k => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin || !url.pathname.startsWith(new URL(self.registration.scope).pathname)) return;
  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).catch(() => caches.match('./index.html')));
    return;
  }
  if (url.pathname.includes('/branding/')) { event.respondWith(fetch(request).catch(() => caches.match(request))); return; }
  if (url.pathname.includes('/icons/') || url.pathname.endsWith('manifest.webmanifest')) {
    event.respondWith(caches.match(request).then(found => found || fetch(request)));
  }
});
