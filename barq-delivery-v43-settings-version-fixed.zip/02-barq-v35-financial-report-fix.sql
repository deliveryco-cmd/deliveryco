-- BARQ V35 | HOTFIX financial report: PostgreSQL does not support MIN(uuid).
-- Safely replace ONLY V34 and V35 financial report functions.
-- Does NOT delete or change orders, branches, commissions, or payments.
-- Run in Supabase SQL Editor as a single complete script.
BEGIN;

CREATE OR REPLACE FUNCTION public.barq_admin_financial_report_v34(p_month date)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $fn$
DECLARE v_branches jsonb; v_expenses jsonb;
BEGIN
 IF auth.uid() IS NULL OR NOT EXISTS (
  SELECT 1 FROM public.profiles p WHERE p.id=auth.uid() AND p.role='admin'
 ) THEN RAISE EXCEPTION 'هذا التقرير خاص بالمدير العام' USING ERRCODE='42501'; END IF;
 IF p_month IS NULL OR EXTRACT(DAY FROM p_month)<>1 OR
    p_month < DATE '2020-01-01' OR
    p_month > date_trunc('month',(now() AT TIME ZONE 'Asia/Baghdad'))::date THEN
   RAISE EXCEPTION 'شهر التقرير غير صحيح' USING ERRCODE='22023'; END IF;

 WITH branch_catalog AS (
  SELECT b.id,b.code,b.name,b.governorate FROM public.barq_branches b
  UNION ALL SELECT NULL::uuid,'HQ'::text,'المركز / بدون فرع'::text,'غير محددة'::text
 ), delivered AS (
  SELECT
    COALESCE(o.destination_branch_id,
      (SELECT MIN(b.id::text)::uuid FROM public.barq_branches b
       WHERE b.governorate=o.delivery_governorate
       HAVING count(*)=1)) AS branch_id,
    o.delivery_fee_iqd, o.driver_earning_iqd, o.collection_method,
    (lm.delivered_at IS NOT NULL) AS has_exact_delivery_time
  FROM public.orders o
  LEFT JOIN public.barq_last_mile_v28 lm ON lm.order_id=o.id
  WHERE o.status='delivered'
    AND date_trunc('month',(coalesce(lm.delivered_at,o.updated_at) AT TIME ZONE 'Asia/Baghdad'))::date=p_month
 ), delivery_sums AS (
  SELECT branch_id,
    count(*)::bigint AS delivered_count,
    count(*) FILTER(WHERE (
      collection_method IN ('full_cod','delivery_fee_only')
      AND delivery_fee_iqd IS NOT NULL AND driver_earning_iqd IS NOT NULL
      AND delivery_fee_iqd >= driver_earning_iqd AND driver_earning_iqd>=0
    ) IS NOT TRUE)::bigint AS incomplete_count,
    count(*) FILTER(WHERE NOT has_exact_delivery_time)::bigint AS approximate_date_count,
    COALESCE(sum(delivery_fee_iqd) FILTER (WHERE
      collection_method IN ('full_cod','delivery_fee_only')
      AND delivery_fee_iqd IS NOT NULL AND driver_earning_iqd IS NOT NULL
      AND delivery_fee_iqd >= driver_earning_iqd AND driver_earning_iqd>=0),0)::bigint AS fee_revenue,
    COALESCE(sum(driver_earning_iqd) FILTER (WHERE
      collection_method IN ('full_cod','delivery_fee_only')
      AND delivery_fee_iqd IS NOT NULL AND driver_earning_iqd IS NOT NULL
      AND delivery_fee_iqd >= driver_earning_iqd AND driver_earning_iqd>=0),0)::bigint AS delivery_commissions
  FROM delivered GROUP BY branch_id
 ), payroll_sums AS (
  SELECT branch_id, sum(salary_amount_iqd)::bigint AS salary_accrued
  FROM public.barq_driver_payroll_months_v33 WHERE salary_month=p_month GROUP BY branch_id
 ), payroll_paid_total AS (
  SELECT pm.branch_id,sum(pay.amount_iqd)::bigint AS paid_against_this_month
  FROM public.barq_driver_payroll_months_v33 pm
  JOIN public.barq_driver_salary_payments_v33 pay ON pay.payroll_id=pm.id
  WHERE pm.salary_month=p_month GROUP BY pm.branch_id
 ), salary_cash AS (
  SELECT pm.branch_id, sum(pay.amount_iqd)::bigint AS salary_paid_cash
  FROM public.barq_driver_salary_payments_v33 pay
  JOIN public.barq_driver_payroll_months_v33 pm ON pm.id=pay.payroll_id
  WHERE date_trunc('month',(pay.paid_at AT TIME ZONE 'Asia/Baghdad'))::date=p_month
  GROUP BY pm.branch_id
 ), expenses_sums AS (
  SELECT branch_id,sum(amount_iqd)::bigint AS operating_cost
  FROM public.barq_finance_expenses_v34
  WHERE expense_date>=p_month AND expense_date<(p_month+interval '1 month')::date
    AND voided_at IS NULL
  GROUP BY branch_id
 ), cash_movements AS (
  SELECT COALESCE(o.destination_branch_id,
     (SELECT MIN(b.id::text)::uuid FROM public.barq_branches b
      WHERE b.governorate=o.delivery_governorate HAVING count(*)=1)) AS branch_id,
     COALESCE(sum(s.amount_iqd) FILTER(WHERE s.movement_type='driver_remittance'),0)::bigint AS driver_collections,
     COALESCE(sum(s.amount_iqd) FILTER(WHERE s.movement_type='merchant_payout'),0)::bigint AS merchant_payments
  FROM public.delivery_settlements s JOIN public.orders o ON o.id=s.order_id
  WHERE date_trunc('month',(s.created_at AT TIME ZONE 'Asia/Baghdad'))::date=p_month
  GROUP BY 1
 )
 SELECT coalesce(jsonb_agg(jsonb_build_object(
     'branch_id',bc.id,'code',bc.code,'name',bc.name,'governorate',bc.governorate,
     'delivered_count',coalesce(ds.delivered_count,0),
     'incomplete_count',coalesce(ds.incomplete_count,0),
     'approximate_date_count',coalesce(ds.approximate_date_count,0),
     'fee_revenue',coalesce(ds.fee_revenue,0),
     'delivery_commissions',coalesce(ds.delivery_commissions,0),
     'salary_accrued',coalesce(ps.salary_accrued,0),
     'salary_paid_against_month',coalesce(ppt.paid_against_this_month,0),
     'operating_cost',coalesce(es.operating_cost,0),
     'estimated_operating_result',coalesce(ds.fee_revenue,0)-coalesce(ds.delivery_commissions,0)-coalesce(ps.salary_accrued,0)-coalesce(es.operating_cost,0),
     'cash_driver_collections',coalesce(cm.driver_collections,0),
     'cash_merchant_payments',coalesce(cm.merchant_payments,0),
     'cash_salary_payments',coalesce(sc.salary_paid_cash,0)
   ) ORDER BY bc.code),'[]'::jsonb) INTO v_branches
 FROM branch_catalog bc
 LEFT JOIN delivery_sums ds ON ds.branch_id IS NOT DISTINCT FROM bc.id
 LEFT JOIN payroll_sums ps ON ps.branch_id IS NOT DISTINCT FROM bc.id
 LEFT JOIN payroll_paid_total ppt ON ppt.branch_id IS NOT DISTINCT FROM bc.id
 LEFT JOIN salary_cash sc ON sc.branch_id IS NOT DISTINCT FROM bc.id
 LEFT JOIN expenses_sums es ON es.branch_id IS NOT DISTINCT FROM bc.id
 LEFT JOIN cash_movements cm ON cm.branch_id IS NOT DISTINCT FROM bc.id;

 SELECT coalesce(jsonb_agg(jsonb_build_object(
   'id',t.id,'branch_id',t.branch_id,'branch_name',coalesce(b.name,'المركز / بدون فرع'),
   'expense_date',t.expense_date,'category',t.category,'amount_iqd',t.amount_iqd,
   'description',t.description,'voided_at',t.voided_at,'void_reason',t.void_reason,
   'created_at',t.created_at
 ) ORDER BY t.expense_date DESC,t.created_at DESC),'[]'::jsonb)
 INTO v_expenses
 FROM (SELECT * FROM public.barq_finance_expenses_v34
       WHERE expense_date>=p_month AND expense_date<(p_month+interval '1 month')::date
       ORDER BY expense_date DESC,created_at DESC LIMIT 150) t
 LEFT JOIN public.barq_branches b ON b.id=t.branch_id;
 RETURN jsonb_build_object('month',to_char(p_month,'YYYY-MM'),
   'branches',coalesce(v_branches,'[]'::jsonb),
   'expenses',coalesce(v_expenses,'[]'::jsonb),
   'expense_list_limit',150,
   'notes','التقرير إداري تقديري: تواريخ التسليم القديمة قد تعتمد على آخر تحديث للطلب، والأرباح لا تشمل كل الالتزامات غير المسجلة');
END;
$fn$;

CREATE OR REPLACE FUNCTION public.barq_admin_financial_report_v35(p_month date)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $fn$
DECLARE v_report jsonb; v_branches jsonb;
BEGIN
 IF auth.uid() IS NULL OR NOT EXISTS
 (SELECT 1 FROM public.profiles WHERE id=auth.uid() AND role='admin')
 THEN RAISE EXCEPTION 'الإدارة العامة فقط' USING ERRCODE='42501'; END IF;
 v_report:=public.barq_admin_financial_report_v34(p_month);
 WITH old_comm AS (
  SELECT coalesce(o.destination_branch_id,
    (SELECT min(b.id::text)::uuid FROM public.barq_branches b
     WHERE b.governorate=o.delivery_governorate HAVING count(*)=1)) AS branch_id,
   sum(o.driver_earning_iqd)::bigint AS old_amount
  FROM public.orders o
  LEFT JOIN public.barq_last_mile_v28 lm ON lm.order_id=o.id
  WHERE o.status='delivered'
    AND date_trunc('month',(coalesce(lm.delivered_at,o.updated_at) AT TIME ZONE 'Asia/Baghdad'))::date=p_month
    AND o.collection_method IN ('full_cod','delivery_fee_only')
    AND o.driver_earning_iqd IS NOT NULL AND o.delivery_fee_iqd IS NOT NULL
    AND o.driver_earning_iqd BETWEEN 0 AND o.delivery_fee_iqd
    AND EXISTS(SELECT 1 FROM public.barq_commission_earnings_v35 c WHERE c.order_id=o.id)
  GROUP BY 1
 ), new_comm AS (
  SELECT c.branch_id,sum(c.amount_iqd)::bigint AS new_amount,
    count(*) FILTER (WHERE c.amount_iqd IS NULL)::int AS pending_count
  FROM public.barq_commission_earnings_v35 c
  WHERE date_trunc('month',(c.earned_at AT TIME ZONE 'Asia/Baghdad'))::date=p_month
  GROUP BY c.branch_id
 )
 SELECT coalesce(jsonb_agg(
  b || jsonb_build_object(
    'delivery_commissions',greatest(0,(b->>'delivery_commissions')::bigint-coalesce(oc.old_amount,0)+coalesce(nc.new_amount,0)),
    'commission_pending_count',coalesce(nc.pending_count,0),
    'estimated_operating_result',CASE WHEN coalesce(nc.pending_count,0)>0 THEN NULL
      ELSE (b->>'estimated_operating_result')::bigint+coalesce(oc.old_amount,0)-coalesce(nc.new_amount,0) END
  ) ORDER BY b->>'code'),'[]'::jsonb) INTO v_branches
 FROM jsonb_array_elements(v_report->'branches') b
 LEFT JOIN old_comm oc ON oc.branch_id IS NOT DISTINCT FROM nullif(b->>'branch_id','')::uuid
 LEFT JOIN new_comm nc ON nc.branch_id IS NOT DISTINCT FROM nullif(b->>'branch_id','')::uuid;
 RETURN jsonb_set(v_report,'{branches}',v_branches)
   || jsonb_build_object('v35_note','عمولات V35 من أجرة التوصيل. الحسابات ذات النسبة غير المحددة لا يظهر لها ربح نهائي.');
END;
$fn$;

COMMIT;

-- Read-only installation check (both should be TRUE).
SELECT
 position('min(b.id::text)::uuid' in lower(pg_get_functiondef(
   'public.barq_admin_financial_report_v34(date)'::regprocedure)))>0 AS v34_uuid_fix_ready,
 position('min(b.id::text)::uuid' in lower(pg_get_functiondef(
   'public.barq_admin_financial_report_v35(date)'::regprocedure)))>0 AS v35_uuid_fix_ready;
