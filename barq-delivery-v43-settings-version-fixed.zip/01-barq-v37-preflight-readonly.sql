-- BARQ V37: READ-ONLY readiness check. Does not change any records.
SELECT
  to_regclass('public.profiles') IS NOT NULL AS profiles_ready,
  to_regclass('public.barq_branches') IS NOT NULL AS branches_ready,
  to_regclass('public.barq_branch_staff') IS NOT NULL AS branch_staff_ready,
  to_regprocedure('public.barq_admin_set_branch_manager_v23(uuid,uuid,boolean)') IS NOT NULL AS assign_manager_ready,
  to_regprocedure('public.barq_admin_driver_aliases_v36()') IS NOT NULL AS v36_admin_ready;
