/* BARQ V39 - one operational branch dashboard for every Iraqi governorate.
 * Every mutation RPC verifies the authenticated user's branch + receipt scan server-side.
 */
(() => {
  'use strict';
  const E = id => document.getElementById(id);
  const safe = val => String(val ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const label = (v) => ({prepared:'مجهز في المخزن',in_transit:'بالطريق',received:'مستلم',assigned:'تم تعيين المندوب',out_for_delivery:'خرج للمندوب',delivered:'تم التسليم'})[v] || v || '—';
  const blank = '<p class="empty">لا توجد طرود بهذه المرحلة حالياً.</p>';
  let current = null;
  let loading = false;
  const code = r => safe(r.receipt_code || String(r.order_id || '').slice(0,8));
  const item = (inner) => `<article class="shipment v39-parcel">${inner}</article>`;
  const header = (r, state) => `<div class="top"><strong dir="ltr">${code(r)}</strong><span class="tag">${safe(label(state))}</span></div><p>الزبون: ${safe(r.customer_name || '—')}</p>`;
  const btn = (action,id,caption) => `<button class="primary v39-act" data-v39-action="${safe(action)}" data-v39-id="${safe(id)}" type="button">${safe(caption)}</button>`;
  const selectDest = (row) => {
    const dests = (current.destinations || []).filter(d=>d.governorate===row.delivery_governorate);
    if (!dests.length) return `<p class="notice">ماكو فرع فعال مسجّل بمحافظة ${safe(row.delivery_governorate || 'الوجهة')}. فعّل الفرع من الإدارة العامة أولاً.</p>`;
    return `<label class="v39-label">فرع الوجهة</label><select class="v39-select v39-dest">${dests.map(d=>`<option value="${safe(d.id)}">${safe(d.name)}</option>`).join('')}</select>${btn('prepare',row.order_id,'📦 مسح وتجهيز تحويل للفرع')}`;
  };
  const render = () => {
    if (!current) return;
    const pickups = current.pickups || [], outbound = current.outbound || [], incoming = current.incoming || [];
    const final = current.final_mile || [], drivers = current.drivers || [], stock = current.warehouse || [];
    E('v39PickupList').innerHTML = pickups.length ? pickups.map(r => item(header(r,r.stage==='awaiting_receipt'?'بانتظار استلام المخزن':'مندوب بالطريق')+`<p>المندوب: ${safe(r.driver_name||'—')} · البضاعة: ${safe(r.goods_type||'—')}</p>`+(r.stage==='awaiting_receipt'?btn('pickup',r.order_id,'📷 مسح واستلام الطرد في المخزن'):'<p class="muted tiny">بانتظار إثبات وصول المندوب إلى المخزن</p>'))).join('') : blank;
    E('v39OutboundList').innerHTML = outbound.length ? outbound.map(r => item(header(r,r.transfer_status || 'داخل المخزن')+`<p>الوجهة: ${safe(r.delivery_governorate||'—')} · الرف: ${safe(r.shelf||'—')}</p>`+(!r.transfer_id?(r.item_status==='stored'?selectDest(r):''):
     r.transfer_status==='prepared'?btn('dispatch',r.transfer_id,'🚚 مسح وتسليم الطرد للناقل'):`<p class="muted">${r.transfer_status==='in_transit'?'تم تسليم الشحنة للناقل، بانتظار وصولها':'تم استلام الشحنة بالفرع الآخر'}</p>`))).join('') : blank;
    E('v39IncomingList').innerHTML = incoming.length ? incoming.map(r=>item(header(r,r.transfer_status)+`<p>القادم من: ${safe(r.from_branch_name||'—')} · الناقل: ${safe(r.transport_name||'—')}</p>`+(r.transfer_status==='in_transit'?btn('receive',r.transfer_id,'📷 مسح واستلام الطرد القادم'):'<p class="muted">✅ تم استلامه في مخزنك</p>'))).join('') : blank;
    E('v39FinalList').innerHTML = final.length ? final.map(r=>{
      let next='';
      if(!r.state){
        const available = drivers.filter(d => d.is_available === true);
        next = available.length? `<label class="v39-label">اختار مندوب التوصيل من نفس الفرع</label><select class="v39-select v39-driver">${available.map(d=>`<option value="${safe(d.id)}">${safe(d.name || d.phone || d.id)}</option>`).join('')}</select>${btn('assign',r.order_id,'👤 مسح وتعيين المندوب')}` : '<p class="notice">ماكو مندوب متاح بالفرع حالياً؛ الإدارة العامة تقدر تفعّل مندوب.</p>';
      }else if(r.state==='assigned')next=`<p>المندوب: ${safe(r.driver_name||'—')}</p>${btn('handover',r.order_id,'📦 مسح وتأكيد خروج الطرد للمندوب')}`;
      else next=`<p>المندوب: ${safe(r.driver_name||'—')}</p><p class="muted">${r.state==='delivered'?'✅ تم تسليم الطرد للزبون':'بانتظار مسح المندوب لباركود الطرد عند الزبون'}</p>`;
      return item(header(r,r.state||'داخل المخزن')+`<p>الرف: ${safe(r.shelf||'—')}</p>`+next);
    }).join('') : blank;
    E('v39WarehouseList').innerHTML = stock.length?stock.map(r=>item(header(r,r.status)+`<p>البضاعة: ${safe(r.description||'طرد')} · الرف: ${safe(r.shelf||'—')} · الكمية: ${safe(r.quantity||1)}</p>`)).join(''):blank;
    E('v39BranchNote').textContent=`إدارة مخزن ${branch?.governorate||'الفرع'} — الاستلام والتجهيز والنقل وتعيين المندوب والتسليم كلها بالباركود. لا تعتبر المسح دليلاً على تسليم الطرد إلا بعد تأكيد الاستلام الفعلي.`;
  };
  const refresh = async () => {
    if (!branch || !sb || loading) return false;
    loading = true;
    E('v39Refresh').disabled=true;
    try {
      const {data,error}=await sb.rpc('barq_v39_branch_operations');
      if(error)throw error;
      if(!data || data.branch_id!==branch.id)throw new Error('بيانات الفرع لا تطابق حسابك؛ لن تُعرض معلومات الفروع الأخرى.');
      current = data;
      E('v39Operations').classList.remove('hidden');
      E('activeContent').classList.add('hidden');
      E('v38ReadonlyNote').classList.add('hidden');
      E('v39Error').innerHTML='';
      render();
      return true;
    }catch(e){
      E('v39Error').innerHTML=`<div class="notice error">تعذر تشغيل إدارة المخزن الموحّدة. تأكد من تنفيذ SQL الخاص بـV39: ${safe(e?.message||e)}</div>`;
      E('v39Operations').classList.add('hidden');
      return false;
    }finally{
      loading=false;
      E('v39Refresh').disabled=false;
    }
  };
  async function scan(title, expected){
    if (!window.BarqScannerV29?.scan)throw new Error('قارئ الباركود غير جاهز؛ أعد تحميل الصفحة وتأكد من الإنترنت.');
    return window.BarqScannerV29.scan({title,expectedCode:expected});
  }
  const action = async (button) => {
    if (!branch || !current || button.disabled) return;
    const card=button.closest('.v39-parcel');
    const a=button.dataset.v39Action,id=button.dataset.v39Id;
    const lists = {pickup:current.pickups,outbound:current.outbound,incoming:current.incoming,assign:current.final_mile,handover:current.final_mile,prepare:current.outbound,dispatch:current.outbound};
    const row=(lists[a]||[]).find(r=>String(a==='dispatch'||a==='receive'?r.transfer_id:r.order_id)===id);
    if(!row)return alert('الطرد تغيّرت حالته. اضغط تحديث وحاول مرة ثانية.');
    let rpc,params,success;
    if(a==='pickup'){
      const shelf=prompt('شنو رقم رف الطرد داخل المخزن؟ (مثل K1)');if(shelf===null)return;
      if(!shelf.trim() || shelf.trim().length>100)return alert('اكتب رفاً صحيحاً.');
      const scanned=await scan('مسح وصل الطرد عند استلامه من المندوب',row.receipt_code);if(!scanned)return;
      if(!confirm('الطرد وصل فعلياً إلى مخزنك؟'))return;
      rpc='barq_branch_receive_pickup_v29';params={p_order_id:row.order_id,p_scan:scanned,p_shelf:shelf.trim(),p_condition:'good'};
      success='تم تسجيل استلام الطرد من مندوب الفرع.';
    }else if(a==='prepare'){
      const dest=card.querySelector('.v39-dest')?.value;
      if(!dest)return alert('اختار فرع الوجهة.');
      const scanned=await scan('مسح الطرد قبل تجهيز التحويل',row.receipt_code);if(!scanned)return;
      if(!confirm('تجهيز شحنة للفرع المختار؟ الطرد يبقى داخل المخزن لحين تسليمه فعلياً للناقل.'))return;
      rpc='barq_v39_branch_prepare_transfer';params={p_order_id:row.order_id,p_to_branch_id:dest,p_scan:scanned};
      success='تم تجهيز التحويل. الطرد ما زال بالمخزن.';
    }else if(a==='dispatch'){
      const name=prompt('اسم الناقل الذي استلم الطرد فعلياً:');if(name===null)return;
      if(name.trim().length<2||name.trim().length>120)return alert('اسم الناقل لازم يكون بين حرفين و120 حرف.');
      const ref=prompt('رقم مرجع النقل (اختياري):','');if(ref===null)return;
      if(ref.length>120)return alert('رقم مرجع النقل طويل جداً.');
      const scanned=await scan('مسح الطرد عند التسليم الفعلي للناقل',row.receipt_code);if(!scanned)return;
      if(!confirm('تأكيد تسليم الطرد فعلياً للناقل؟ سيتحول إلى حالة «بالطريق».'))return;
      rpc='barq_v39_branch_dispatch_transfer';params={p_transfer_id:row.transfer_id,p_scan:scanned,p_transport_name:name.trim(),p_transport_reference:ref.trim()||null};
      success='تم تسليم الطرد للناقل وتسجيله بالطريق.';
    }else if(a==='receive'){
      const shelf=prompt('رقم الرف لاستلام الطرد القادم:');if(shelf===null)return;
      if(!shelf.trim() || shelf.trim().length>100)return alert('اكتب رفاً صحيحاً.');
      const scanned=await scan('مسح الطرد الوارد إلى مخزن الفرع',row.receipt_code);if(!scanned)return;
      if(!confirm('وصل الطرد فعلياً لمخزن فرعك؟'))return;
      rpc='barq_v39_branch_receive_transfer';params={p_transfer_id:row.transfer_id,p_scan:scanned,p_shelf:shelf.trim(),p_condition:'good'};
      success='تم استلام التحويل فعلياً وحفظه بالمخزن.';
    }else if(a==='assign'){
      const driver=card.querySelector('.v39-driver')?.value;if(!driver)return alert('اختار المندوب.');
      const scanned=await scan('مسح الطرد قبل تعيين مندوب التوصيل',row.receipt_code);if(!scanned)return;
      if(!confirm('تعيين المندوب لهذا الطلب؟ الطرد يبقى بالمخزن إلى أن يتم تسليمه له.'))return;
      rpc='barq_v39_branch_assign_final_driver';params={p_order_id:row.order_id,p_driver_id:driver,p_scan:scanned};
      success='تم تعيين المندوب. الطرد لم يخرج من المخزن بعد.';
    }else if(a==='handover'){
      const scanned=await scan('مسح الطرد عند تسليمه للمندوب النهائي',row.receipt_code);if(!scanned)return;
      if(!confirm('هل استلم المندوب الطرد فعلياً؟ بعدها تظهر الشحنة بتطبيق المندوب.'))return;
      rpc='barq_v39_branch_handover_final';params={p_order_id:row.order_id,p_scan:scanned};
      success='تم تسجيل خروج الطرد من المخزن إلى المندوب. التسليم للزبون يحتاج مسحاً منفصلاً.';
    }else return;
    button.disabled=true;
    try{
      const {error}=await sb.rpc(rpc,params);
      if(error)throw error;
      E('v39ActionMessage').innerHTML=`<div class="notice good">✅ ${safe(success)}</div>`;
      await refresh();
      if (typeof loadUnifiedDashboard === 'function') await loadUnifiedDashboard();
    }catch(e){ E('v39ActionMessage').innerHTML=`<div class="notice error">تعذر تنفيذ الإجراء: ${safe(e?.message||e)}</div>`; }
    finally{button.disabled=false}
  };
  E('v39Refresh').addEventListener('click',async()=>{await refresh();if(typeof loadUnifiedDashboard==='function')await loadUnifiedDashboard()});
  E('v39Operations').addEventListener('click',async e=>{
    const b=e.target.closest('[data-v39-action]');
    if(!b)return;
    try{await action(b)}catch(err){E('v39ActionMessage').innerHTML=`<div class="notice error">${safe(err?.message||err)}</div>`}
  });
  window.barqV39 = {refresh};
})();
