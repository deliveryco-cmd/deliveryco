-- BARQ V42 | Transfer an EXISTING driver between ACTIVE branches from admin UI.
-- Run AFTER V41. Admin-only, transactional, audit-logged. NO order/history/commission deletion.
-- An ongoing pickup, delivery, or return blocks transfer. The old branch staffing is deactivated.
BEGIN;

CREATE TABLE IF NOT EXISTS public.barq_driver_transfers_v42 (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    driver_id uuid NOT NULL REFERENCES public.drivers(id) ON DELETE RESTRICT,
    from_branch_id uuid NOT NULL REFERENCES public.barq_branches(id),
    to_branch_id uuid NOT NULL REFERENCES public.barq_branches(id),
    transferred_by uuid NOT NULL,
    transferred_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT barq_driver_transfer_different_branches_v42
      CHECK (from_branch_id <> to_branch_id)
);
CREATE INDEX IF NOT EXISTS barq_driver_transfers_v42_lookup
    ON public.barq_driver_transfers_v42 (driver_id, transferred_at DESC);
ALTER TABLE public.barq_driver_transfers_v42 ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.barq_driver_transfers_v42 FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.barq_admin_transfer_driver_v42(
    p_driver_id uuid,
    p_target_branch_code text
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $fn$
DECLARE
    v_driver public.drivers%ROWTYPE;
    v_target uuid;
    v_code text := upper(btrim(coalesce(p_target_branch_code,'')));
    v_count integer;
BEGIN
    -- Never rely on hidden buttons for security.
    IF auth.uid() IS NULL OR NOT EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid() AND p.role = 'admin'
    ) THEN
      RAISE EXCEPTION 'نقل المندوبين مسموح للمدير العام فقط' USING ERRCODE='42501';
    END IF;
    IF p_driver_id IS NULL OR v_code = '' THEN
      RAISE EXCEPTION 'اختر المندوب والفرع الجديد' USING ERRCODE='22023';
    END IF;

    -- Serializes simultaneous attempts to transfer the same driver.
    SELECT * INTO v_driver FROM public.drivers d
    WHERE d.id = p_driver_id FOR UPDATE;
    IF NOT FOUND OR v_driver.is_active IS DISTINCT FROM TRUE THEN
      RAISE EXCEPTION 'المندوب غير موجود أو حسابه غير نشط' USING ERRCODE='22023';
    END IF;
    IF v_driver.branch_id IS NULL THEN
      RAISE EXCEPTION 'المندوب غير مرتبط بفرع؛ استخدم ربط مندوب بلا فرع أولاً' USING ERRCODE='22023';
    END IF;
    IF NOT EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = v_driver.user_id AND p.role = 'driver'
    ) THEN
      RAISE EXCEPTION 'حساب المستخدم ليس بحالة مندوب' USING ERRCODE='22023';
    END IF;
    IF (SELECT count(*) FROM public.drivers d WHERE d.user_id = v_driver.user_id AND d.is_active IS TRUE) <> 1 THEN
      RAISE EXCEPTION 'الحساب لديه أكثر من سجل مندوب نشط؛ راجع البيانات أولاً' USING ERRCODE='23514';
    END IF;

    SELECT count(*)::integer INTO v_count
    FROM public.barq_branches b
    WHERE upper(btrim(b.code))=v_code AND b.is_active IS TRUE;
    IF v_count <> 1 THEN
      RAISE EXCEPTION 'الفرع المطلوب غير موجود أو غير فعال' USING ERRCODE='22023';
    END IF;
    SELECT b.id INTO v_target FROM public.barq_branches b
    WHERE upper(btrim(b.code))=v_code AND b.is_active IS TRUE;
    IF v_target = v_driver.branch_id THEN
      RAISE EXCEPTION 'المندوب مرتبط مسبقاً بهذا الفرع' USING ERRCODE='22023';
    END IF;

    -- Order status is intentionally checked server-side across ALL orders,
    -- not only the last 100 rows displayed by the admin panel.
    IF EXISTS (
      SELECT 1 FROM public.orders o
      WHERE o.driver_id=v_driver.id
        AND coalesce(o.status,'') NOT IN ('delivered','cancelled','returned')
    ) OR EXISTS (
      SELECT 1 FROM public.barq_order_routes r
      JOIN public.orders o ON o.id=r.order_id
      WHERE r.driver_id=v_driver.id
        AND coalesce(o.status,'') NOT IN ('delivered','cancelled','returned')
    ) OR EXISTS (
      SELECT 1 FROM public.barq_last_mile_v28 lm
      WHERE lm.driver_id=v_driver.id
        AND lm.state IN ('assigned','out_for_delivery')
    ) OR EXISTS (
      -- A returned order without a completed return record is still in someone's custody.
      SELECT 1 FROM public.orders o
      WHERE o.status='returned' AND (
        o.driver_id=v_driver.id OR EXISTS (
          SELECT 1 FROM public.barq_order_routes r
          WHERE r.order_id=o.id AND r.driver_id=v_driver.id
        )
      ) AND NOT EXISTS (
        SELECT 1 FROM public.barq_returns ret
        WHERE ret.order_id=o.id AND ret.status='returned_to_merchant'
      )
    ) OR EXISTS (
      SELECT 1 FROM public.barq_returns ret
      WHERE ret.driver_id=v_driver.id
        AND coalesce(ret.status,'') NOT IN ('returned_to_merchant')
    ) THEN
      RAISE EXCEPTION 'تعذر النقل: توجد طلبات أو طرود أو رواجع غير مكتملة بعهدة المندوب. أغلقها أو أعد تعيينها أولاً.'
        USING ERRCODE='23514';
    END IF;

    -- A driver must not retain an active other-branch manager/staff role.
    IF EXISTS (
      SELECT 1 FROM public.barq_branch_staff s
      WHERE s.user_id=v_driver.user_id AND s.is_active IS TRUE
        AND s.branch_role <> 'driver'
    ) THEN
      RAISE EXCEPTION 'لدى الحساب عضوية أخرى فعالة؛ راجع الصلاحيات قبل النقل' USING ERRCODE='23514';
    END IF;

    -- Move the CURRENT assignment only. All past orders / earnings remain unchanged.
    UPDATE public.barq_branch_staff s
    SET is_active=false
    WHERE s.user_id=v_driver.user_id AND s.branch_role='driver' AND s.is_active IS TRUE;

    IF EXISTS (
      SELECT 1 FROM public.barq_branch_staff s
      WHERE s.user_id=v_driver.user_id AND s.branch_id=v_target AND s.branch_role='driver'
    ) THEN
      UPDATE public.barq_branch_staff s
      SET is_active=true, assigned_by=auth.uid(), assigned_at=now()
      WHERE s.user_id=v_driver.user_id AND s.branch_id=v_target AND s.branch_role='driver';
    ELSE
      INSERT INTO public.barq_branch_staff
        (id,branch_id,user_id,branch_role,is_active,assigned_by,assigned_at)
      VALUES (pg_catalog.gen_random_uuid(),v_target,v_driver.user_id,'driver',true,auth.uid(),now());
    END IF;

    UPDATE public.drivers d SET branch_id=v_target WHERE d.id=v_driver.id;

    -- Clear the old branch's last GPS pickup coordinate; it is not a historical parcel record.
    DELETE FROM public.driver_pickup_locations p WHERE p.driver_id=v_driver.id;

    INSERT INTO public.barq_driver_transfers_v42
      (driver_id,from_branch_id,to_branch_id,transferred_by)
    VALUES (v_driver.id,v_driver.branch_id,v_target,auth.uid());

    RETURN v_target;
END;
$fn$;

-- Read-only audit feed for the same admin page. Do not grant direct table SELECT.
CREATE OR REPLACE FUNCTION public.barq_admin_driver_transfer_history_v42()
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER SET search_path = ''
AS $hist$
BEGIN
    IF auth.uid() IS NULL OR NOT EXISTS (
      SELECT 1 FROM public.profiles p WHERE p.id=auth.uid() AND p.role='admin'
    ) THEN
      RAISE EXCEPTION 'سجل النقل للمدير العام فقط' USING ERRCODE='42501';
    END IF;
    RETURN (
      SELECT coalesce(pg_catalog.jsonb_agg(
        pg_catalog.jsonb_build_object(
          'driver_name',r.driver_name,
          'from_name',r.from_name,
          'to_name',r.to_name,
          'transferred_at',r.transferred_at
        ) ORDER BY r.transferred_at DESC
      ),'[]'::jsonb)
      FROM (
        SELECT t.transferred_at,
               coalesce(nullif(p.full_name,''),'مندوب') AS driver_name,
               f.name AS from_name, b.name AS to_name
        FROM public.barq_driver_transfers_v42 t
        JOIN public.drivers d ON d.id=t.driver_id
        LEFT JOIN public.profiles p ON p.id=d.user_id
        JOIN public.barq_branches f ON f.id=t.from_branch_id
        JOIN public.barq_branches b ON b.id=t.to_branch_id
        ORDER BY t.transferred_at DESC LIMIT 100
      ) r
    );
END;
$hist$;

REVOKE ALL ON FUNCTION public.barq_admin_driver_transfer_history_v42() FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.barq_admin_driver_transfer_history_v42() TO authenticated;

REVOKE ALL ON FUNCTION public.barq_admin_transfer_driver_v42(uuid,text) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.barq_admin_transfer_driver_v42(uuid,text) TO authenticated;
COMMIT;

-- A true result checks installation only, not an actual transfer.
SELECT
  to_regprocedure('public.barq_admin_transfer_driver_v42(uuid,text)') IS NOT NULL AS transfer_ready,
  to_regclass('public.barq_driver_transfers_v42') IS NOT NULL AS history_ready,
  to_regprocedure('public.barq_admin_driver_transfer_history_v42()') IS NOT NULL AS history_feed_ready,
  EXISTS (SELECT 1 FROM public.barq_branches WHERE code='KRB' AND is_active IS TRUE) AS karbala_active;
