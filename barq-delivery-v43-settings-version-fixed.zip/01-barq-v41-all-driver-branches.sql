-- BARQ V41 | Enroll drivers in ANY ACTIVE branch by code (BAS, BGD, KRB, future branches).
-- Run AFTER the existing V40/V39 schema, before deploying V41.
-- No existing orders, accounts, salaries, commissions or branch data are deleted.
-- For existing unassigned drivers this link is idempotent; does not move drivers between branches.
BEGIN;

CREATE OR REPLACE FUNCTION public.barq_admin_assign_new_driver_branch_v41(
    p_user_id uuid,
    p_branch_code text
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $fn$
DECLARE
    v_branch_id uuid;
    v_code text;
    v_branch_count integer;
    v_driver_count integer;
    v_updated integer;
BEGIN
    IF auth.uid() IS NULL OR NOT EXISTS (
        SELECT 1 FROM public.profiles p
        WHERE p.id = auth.uid() AND p.role = 'admin'
    ) THEN
        RAISE EXCEPTION 'يسمح للمدير العام فقط بتحديد فرع المندوب'
          USING ERRCODE = '42501';
    END IF;

    v_code := upper(btrim(coalesce(p_branch_code, '')));
    IF p_user_id IS NULL OR v_code = '' THEN
        RAISE EXCEPTION 'معرف المندوب ورمز الفرع مطلوبان'
          USING ERRCODE = '22023';
    END IF;

    SELECT count(*)::integer INTO v_branch_count
    FROM public.barq_branches b
    WHERE upper(btrim(b.code)) = v_code AND b.is_active IS TRUE;
    IF v_branch_count <> 1 THEN
        RAISE EXCEPTION 'الفرع غير موجود أو موقوف أو له رمز مكرر: %', v_code
          USING ERRCODE = '23514';
    END IF;

    SELECT b.id INTO STRICT v_branch_id
    FROM public.barq_branches b
    WHERE upper(btrim(b.code)) = v_code AND b.is_active IS TRUE;

    IF NOT EXISTS (
        SELECT 1 FROM public.profiles p
        WHERE p.id = p_user_id AND p.role = 'driver'
    ) THEN
        RAISE EXCEPTION 'المستخدم المطلوب ليس مندوباً مسجلاً'
          USING ERRCODE = '23514';
    END IF;

    SELECT count(*)::integer INTO v_driver_count
    FROM public.drivers d
    WHERE d.user_id = p_user_id AND d.is_active IS TRUE;
    IF v_driver_count <> 1 THEN
        RAISE EXCEPTION 'يجب وجود سجل مندوب نشط واحد لهذا الحساب'
          USING ERRCODE = '23514';
    END IF;

    IF EXISTS (
        SELECT 1 FROM public.drivers d
        WHERE d.user_id = p_user_id AND d.is_active IS TRUE
          AND d.branch_id IS NOT NULL AND d.branch_id <> v_branch_id
    ) OR EXISTS (
        SELECT 1 FROM public.barq_branch_staff s
        WHERE s.user_id = p_user_id AND s.is_active IS TRUE
          AND s.branch_id <> v_branch_id
    ) THEN
        RAISE EXCEPTION 'المندوب مرتبط بالفعل بفرع آخر؛ لا يمكن نقله بهذه العملية'
          USING ERRCODE = '23514';
    END IF;

    UPDATE public.drivers d
    SET branch_id = v_branch_id
    WHERE d.user_id = p_user_id AND d.is_active IS TRUE
      AND (d.branch_id IS NULL OR d.branch_id = v_branch_id);
    GET DIAGNOSTICS v_updated = ROW_COUNT;
    IF v_updated <> 1 THEN
        RAISE EXCEPTION 'تعذّر ربط سجل المندوب بالفرع'
          USING ERRCODE = '23514';
    END IF;

    IF EXISTS (
        SELECT 1 FROM public.barq_branch_staff s
        WHERE s.user_id = p_user_id AND s.branch_id = v_branch_id
          AND s.branch_role = 'driver'
    ) THEN
        UPDATE public.barq_branch_staff s
        SET is_active = true
        WHERE s.user_id = p_user_id AND s.branch_id = v_branch_id
          AND s.branch_role = 'driver';
    ELSE
        INSERT INTO public.barq_branch_staff
          (id, branch_id, user_id, branch_role, is_active, assigned_by, assigned_at)
        VALUES
          (pg_catalog.gen_random_uuid(),v_branch_id,p_user_id,'driver',true,auth.uid(),now());
    END IF;

    RETURN v_branch_id;
END;
$fn$;

REVOKE ALL ON FUNCTION public.barq_admin_assign_new_driver_branch_v41(uuid,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.barq_admin_assign_new_driver_branch_v41(uuid,text) TO authenticated;

COMMIT;

-- Verify that the function exists and Karbala is listed as active (if currently enabled).
SELECT
  to_regprocedure('public.barq_admin_assign_new_driver_branch_v41(uuid,text)') IS NOT NULL AS driver_link_ready,
  EXISTS (SELECT 1 FROM public.barq_branches WHERE code='KRB' AND is_active IS TRUE) AS karbala_active;
