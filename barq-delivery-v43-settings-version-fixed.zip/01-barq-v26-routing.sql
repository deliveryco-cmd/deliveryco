-- BARQ V26 | 2026-11-15 | Merchant governorate-aware routing and Baghdad origin warehouse
-- Run in Supabase SQL Editor as project owner BEFORE deploying V26.
-- Additive migration: does not delete or rewrite existing orders, branch transfers or routes.
-- IMPORTANT: the existing interbranch transfer RPCs may only support BAS -> BGD;
-- this migration does NOT implement automatic BGD -> BAS dispatch.

-- 1) Guard against bypassing the application with a direct route across provinces.
CREATE OR REPLACE FUNCTION public.barq_v26_guard_direct_route()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_origin text;
  v_destination text;
BEGIN
  IF NEW.route_type = 'direct' THEN
    SELECT COALESCE(origin_branch.governorate, m.governorate), o.delivery_governorate
      INTO v_origin, v_destination
    FROM public.orders AS o
    JOIN public.merchants AS m ON m.id = o.merchant_id
    LEFT JOIN public.barq_branches AS origin_branch
      ON origin_branch.id = COALESCE(o.origin_branch_id, m.branch_id)
    WHERE o.id = NEW.order_id;

    v_origin := replace(btrim(coalesce(v_origin, '')), 'البصره', 'البصرة');
    v_destination := replace(btrim(coalesce(v_destination, '')), 'البصره', 'البصرة');
    IF v_origin = '' OR v_destination = '' OR v_origin <> v_destination THEN
      RAISE EXCEPTION 'لا يمكن اختيار التوصيل المباشر: محافظة انطلاق الطلب تختلف عن محافظة الزبون أو غير محددة'
        USING ERRCODE = '23514';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS barq_v26_guard_direct_route_trigger ON public.barq_order_routes;
CREATE TRIGGER barq_v26_guard_direct_route_trigger
BEFORE INSERT OR UPDATE OF route_type, order_id
ON public.barq_order_routes
FOR EACH ROW EXECUTE FUNCTION public.barq_v26_guard_direct_route();

-- 2) Server-computed routing context; only the logged-in, active driver sees their orders.
CREATE OR REPLACE FUNCTION public.barq_driver_route_context_v26()
RETURNS TABLE (
  order_id uuid,
  origin_governorate text,
  destination_governorate text,
  origin_branch_id uuid,
  origin_branch_name text,
  can_direct boolean,
  routing_issue text
)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
DECLARE
  v_driver uuid;
BEGIN
  SELECT d.id INTO v_driver
  FROM public.drivers d
  JOIN public.profiles p ON p.id = d.user_id
  WHERE d.user_id = auth.uid()
    AND d.is_active IS TRUE
    AND p.role = 'driver';
  IF v_driver IS NULL THEN
    RAISE EXCEPTION 'ممنوع: الحساب ليس مندوباً فعالاً' USING ERRCODE = '42501';
  END IF;

  RETURN QUERY
  SELECT
    o.id,
    coalesce(b.governorate, m.governorate),
    o.delivery_governorate,
    b.id,
    b.name,
    (b.id IS NOT NULL AND b.is_active IS TRUE
      AND replace(btrim(coalesce(b.governorate,'')),'البصره','البصرة')
       = replace(btrim(coalesce(o.delivery_governorate,'')),'البصره','البصرة')),
    CASE
      WHEN b.id IS NULL THEN 'محل الطلب غير مربوط بفرع انطلاق معروف'
      WHEN b.is_active IS DISTINCT FROM TRUE THEN 'فرع الانطلاق غير فعال'
      WHEN nullif(btrim(coalesce(o.delivery_governorate,'')), '') IS NULL THEN 'محافظة الزبون غير محددة'
      WHEN d.branch_id IS DISTINCT FROM b.id THEN 'المندوب ليس من فرع انطلاق الطلب'
      ELSE NULL
    END
  FROM public.orders o
  JOIN public.merchants m ON m.id = o.merchant_id
  JOIN public.drivers d ON d.id = o.driver_id
  LEFT JOIN public.barq_branches b ON b.id = COALESCE(o.origin_branch_id, m.branch_id)
  WHERE o.driver_id = v_driver
    AND o.status IN ('assigned','picked_up','on_the_way');
END;
$$;

-- 3) Route selection: keep legacy same-province direct delivery logic;
--    support warehouse in origin province even when destination is Basra.
CREATE OR REPLACE FUNCTION public.barq_driver_select_route_v26(
  p_order_id uuid,
  p_route_type text
)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
DECLARE
  v_driver uuid;
  v_order public.orders%ROWTYPE;
  v_origin_branch uuid;
  v_origin text;
  v_destination text;
  v_origin_active boolean;
  v_driver_branch uuid;
  v_direct boolean;
BEGIN
  IF p_route_type NOT IN ('direct','warehouse') THEN
    RAISE EXCEPTION 'مسار الطلب غير معروف' USING ERRCODE = '22023';
  END IF;
  SELECT d.id, d.branch_id INTO v_driver, v_driver_branch
  FROM public.drivers d
  JOIN public.profiles p ON p.id = d.user_id
  WHERE d.user_id = auth.uid() AND d.is_active IS TRUE AND p.role = 'driver';
  IF v_driver IS NULL THEN
    RAISE EXCEPTION 'ممنوع: الحساب ليس مندوباً فعالاً' USING ERRCODE = '42501';
  END IF;

  SELECT o.* INTO v_order FROM public.orders o
  WHERE o.id = p_order_id AND o.driver_id = v_driver FOR UPDATE;
  IF NOT FOUND OR v_order.status <> 'picked_up' THEN
    RAISE EXCEPTION 'الطلب غير مكلّف إليك أو ليس بمرحلة الاستلام' USING ERRCODE = '42501';
  END IF;
  IF EXISTS (SELECT 1 FROM public.barq_order_routes r WHERE r.order_id = p_order_id) THEN
    RAISE EXCEPTION 'مسار هذا الطلب محدد مسبقاً؛ راجع الإدارة' USING ERRCODE = '23505';
  END IF;

  SELECT b.id, b.governorate, b.is_active
    INTO v_origin_branch, v_origin, v_origin_active
  FROM public.merchants m
  LEFT JOIN public.barq_branches b ON b.id = coalesce(v_order.origin_branch_id, m.branch_id)
  WHERE m.id = v_order.merchant_id;

  v_origin := replace(btrim(coalesce(v_origin, '')), 'البصره','البصرة');
  v_destination := replace(btrim(coalesce(v_order.delivery_governorate,'')),'البصره','البصرة');
  IF v_origin_branch IS NULL OR v_origin_active IS DISTINCT FROM TRUE
     OR v_destination = '' OR v_origin = '' OR v_driver_branch IS DISTINCT FROM v_origin_branch THEN
    RAISE EXCEPTION 'راجع الإدارة: محافظة أو فرع الانطلاق أو تعيين المندوب غير صحيح' USING ERRCODE = '23514';
  END IF;
  v_direct := (v_origin = v_destination);
  IF (p_route_type = 'direct') IS DISTINCT FROM v_direct THEN
    RAISE EXCEPTION 'لا يسمح بهذا المسار: قارن محافظة المحل ومحافظة الزبون' USING ERRCODE = '23514';
  END IF;

  IF v_direct THEN
    -- This preserves the legacy status advancement and collection semantics.
    PERFORM public.barq_driver_select_route(p_order_id, 'direct');
  ELSE
    -- Old RPC assumed every Basra destination was local; insert origin-warehouse route.
    INSERT INTO public.barq_order_routes
       (order_id, merchant_id, driver_id, route_type, stage, created_at, updated_at)
    VALUES (p_order_id, v_order.merchant_id, v_driver, 'warehouse', 'to_warehouse', now(), now());
  END IF;
END;
$$;

-- 4) Driver arrival at the origin warehouse, independently from destination governorate.
CREATE OR REPLACE FUNCTION public.barq_driver_arrive_warehouse_v26(p_order_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
DECLARE
  v_driver uuid;
  v_driver_branch uuid;
  v_order_branch uuid;
BEGIN
  SELECT d.id, d.branch_id INTO v_driver,v_driver_branch
  FROM public.drivers d JOIN public.profiles p ON p.id = d.user_id
  WHERE d.user_id = auth.uid() AND d.is_active IS TRUE AND p.role = 'driver';
  IF v_driver IS NULL THEN RAISE EXCEPTION 'ممنوع: حساب المندوب غير فعال' USING ERRCODE='42501'; END IF;
  SELECT coalesce(o.origin_branch_id,m.branch_id) INTO v_order_branch
  FROM public.orders o JOIN public.merchants m ON m.id = o.merchant_id
  WHERE o.id = p_order_id AND o.driver_id = v_driver AND o.status = 'picked_up';
  IF v_order_branch IS NULL OR v_order_branch IS DISTINCT FROM v_driver_branch THEN
    RAISE EXCEPTION 'الطلب لا يتبع فرع المندوب' USING ERRCODE='23514';
  END IF;
  UPDATE public.barq_order_routes r
  SET stage = 'awaiting_receipt', updated_at = now()
  WHERE r.order_id = p_order_id
    AND r.driver_id = v_driver
    AND r.route_type = 'warehouse'
    AND r.stage = 'to_warehouse';
  IF NOT FOUND THEN RAISE EXCEPTION 'لا يوجد مسار مخزن نشط لهذا الطلب' USING ERRCODE='23514'; END IF;
END;
$$;

-- 5) List local incoming courier handoffs, scoped to this active branch manager only.
CREATE OR REPLACE FUNCTION public.barq_branch_pickups_v26()
RETURNS TABLE (
  order_id uuid,
  receipt_code text,
  customer_name text,
  goods_type text,
  driver_name text,
  stage text
)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
DECLARE v_branch_id uuid;
BEGIN
  SELECT s.branch_id INTO v_branch_id
  FROM public.barq_branch_staff s
  JOIN public.barq_branches b ON b.id=s.branch_id
  JOIN public.profiles p ON p.id=s.user_id
  WHERE s.user_id=auth.uid() AND s.is_active IS TRUE AND b.is_active IS TRUE
    AND p.role IN ('branch_manage','branch_manager')
    AND s.branch_role IN ('branch_manage','branch_manager')
  LIMIT 1;
  IF v_branch_id IS NULL THEN
    RAISE EXCEPTION 'غير مصرح: حساب مدير الفرع غير فعال' USING ERRCODE='42501';
  END IF;
  IF (SELECT count(*) FROM public.barq_branch_staff s
      JOIN public.barq_branches b ON b.id=s.branch_id
      WHERE s.user_id=auth.uid() AND s.is_active IS TRUE AND b.is_active IS TRUE
        AND s.branch_role IN ('branch_manage','branch_manager')) <> 1 THEN
    RAISE EXCEPTION 'تعيين مدير الفرع ملتبس؛ راجع الإدارة' USING ERRCODE='23514';
  END IF;
  RETURN QUERY
  SELECT o.id,o.receipt_code,o.customer_name,o.goods_type,p.full_name,r.stage
  FROM public.barq_order_routes r
  JOIN public.orders o ON o.id=r.order_id
  JOIN public.merchants m ON m.id=o.merchant_id
  LEFT JOIN public.drivers d ON d.id=r.driver_id
  LEFT JOIN public.profiles p ON p.id=d.user_id
  WHERE coalesce(o.origin_branch_id,m.branch_id)=v_branch_id
    AND r.route_type='warehouse'
    AND r.stage IN ('to_warehouse','awaiting_receipt')
    AND r.warehouse_item_id IS NULL
  ORDER BY r.created_at DESC LIMIT 200;
END;
$$;

-- 6) Warehouse manager confirms PHYSICAL receipt, creates stock record, no delivery/cash status changes.
CREATE OR REPLACE FUNCTION public.barq_branch_receive_pickup_v26(
  p_order_id uuid,
  p_shelf text,
  p_condition text DEFAULT 'good'
)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
DECLARE
  v_branch_id uuid;
  v_origin_branch uuid;
  v_merchant_id uuid;
  v_goods text;
  v_item_id uuid;
BEGIN
  SELECT s.branch_id INTO v_branch_id
  FROM public.barq_branch_staff s
  JOIN public.barq_branches b ON b.id=s.branch_id
  JOIN public.profiles p ON p.id=s.user_id
  WHERE s.user_id=auth.uid() AND s.is_active IS TRUE AND b.is_active IS TRUE
    AND p.role IN ('branch_manage','branch_manager')
    AND s.branch_role IN ('branch_manage','branch_manager')
  LIMIT 1;
  IF v_branch_id IS NULL THEN
    RAISE EXCEPTION 'ممنوع: مدير الفرع غير فعال' USING ERRCODE='42501';
  END IF;
  IF (SELECT count(*) FROM public.barq_branch_staff s
      JOIN public.barq_branches b ON b.id=s.branch_id
      WHERE s.user_id=auth.uid() AND s.is_active IS TRUE AND b.is_active IS TRUE
        AND s.branch_role IN ('branch_manage','branch_manager')) <> 1 THEN
    RAISE EXCEPTION 'تعيين مدير الفرع غير واضح' USING ERRCODE='23514';
  END IF;
  IF nullif(btrim(coalesce(p_shelf,'')),'') IS NULL OR length(p_shelf)>100 OR
     (p_condition IS NULL OR p_condition NOT IN ('good','damaged','unknown')) THEN
    RAISE EXCEPTION 'الرف أو حالة البضاعة غير صالحة' USING ERRCODE='22023';
  END IF;

  -- Lock the route, so two operators cannot receive the same parcel simultaneously.
  SELECT coalesce(o.origin_branch_id,m.branch_id),o.merchant_id,o.goods_type
    INTO v_origin_branch,v_merchant_id,v_goods
  FROM public.barq_order_routes r
  JOIN public.orders o ON o.id=r.order_id
  JOIN public.merchants m ON m.id=o.merchant_id
  WHERE r.order_id=p_order_id AND r.route_type='warehouse'
    AND r.stage='awaiting_receipt' AND r.warehouse_item_id IS NULL
  FOR UPDATE OF r;
  IF NOT FOUND OR v_origin_branch IS DISTINCT FROM v_branch_id THEN
    RAISE EXCEPTION 'هذا الطلب غير منتظر الاستلام في مخزن فرعك' USING ERRCODE='23514';
  END IF;
  IF EXISTS (SELECT 1 FROM public.barq_warehouse_items wi
             WHERE wi.order_id=p_order_id AND wi.status='stored') THEN
    RAISE EXCEPTION 'الطلب مسجل بالفعل في مخزن' USING ERRCODE='23505';
  END IF;

  INSERT INTO public.barq_warehouse_items
    (id,order_id,branch_id,merchant_id,description,quantity,shelf,condition,status,notes,received_at,received_by)
  VALUES
    (gen_random_uuid(),p_order_id,v_branch_id,v_merchant_id,
     coalesce(nullif(v_goods,''),'طرد'),1,btrim(p_shelf),p_condition,'stored',
     'استلام من مندوب فرع الانطلاق - BARQ V26',now(),auth.uid())
  RETURNING id INTO v_item_id;

  UPDATE public.barq_order_routes r
     SET stage='in_warehouse',warehouse_item_id=v_item_id,updated_at=now()
   WHERE r.order_id=p_order_id;
  RETURN v_item_id;
END;
$$;

-- 7) Do not accidentally store Baghdad-origin courier parcels in Basra through an older admin RPC.
--    A later, explicitly registered branch transfer may store the parcel at its destination warehouse.
CREATE OR REPLACE FUNCTION public.barq_v26_guard_warehouse_origin()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
DECLARE v_origin_id uuid; v_origin_code text;
BEGIN
  IF NEW.order_id IS NULL THEN RETURN NEW; END IF;
  SELECT b.id,b.code INTO v_origin_id,v_origin_code
  FROM public.orders o
  JOIN public.merchants m ON m.id=o.merchant_id
  JOIN public.barq_order_routes r ON r.order_id=o.id AND r.route_type='warehouse'
  LEFT JOIN public.barq_branches b ON b.id=coalesce(o.origin_branch_id,m.branch_id)
  WHERE o.id=NEW.order_id;

  IF v_origin_code='BGD' AND NEW.branch_id IS DISTINCT FROM v_origin_id AND NOT EXISTS (
    SELECT 1 FROM public.barq_branch_transfers t
    WHERE t.order_id=NEW.order_id AND t.to_branch_id=NEW.branch_id
      AND t.transfer_status IN ('in_transit','received')
  ) THEN
    RAISE EXCEPTION 'لا يجوز استلام طرد من محل بغداد في مخزن آخر قبل تحويل فرعي موثق'
      USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS barq_v26_guard_warehouse_origin_trigger ON public.barq_warehouse_items;
CREATE TRIGGER barq_v26_guard_warehouse_origin_trigger
BEFORE INSERT OR UPDATE OF branch_id, order_id
ON public.barq_warehouse_items
FOR EACH ROW EXECUTE FUNCTION public.barq_v26_guard_warehouse_origin();

-- Invokable only by signed-in clients; each function also verifies account and branch.
REVOKE ALL ON FUNCTION public.barq_driver_route_context_v26() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.barq_driver_select_route_v26(uuid,text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.barq_driver_arrive_warehouse_v26(uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.barq_branch_pickups_v26() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.barq_branch_receive_pickup_v26(uuid,text,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.barq_driver_route_context_v26() TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_driver_select_route_v26(uuid,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_driver_arrive_warehouse_v26(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_branch_pickups_v26() TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_branch_receive_pickup_v26(uuid,text,text) TO authenticated;

-- 8) READ-ONLY report: old incorrectly selected direct routes, if any. Review manually; don't auto-change live shipments.
SELECT o.id AS order_id, m.name AS merchant_name,
       coalesce(b.governorate,m.governorate) AS origin_governorate,
       o.delivery_governorate AS destination_governorate,
       r.route_type, r.stage
FROM public.barq_order_routes r
JOIN public.orders o ON o.id=r.order_id
JOIN public.merchants m ON m.id=o.merchant_id
LEFT JOIN public.barq_branches b ON b.id=coalesce(o.origin_branch_id,m.branch_id)
WHERE r.route_type='direct'
  AND replace(btrim(coalesce(b.governorate,m.governorate,'')),'البصره','البصرة')
   IS DISTINCT FROM replace(btrim(coalesce(o.delivery_governorate,'')),'البصره','البصرة')
ORDER BY o.created_at DESC;
