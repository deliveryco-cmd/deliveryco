/* BARQ V31: Full-frame QR/Code128 scanning fix. One receipt scanner for USB/Bluetooth keyboard scanners or mobile camera.
   Physical custody and authenticated DB validation are separate requirements. */
(()=>{'use strict';
 const normalize=x=>{const s=String(x??'').trim();return (s.match(/BRQ-[0-9a-f]{32}/i)||[])[0]?.toUpperCase()||s.toUpperCase();};
 let node=null,resolvePromise=null,scanner=null,closed=false,matched='',expected='';
 const html=`<div class="brq29-mask" style="position:fixed;inset:0;z-index:2147483646;background:#07172fd9;display:flex;align-items:center;justify-content:center;padding:12px;direction:rtl;font-family:Tahoma,Arial,sans-serif">
  <div style="width:min(100%,550px);max-height:94dvh;overflow:auto;background:white;color:#162b45;border-radius:20px;padding:18px;box-shadow:0 15px 60px #0006">
   <div style="display:flex;justify-content:space-between;align-items:center;gap:10px"><b id="brq29Title" style="font-size:17px"></b><button id="brq29Close" type="button" style="background:#eff3fa;color:#152d4b;border:0;border-radius:10px;padding:10px">✕</button></div>
   <p style="font-size:12px;color:#61748b;line-height:1.9">امسح باركود الطرد بقارئ USB/Bluetooth أو بكاميرا الهاتف. خلّي رمز QR كاملاً داخل الصورة مع زواياه الأربع، وبعد المطابقة اضغط تأكيد العملية.</p>
   <label style="display:block;font-weight:bold;font-size:13px">حقل قارئ الباركود <input id="brq29Input" type="text" autocomplete="off" spellcheck="false" dir="ltr" placeholder="وجّه قارئ الباركود إلى الوصل..." style="display:block;width:100%;box-sizing:border-box;margin:8px 0 10px;padding:14px;border:2px solid #c7d6e6;border-radius:13px;font-size:15px;color:#102a48"/></label>
   <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0"><button id="brq29Camera" type="button" style="background:#f9891e;color:white;border:0;border-radius:10px;padding:10px 14px">📷 كاميرا الهاتف</button><button id="brq29Stop" type="button" style="background:#e9eff6;color:#153454;border:0;border-radius:10px;padding:10px">إيقاف الكاميرا</button></div>
   <div id="brq29Reader" style="width:100%;overflow:hidden;border-radius:12px"></div>
   <label style="display:block;font-weight:600;font-size:12px;margin:10px 0">أو اختار صورة الباركود <input id="brq29Photo" type="file" accept="image/*" style="display:block;width:100%;margin-top:6px"/></label>
   <div id="brq29Status" role="status" style="border-radius:9px;background:#f1f7fd;color:#2c5579;padding:10px;font-size:12px;line-height:1.8;margin:8px 0">بانتظار قراءة باركود الطرد...</div>
   <button id="brq29Confirm" type="button" disabled style="width:100%;border:0;border-radius:11px;padding:15px;background:#ee8c25;color:#fff;font-weight:bold;opacity:.5">✅ متابعة العملية بعد مطابقة الرمز</button>
   <small style="display:block;color:#738398;line-height:1.7;margin-top:9px">المسح يؤكد مطابقة الوصل فقط؛ لازم تتأكد من تسليم/استلام الطرد فعلياً. إدخال نص يدوياً لا يُثبت استخدام قارئ مادي.</small>
  </div></div>`;
 const el=id=>node?.querySelector('#'+id);
 function status(t,good=false){const x=el('brq29Status');if(!x)return;x.textContent=t;x.style.color=good?'#0b7652':'#a43b37';}
 async function stop(){if(scanner){try{await scanner.stop()}catch(_){}try{await scanner.clear()}catch(_){}scanner=null;}if(el('brq29Reader'))el('brq29Reader').innerHTML='';}
 async function finish(result){if(closed)return;closed=true;await stop();node?.remove();node=null;const fn=resolvePromise;resolvePromise=null;fn?.(result);}
 function got(raw){if(!node||closed)return;const scan=normalize(raw);if(!scan){status('لم يتم قراءة رمز صالح');return;}
  if(scan!==expected){matched='';el('brq29Confirm').disabled=true;el('brq29Confirm').style.opacity='.5';status('❌ هذا الباركود يخص طرداً آخر. افحص الوصل المطبوع.');return;}
  matched=scan;el('brq29Input').value=String(raw);el('brq29Confirm').disabled=false;el('brq29Confirm').style.opacity='1';status('✅ الرمز مطابق. تأكد من الطرد ثم اضغط متابعة.',true);stop().catch(()=>{});
 }
 async function camera(){if(closed)return;try{if(typeof Html5Qrcode==='undefined')throw Error('مكتبة قراءة الباركود غير محمّلة. جرّب جهاز القارئ أو الصورة.');
  await stop();
  // V31: Do not crop a rectangular 220x160 scan window around a square QR.
  // Full-frame decoding handles QR and wider Code128 labels on phones more reliably.
  const formats = typeof Html5QrcodeSupportedFormats !== 'undefined'
    ? [Html5QrcodeSupportedFormats.QR_CODE, Html5QrcodeSupportedFormats.CODE_128]
    : undefined;
  scanner = new Html5Qrcode('brq29Reader', formats ? {formatsToSupport: formats, verbose:false} : undefined);
  await scanner.start({facingMode:'environment'},{fps:12},raw=>got(raw),()=>{});
  status('الكاميرا شغالة. خلّي QR كامل داخل المعاينة مع الزوايا الأربع وابتعد قليلاً عن الشاشة حتى يوضح.',true);
 }catch(err){status('تعذر تشغيل الكاميرا: '+(err.message||err));await stop();}}
 function scan({title='مسح باركود الطرد',expectedCode}={}){
  if(node) return Promise.reject(Error('يوجد مسح آخر قيد التنفيذ'));
  expected=normalize(expectedCode);if(!expected)return Promise.reject(Error('باركود هذا الطلب غير محدد'));
  closed=false;matched='';node=document.createElement('div');node.innerHTML=html;const holder=node.firstElementChild;document.body.appendChild(holder);node=holder;
  el('brq29Title').textContent=title;
  el('brq29Close').addEventListener('click',()=>finish(null));
  el('brq29Stop').addEventListener('click',stop);
  el('brq29Camera').addEventListener('click',camera);
  el('brq29Input').addEventListener('input',e=>got(e.target.value));
  el('brq29Input').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();got(e.target.value);if(matched)el('brq29Confirm').click();}});
  el('brq29Confirm').addEventListener('click',()=>matched&&finish(matched));
  el('brq29Photo').addEventListener('change',async e=>{const f=e.target.files?.[0];if(!f)return;try{if(typeof Html5Qrcode==='undefined')throw Error('مكتبة القراءة غير جاهزة');await stop();scanner=new Html5Qrcode('brq29Reader');const raw=await scanner.scanFile(f,true);got(raw);}catch(err){status('تعذر قراءة الرمز من الصورة. تأكد أن رمز QR كامل وواضح داخلها. التفاصيل: '+(err.message||err));}});
  requestAnimationFrame(()=>el('brq29Input')?.focus());
  return new Promise(resolve=>resolvePromise=resolve);
 }
 window.BarqScannerV29={scan,normalize};
})();
