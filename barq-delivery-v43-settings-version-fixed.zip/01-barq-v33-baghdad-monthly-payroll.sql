-- BARQ V33 | Baghdad courier monthly payroll (Iraqi dinars).
-- Run in Supabase SQL Editor before deploying V33.
-- Adds separate payroll records; does NOT alter existing orders, courier commissions,
-- barcode scan records, branch transfers, or delivery settlements.
-- Monthly rate is versioned by effective month. Each opened payroll month takes a
-- permanent salary snapshot. Payments can never exceed the snapshot.

BEGIN;

CREATE TABLE IF NOT EXISTS public.barq_driver_salary_rates_v33 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_id uuid NOT NULL REFERENCES public.drivers(id) ON DELETE RESTRICT,
  branch_id uuid NOT NULL REFERENCES public.barq_branches(id) ON DELETE RESTRICT,
  effective_month date NOT NULL CHECK (EXTRACT(DAY FROM effective_month) = 1),
  monthly_salary_iqd bigint NOT NULL CHECK (monthly_salary_iqd BETWEEN 1 AND 1000000000),
  is_active boolean NOT NULL DEFAULT true,
  changed_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  changed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT barq_v33_unique_driver_effective UNIQUE(driver_id,effective_month)
);

CREATE TABLE IF NOT EXISTS public.barq_driver_payroll_months_v33 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_id uuid NOT NULL REFERENCES public.drivers(id) ON DELETE RESTRICT,
  branch_id uuid NOT NULL REFERENCES public.barq_branches(id) ON DELETE RESTRICT,
  salary_month date NOT NULL CHECK (EXTRACT(DAY FROM salary_month) = 1),
  salary_amount_iqd bigint NOT NULL CHECK (salary_amount_iqd BETWEEN 1 AND 1000000000),
  opened_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  opened_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT barq_v33_unique_payroll_month UNIQUE(driver_id,salary_month)
);

CREATE TABLE IF NOT EXISTS public.barq_driver_salary_payments_v33 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payroll_id uuid NOT NULL REFERENCES public.barq_driver_payroll_months_v33(id) ON DELETE RESTRICT,
  amount_iqd bigint NOT NULL CHECK (amount_iqd BETWEEN 1 AND 1000000000),
  paid_at timestamptz NOT NULL DEFAULT now(),
  recorded_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  note text NOT NULL DEFAULT '' CHECK (char_length(note) <= 500),
  request_id uuid NOT NULL UNIQUE
);

CREATE INDEX IF NOT EXISTS barq_v33_payroll_month_idx
  ON public.barq_driver_payroll_months_v33 (salary_month,branch_id);
CREATE INDEX IF NOT EXISTS barq_v33_payments_payroll_idx
  ON public.barq_driver_salary_payments_v33 (payroll_id,paid_at);

-- Only SECURITY DEFINER RPCs below may read/write the payroll tables from the app.
ALTER TABLE public.barq_driver_salary_rates_v33 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.barq_driver_payroll_months_v33 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.barq_driver_salary_payments_v33 ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.barq_driver_salary_rates_v33 FROM PUBLIC, anon, authenticated;
REVOKE ALL ON public.barq_driver_payroll_months_v33 FROM PUBLIC, anon, authenticated;
REVOKE ALL ON public.barq_driver_salary_payments_v33 FROM PUBLIC, anon, authenticated;

-- The present project has one Baghdad courier. Only auto-assign the requested
-- 500,000 IQD rate if exactly ONE active courier is assigned to BGD.
-- If more than one exists, use the V33 admin screen to choose each salary instead.
INSERT INTO public.barq_driver_salary_rates_v33
  (driver_id,branch_id,effective_month,monthly_salary_iqd,is_active)
SELECT d.id,b.id,
  date_trunc('month',timezone('Asia/Baghdad',now()))::date,
  500000,true
FROM public.drivers d
JOIN public.barq_branches b ON b.id=d.branch_id AND b.code='BGD'
WHERE d.is_active IS TRUE
  AND (
    SELECT COUNT(*) FROM public.drivers d2
    JOIN public.barq_branches b2 ON b2.id=d2.branch_id AND b2.code='BGD'
    WHERE d2.is_active IS TRUE
  )=1
ON CONFLICT (driver_id,effective_month) DO NOTHING;

CREATE OR REPLACE FUNCTION public.barq_admin_salary_dashboard_v33(p_month date)
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
DECLARE
  v_rows jsonb;
BEGIN
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.profiles p WHERE p.id=auth.uid() AND p.role='admin'
  ) THEN
    RAISE EXCEPTION 'خاص بالمدير العام فقط' USING ERRCODE='42501';
  END IF;
  IF p_month IS NULL OR EXTRACT(DAY FROM p_month) <> 1 THEN
    RAISE EXCEPTION 'تاريخ الشهر غير صحيح' USING ERRCODE='22023';
  END IF;
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'driver_id',x.driver_id,
    'driver_name',x.driver_name,
    'phone',x.phone,
    'driver_active',x.driver_active,
    'effective_month',x.effective_month,
    'monthly_salary_iqd',x.monthly_salary_iqd,
    'salary_active',COALESCE(x.salary_active,false),
    'payroll_id',x.payroll_id,
    'payroll_salary_iqd',x.payroll_salary_iqd,
    'paid_iqd',x.paid_iqd,
    'due_iqd',CASE WHEN x.payroll_id IS NULL THEN 0
      ELSE GREATEST(0,x.payroll_salary_iqd-x.paid_iqd) END
  ) ORDER BY x.driver_name,x.driver_id::text),'[]'::jsonb)
  INTO v_rows
  FROM (
    SELECT d.id AS driver_id,
      COALESCE(NULLIF(btrim(p.full_name),''),'مندوب بدون اسم') AS driver_name,
      p.phone,
      d.is_active AS driver_active,
      rate.effective_month,
      rate.monthly_salary_iqd,
      rate.is_active AS salary_active,
      pm.id AS payroll_id,
      pm.salary_amount_iqd AS payroll_salary_iqd,
      COALESCE((
        SELECT SUM(pay.amount_iqd)
        FROM public.barq_driver_salary_payments_v33 pay
        WHERE pay.payroll_id=pm.id
      ),0)::bigint AS paid_iqd
    FROM public.drivers d
    LEFT JOIN public.profiles p ON p.id=d.user_id
    LEFT JOIN public.barq_branches b ON b.id=d.branch_id
    LEFT JOIN public.barq_driver_payroll_months_v33 pm
      ON pm.driver_id=d.id AND pm.salary_month=p_month
    LEFT JOIN LATERAL (
      SELECT rr.effective_month,rr.monthly_salary_iqd,rr.is_active
      FROM public.barq_driver_salary_rates_v33 rr
      WHERE rr.driver_id=d.id AND rr.effective_month<=p_month
      ORDER BY rr.effective_month DESC LIMIT 1
    ) rate ON true
    WHERE b.code='BGD' OR (
      pm.branch_id IN (SELECT bb.id FROM public.barq_branches bb WHERE bb.code='BGD')
    )
  ) x;

  RETURN jsonb_build_object('month',to_char(p_month,'YYYY-MM'),'drivers',v_rows);
END;
$$;

CREATE OR REPLACE FUNCTION public.barq_admin_set_salary_v33(
  p_driver_id uuid,
  p_monthly_salary_iqd bigint,
  p_effective_month date,
  p_is_active boolean
)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
DECLARE
  v_branch_id uuid;
  v_current_month date := date_trunc('month',timezone('Asia/Baghdad',now()))::date;
BEGIN
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.profiles p WHERE p.id=auth.uid() AND p.role='admin'
  ) THEN
    RAISE EXCEPTION 'خاص بالمدير العام فقط' USING ERRCODE='42501';
  END IF;
  IF p_driver_id IS NULL OR p_monthly_salary_iqd IS NULL OR
     p_monthly_salary_iqd NOT BETWEEN 1 AND 1000000000 OR
     p_effective_month IS NULL OR EXTRACT(DAY FROM p_effective_month) <> 1 OR
     p_effective_month < v_current_month OR p_is_active IS NULL THEN
    RAISE EXCEPTION 'راجع الراتب والشهر (الحالي أو القادم)' USING ERRCODE='22023';
  END IF;
  SELECT d.branch_id INTO v_branch_id
  FROM public.drivers d
  JOIN public.barq_branches b ON b.id=d.branch_id AND b.code='BGD'
  WHERE d.id=p_driver_id;
  IF v_branch_id IS NULL THEN
    RAISE EXCEPTION 'المندوب غير مرتبط حالياً بفرع بغداد' USING ERRCODE='22023';
  END IF;
  IF EXISTS (
    SELECT 1 FROM public.barq_driver_payroll_months_v33 pm
    WHERE pm.driver_id=p_driver_id AND pm.salary_month>=p_effective_month
  ) THEN
    RAISE EXCEPTION 'شهر راتب مفتوح مسبقاً، اختر شهراً لاحقاً لحماية سجلات الرواتب' USING ERRCODE='23514';
  END IF;
  INSERT INTO public.barq_driver_salary_rates_v33
    (driver_id,branch_id,effective_month,monthly_salary_iqd,is_active,changed_by)
  VALUES (p_driver_id,v_branch_id,p_effective_month,p_monthly_salary_iqd,p_is_active,auth.uid())
  ON CONFLICT (driver_id,effective_month)
  DO UPDATE SET monthly_salary_iqd=EXCLUDED.monthly_salary_iqd,
    branch_id=EXCLUDED.branch_id,is_active=EXCLUDED.is_active,
    changed_by=EXCLUDED.changed_by,changed_at=now();
END;
$$;

CREATE OR REPLACE FUNCTION public.barq_admin_open_salary_month_v33(
  p_driver_id uuid,p_month date
)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
DECLARE
  v_branch_id uuid;
  v_salary bigint;
  v_active boolean;
  v_id uuid;
  v_current_month date := date_trunc('month',timezone('Asia/Baghdad',now()))::date;
BEGIN
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.profiles p WHERE p.id=auth.uid() AND p.role='admin'
  ) THEN
    RAISE EXCEPTION 'خاص بالمدير العام فقط' USING ERRCODE='42501';
  END IF;
  IF p_month IS NULL OR EXTRACT(DAY FROM p_month) <> 1 OR p_month > v_current_month THEN
    RAISE EXCEPTION 'لا يمكن فتح شهر راتب مستقبلي' USING ERRCODE='22023';
  END IF;
  SELECT d.branch_id INTO v_branch_id
  FROM public.drivers d
  JOIN public.barq_branches b ON b.id=d.branch_id AND b.code='BGD'
  WHERE d.id=p_driver_id;
  IF v_branch_id IS NULL THEN
    RAISE EXCEPTION 'المندوب غير مرتبط بفرع بغداد' USING ERRCODE='22023';
  END IF;
  SELECT r.monthly_salary_iqd,r.is_active
  INTO v_salary,v_active
  FROM public.barq_driver_salary_rates_v33 r
  WHERE r.driver_id=p_driver_id AND r.effective_month<=p_month
  ORDER BY r.effective_month DESC LIMIT 1;
  IF v_salary IS NULL OR v_active IS DISTINCT FROM true THEN
    RAISE EXCEPTION 'لا توجد اتفاقية راتب فعالة لهذا الشهر' USING ERRCODE='22023';
  END IF;
  INSERT INTO public.barq_driver_payroll_months_v33
    (driver_id,branch_id,salary_month,salary_amount_iqd,opened_by)
  VALUES (p_driver_id,v_branch_id,p_month,v_salary,auth.uid())
  ON CONFLICT (driver_id,salary_month) DO NOTHING
  RETURNING id INTO v_id;
  IF v_id IS NULL THEN
    SELECT pm.id INTO v_id FROM public.barq_driver_payroll_months_v33 pm
    WHERE pm.driver_id=p_driver_id AND pm.salary_month=p_month;
  END IF;
  RETURN v_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.barq_admin_pay_salary_v33(
  p_payroll_id uuid,
  p_amount_iqd bigint,
  p_note text,
  p_request_id uuid
)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
DECLARE
  v_salary bigint;
  v_paid bigint;
  v_payment_id uuid;
BEGIN
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.profiles p WHERE p.id=auth.uid() AND p.role='admin'
  ) THEN
    RAISE EXCEPTION 'خاص بالمدير العام فقط' USING ERRCODE='42501';
  END IF;
  IF p_payroll_id IS NULL OR p_request_id IS NULL OR p_amount_iqd IS NULL
     OR p_amount_iqd NOT BETWEEN 1 AND 1000000000
     OR char_length(coalesce(p_note,''))>500 THEN
    RAISE EXCEPTION 'بيانات صرف الراتب غير صالحة' USING ERRCODE='22023';
  END IF;

  -- Serializes concurrent payments to a monthly payroll.
  SELECT pm.salary_amount_iqd INTO v_salary
  FROM public.barq_driver_payroll_months_v33 pm
  JOIN public.barq_branches b ON b.id=pm.branch_id AND b.code='BGD'
  WHERE pm.id=p_payroll_id FOR UPDATE OF pm;
  IF v_salary IS NULL THEN
    RAISE EXCEPTION 'كشف الراتب غير موجود' USING ERRCODE='P0002';
  END IF;
  -- Repeating the same network request cannot pay twice.
  SELECT pay.id INTO v_payment_id
  FROM public.barq_driver_salary_payments_v33 pay
  WHERE pay.request_id=p_request_id AND pay.payroll_id=p_payroll_id
    AND pay.amount_iqd=p_amount_iqd;
  IF v_payment_id IS NOT NULL THEN
    RETURN v_payment_id;
  END IF;
  SELECT COALESCE(SUM(pay.amount_iqd),0)::bigint INTO v_paid
  FROM public.barq_driver_salary_payments_v33 pay
  WHERE pay.payroll_id=p_payroll_id;
  IF v_paid + p_amount_iqd > v_salary THEN
    RAISE EXCEPTION 'المبلغ يتجاوز المتبقي من راتب هذا الشهر' USING ERRCODE='22023';
  END IF;
  INSERT INTO public.barq_driver_salary_payments_v33
    (payroll_id,amount_iqd,note,recorded_by,request_id)
  VALUES (p_payroll_id,p_amount_iqd,coalesce(p_note,''),auth.uid(),p_request_id)
  RETURNING id INTO v_payment_id;
  RETURN v_payment_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.barq_admin_salary_payments_v33(p_payroll_id uuid)
RETURNS TABLE (paid_at timestamptz,amount_iqd bigint,note text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.profiles p WHERE p.id=auth.uid() AND p.role='admin'
  ) THEN
    RAISE EXCEPTION 'خاص بالمدير العام فقط' USING ERRCODE='42501';
  END IF;
  RETURN QUERY
  SELECT pay.paid_at,pay.amount_iqd,pay.note
  FROM public.barq_driver_salary_payments_v33 pay
  JOIN public.barq_driver_payroll_months_v33 pm ON pm.id=pay.payroll_id
  JOIN public.barq_branches b ON b.id=pm.branch_id AND b.code='BGD'
  WHERE pm.id=p_payroll_id ORDER BY pay.paid_at DESC;
END;
$$;

REVOKE ALL ON FUNCTION public.barq_admin_salary_dashboard_v33(date) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.barq_admin_set_salary_v33(uuid,bigint,date,boolean) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.barq_admin_open_salary_month_v33(uuid,date) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.barq_admin_pay_salary_v33(uuid,bigint,text,uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.barq_admin_salary_payments_v33(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.barq_admin_salary_dashboard_v33(date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_set_salary_v33(uuid,bigint,date,boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_open_salary_month_v33(uuid,date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_pay_salary_v33(uuid,bigint,text,uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_salary_payments_v33(uuid) TO authenticated;

COMMIT;

-- Non-mutating verification (functions exist, no salary payments created):
SELECT
  to_regclass('public.barq_driver_salary_rates_v33') IS NOT NULL AS rates_ready,
  to_regclass('public.barq_driver_payroll_months_v33') IS NOT NULL AS payroll_ready,
  to_regclass('public.barq_driver_salary_payments_v33') IS NOT NULL AS payments_ready,
  to_regprocedure('public.barq_admin_salary_dashboard_v33(date)') IS NOT NULL AS dashboard_ready,
  to_regprocedure('public.barq_admin_set_salary_v33(uuid,bigint,date,boolean)') IS NOT NULL AS set_salary_ready,
  to_regprocedure('public.barq_admin_open_salary_month_v33(uuid,date)') IS NOT NULL AS open_month_ready,
  to_regprocedure('public.barq_admin_pay_salary_v33(uuid,bigint,text,uuid)') IS NOT NULL AS pay_ready,
  to_regprocedure('public.barq_admin_salary_payments_v33(uuid)') IS NOT NULL AS history_ready;
