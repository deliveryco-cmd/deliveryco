-- BARQ V39 | Unified operational warehouse for EVERY active branch.
-- Install after V38 + V30/V28 + V35. Keep backups and test with fake parcels first.
-- Does not remove, reset, or reinterpret existing orders/receipts/settlements.
-- Same authenticated branch manager can only act on their one ACTIVE assigned branch.
-- All actual movements require the receipt barcode to match on the SERVER.
BEGIN;

CREATE OR REPLACE FUNCTION public.barq_v39_branch_id()
RETURNS uuid LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path='' AS $fn$
DECLARE c jsonb;
BEGIN
 c:=public.barq_v38_branch_context();
 IF coalesce((c->>'is_active')::boolean,false) IS DISTINCT FROM true
    OR coalesce((c->>'staff_active')::boolean,false) IS DISTINCT FROM true THEN
  RAISE EXCEPTION 'الفرع أو عضوية مدير الفرع غير فعالة' USING ERRCODE='42501';
 END IF;
 RETURN (c->>'id')::uuid;
END;
$fn$;

-- V28's courier lookup was BAS-only. It is now valid for any ACTIVE branch.
-- The existing V28 and V29 barcode-confirmed delivery routines retain their signatures.
CREATE OR REPLACE FUNCTION public.barq_v28_my_driver()
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path='' AS $fn$
 SELECT d.id FROM public.drivers d
 JOIN public.profiles p ON p.id=d.user_id AND p.role='driver'
 JOIN public.barq_branches b ON b.id=d.branch_id AND b.is_active IS TRUE
 WHERE d.user_id=auth.uid() AND d.is_active IS TRUE
 ORDER BY d.created_at DESC NULLS LAST LIMIT 1;
$fn$;

-- One snapshot used by the same branch UI for all governorates.
CREATE OR REPLACE FUNCTION public.barq_v39_branch_operations()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path='' AS $fn$
DECLARE v_branch uuid;
BEGIN
 v_branch:=public.barq_v39_branch_id();
 RETURN pg_catalog.jsonb_build_object(
 'branch_id',v_branch,
 'destinations',(
   SELECT coalesce(pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
      'id',b.id,'code',b.code,'name',b.name,'governorate',b.governorate
   ) ORDER BY b.name),'[]'::jsonb)
   FROM public.barq_branches b WHERE b.is_active IS TRUE AND b.id<>v_branch
 ),
 'pickups',(
   SELECT coalesce(pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
     'order_id',x.id,'receipt_code',x.receipt_code,'customer_name',x.customer_name,
     'driver_name',x.driver_name,'stage',x.stage,'goods_type',x.goods_type
   ) ORDER BY x.created_at DESC),'[]'::jsonb)
   FROM (
    SELECT o.id,coalesce(nullif(btrim(o.receipt_code),''),o.id::text) receipt_code,
      o.customer_name,o.goods_type,p.full_name driver_name,r.stage,r.created_at
    FROM public.barq_order_routes r
    JOIN public.orders o ON o.id=r.order_id
    JOIN public.merchants m ON m.id=o.merchant_id
    LEFT JOIN public.drivers d ON d.id=r.driver_id
    LEFT JOIN public.profiles p ON p.id=d.user_id
    WHERE coalesce(o.origin_branch_id,m.branch_id)=v_branch
      AND r.route_type='warehouse' AND r.stage IN ('to_warehouse','awaiting_receipt')
      AND r.warehouse_item_id IS NULL AND o.status='picked_up'
    ORDER BY r.created_at DESC LIMIT 100
   ) x
 ),
 'outbound',(
   SELECT coalesce(pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
      'order_id',x.order_id,'receipt_code',x.receipt_code,'customer_name',x.customer_name,
      'delivery_governorate',x.delivery_governorate,'shelf',x.shelf,'item_status',x.item_status,
      'transfer_id',x.transfer_id,'transfer_status',x.transfer_status,
      'to_branch_name',x.to_branch_name,'transport_name',x.transport_name
   ) ORDER BY x.received_at DESC),'[]'::jsonb)
   FROM (
     SELECT o.id order_id,coalesce(nullif(btrim(o.receipt_code),''),o.id::text) receipt_code,
       o.customer_name,o.delivery_governorate,w.shelf,w.status item_status,w.received_at,
       t.id transfer_id,t.transfer_status,t.transport_name,b.name to_branch_name
     FROM public.barq_warehouse_items w
     JOIN public.orders o ON o.id=w.order_id
     JOIN public.barq_order_routes r ON r.order_id=o.id AND r.route_type='warehouse'
     LEFT JOIN LATERAL (
       SELECT tx.id,tx.transfer_status,tx.transport_name,tx.to_branch_id
       FROM public.barq_branch_transfers tx
       WHERE tx.order_id=o.id AND tx.from_branch_id=v_branch
         AND tx.transfer_status <> 'cancelled'
       ORDER BY tx.created_at DESC LIMIT 1
     ) t ON TRUE
     LEFT JOIN public.barq_branches b ON b.id=t.to_branch_id
     WHERE w.branch_id=v_branch AND o.status='picked_up'
       AND (w.status='stored' OR t.id IS NOT NULL)
       AND (o.delivery_governorate IS DISTINCT FROM (SELECT gov.governorate FROM public.barq_branches gov WHERE gov.id=v_branch) OR t.id IS NOT NULL)
       AND (r.warehouse_item_id=w.id OR t.id IS NOT NULL)
       AND NOT EXISTS (SELECT 1 FROM public.barq_last_mile_v28 lm
                       WHERE lm.order_id=o.id AND lm.state IN ('out_for_delivery','delivered'))
     ORDER BY w.received_at DESC LIMIT 150
   ) x
 ),
 'incoming',(
   SELECT coalesce(pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
     'transfer_id',x.id,'order_id',x.order_id,'receipt_code',x.receipt_code,
     'customer_name',x.customer_name,'from_branch_name',x.from_branch_name,
     'transport_name',x.transport_name,'transport_reference',x.transport_reference,
     'transfer_status',x.transfer_status
   ) ORDER BY x.created_at DESC),'[]'::jsonb)
   FROM (
    SELECT t.id,t.order_id,coalesce(nullif(btrim(o.receipt_code),''),o.id::text) receipt_code,
      o.customer_name,b.name from_branch_name,t.transport_name,t.transport_reference,
      t.transfer_status,t.created_at
    FROM public.barq_branch_transfers t
    JOIN public.orders o ON o.id=t.order_id
    JOIN public.barq_branches b ON b.id=t.from_branch_id
    WHERE t.to_branch_id=v_branch AND t.transfer_status IN ('in_transit','received')
    ORDER BY t.created_at DESC LIMIT 100
   ) x
 ),
 'warehouse',(
    SELECT coalesce(pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
       'order_id',x.order_id,'receipt_code',x.receipt_code,'description',x.description,
       'shelf',x.shelf,'quantity',x.quantity,'status',x.status
     ) ORDER BY x.received_at DESC),'[]'::jsonb)
    FROM (
       SELECT w.order_id,o.receipt_code,w.description,w.shelf,w.quantity,w.status,w.received_at
       FROM public.barq_warehouse_items w
       LEFT JOIN public.orders o ON o.id=w.order_id
       WHERE w.branch_id=v_branch
       ORDER BY w.received_at DESC LIMIT 150
    ) x
 ),
 'drivers',(
   SELECT coalesce(pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
    'id',x.id,'name',x.full_name,'phone',x.phone,'is_available',x.is_available
   ) ORDER BY x.full_name),'[]'::jsonb)
   FROM (
      SELECT d.id,p.full_name,p.phone,d.is_available
      FROM public.drivers d JOIN public.profiles p ON p.id=d.user_id
      WHERE d.branch_id=v_branch AND d.is_active IS TRUE AND p.role='driver'
      ORDER BY p.full_name LIMIT 150
   ) x
 ),
 'final_mile',(
   SELECT coalesce(pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
       'order_id',x.id,'receipt_code',x.receipt_code,'customer_name',x.customer_name,
       'shelf',x.shelf,'item_status',x.item_status,'order_status',x.order_status,
       'driver_id',x.driver_id,'driver_name',x.driver_name,'state',x.state
   ) ORDER BY x.received_at DESC),'[]'::jsonb)
   FROM (
     SELECT o.id,coalesce(nullif(btrim(o.receipt_code),''),o.id::text) receipt_code,
       o.customer_name,w.shelf,w.status item_status,o.status order_status,w.received_at,
       lm.driver_id,p.full_name driver_name,lm.state
     FROM public.barq_warehouse_items w
     JOIN public.orders o ON o.id=w.order_id
     JOIN public.barq_order_routes r ON r.order_id=o.id AND r.warehouse_item_id=w.id
       AND r.route_type='warehouse'
     JOIN public.barq_branches b ON b.id=v_branch
     LEFT JOIN public.barq_last_mile_v28 lm ON lm.order_id=o.id AND lm.branch_id=v_branch
     LEFT JOIN public.drivers d ON d.id=lm.driver_id
     LEFT JOIN public.profiles p ON p.id=d.user_id
     WHERE w.branch_id=v_branch AND o.delivery_governorate=b.governorate
      AND ( (w.status='stored' AND o.status='picked_up')
            OR (w.status='released' AND lm.state IN ('out_for_delivery','delivered')) )
      AND NOT EXISTS (SELECT 1 FROM public.barq_branch_transfers t
          WHERE t.order_id=o.id AND t.transfer_status IN ('prepared','in_transit'))
     ORDER BY w.received_at DESC LIMIT 120
   ) x
 )
 );
END;
$fn$;

-- Prepare transfer between ANY two active branches, where destination matches the customer governorate.
CREATE OR REPLACE FUNCTION public.barq_v39_branch_prepare_transfer(
 p_order_id uuid,p_to_branch_id uuid,p_scan text
) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $fn$
DECLARE v_branch uuid;v_order public.orders%ROWTYPE;v_route public.barq_order_routes%ROWTYPE;
 v_item public.barq_warehouse_items%ROWTYPE;v_to_gov text;v_to_active boolean;v_origin uuid;
 v_id uuid;v_code text;
BEGIN
 v_branch:=public.barq_v39_branch_id();
 IF p_to_branch_id IS NULL OR p_to_branch_id=v_branch THEN
  RAISE EXCEPTION 'اختار فرع الوجهة المختلف عن فرع الانطلاق' USING ERRCODE='22023';
 END IF;
 SELECT b.governorate,b.is_active INTO v_to_gov,v_to_active
 FROM public.barq_branches b WHERE b.id=p_to_branch_id;
 IF NOT FOUND OR v_to_active IS DISTINCT FROM true THEN
  RAISE EXCEPTION 'فرع الوجهة غير موجود أو موقوف' USING ERRCODE='23514'; END IF;
 SELECT * INTO v_order FROM public.orders o WHERE o.id=p_order_id FOR UPDATE;
 IF NOT FOUND OR v_order.status IS DISTINCT FROM 'picked_up'
    OR v_order.delivery_governorate IS DISTINCT FROM v_to_gov
    OR (v_order.destination_branch_id IS NOT NULL AND v_order.destination_branch_id IS DISTINCT FROM p_to_branch_id) THEN
  RAISE EXCEPTION 'محافظة الزبون أو حالة الطلب لا تسمح بالتحويل لهذا الفرع' USING ERRCODE='23514';
 END IF;
 SELECT coalesce(o.origin_branch_id,m.branch_id) INTO v_origin
 FROM public.orders o JOIN public.merchants m ON m.id=o.merchant_id WHERE o.id=p_order_id;
 IF v_origin IS DISTINCT FROM v_branch THEN
  RAISE EXCEPTION 'الطرد ليس من فرع الانطلاق الخاص بك' USING ERRCODE='42501'; END IF;
 SELECT * INTO v_route FROM public.barq_order_routes WHERE order_id=p_order_id FOR UPDATE;
 IF NOT FOUND OR v_route.route_type IS DISTINCT FROM 'warehouse'
  OR v_route.stage IS DISTINCT FROM 'in_warehouse' OR v_route.warehouse_item_id IS NULL THEN
  RAISE EXCEPTION 'الطرد ليس محفوظاً بالمسار الصحيح للمخزن' USING ERRCODE='23514'; END IF;
 SELECT * INTO v_item FROM public.barq_warehouse_items
 WHERE id=v_route.warehouse_item_id FOR UPDATE;
 IF NOT FOUND OR v_item.branch_id IS DISTINCT FROM v_branch OR v_item.order_id IS DISTINCT FROM p_order_id
   OR v_item.status IS DISTINCT FROM 'stored' THEN
  RAISE EXCEPTION 'الطرد غير موجود حالياً على رف مخزنك' USING ERRCODE='23514'; END IF;
 IF EXISTS (SELECT 1 FROM public.barq_branch_transfers t
  WHERE t.order_id=p_order_id AND t.transfer_status<>'cancelled') THEN
  RAISE EXCEPTION 'يوجد تحويل فعّال أو سابق لهذا الطرد؛ لا تعيد إرساله' USING ERRCODE='23505';
 END IF;
 v_code:=public.barq_v29_verify_receipt(p_order_id,p_scan);
 INSERT INTO public.barq_branch_transfers
 (id,order_id,from_branch_id,to_branch_id,transfer_status,created_by,created_at,notes)
 VALUES(pg_catalog.gen_random_uuid(),p_order_id,v_branch,p_to_branch_id,'prepared',auth.uid(),now(),'V39 تجهيز تحويل من الفرع')
 RETURNING id INTO v_id;
 PERFORM public.barq_v29_log(p_order_id,'v39_branch_prepare_transfer',v_code,v_branch);
 RETURN v_id;
END;
$fn$;

-- Physical dispatch to the carrier; NOT yet arrived at the destination branch.
CREATE OR REPLACE FUNCTION public.barq_v39_branch_dispatch_transfer(
 p_transfer_id uuid,p_scan text,p_transport_name text,p_transport_reference text DEFAULT NULL
) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $fn$
DECLARE v_branch uuid;v_t public.barq_branch_transfers%ROWTYPE;
 v_order public.orders%ROWTYPE;v_route public.barq_order_routes%ROWTYPE;
 v_item public.barq_warehouse_items%ROWTYPE;v_name text:=btrim(coalesce(p_transport_name,''));
 v_ref text:=nullif(btrim(coalesce(p_transport_reference,'')),'');v_code text;v_gov text;
BEGIN
 v_branch:=public.barq_v39_branch_id();
 IF length(v_name) NOT BETWEEN 2 AND 120 OR length(coalesce(v_ref,''))>120 THEN
  RAISE EXCEPTION 'اسم الناقل أو مرجع النقل غير صحيح' USING ERRCODE='22023'; END IF;
 SELECT * INTO v_t FROM public.barq_branch_transfers WHERE id=p_transfer_id FOR UPDATE;
 IF NOT FOUND OR v_t.from_branch_id IS DISTINCT FROM v_branch
    OR v_t.transfer_status IS DISTINCT FROM 'prepared' THEN
  RAISE EXCEPTION 'هذا التحويل غير مجهز في فرعك أو خرج سابقاً' USING ERRCODE='23514'; END IF;
 SELECT * INTO v_order FROM public.orders WHERE id=v_t.order_id FOR UPDATE;
 SELECT b.governorate INTO v_gov FROM public.barq_branches b WHERE b.id=v_t.to_branch_id AND b.is_active IS TRUE;
 IF NOT FOUND OR v_order.status IS DISTINCT FROM 'picked_up'
    OR v_order.delivery_governorate IS DISTINCT FROM v_gov THEN
  RAISE EXCEPTION 'فرع الوجهة لم يعد فعالاً أو تغيرت محافظة الزبون' USING ERRCODE='23514'; END IF;
 SELECT * INTO v_route FROM public.barq_order_routes WHERE order_id=v_t.order_id FOR UPDATE;
 IF NOT FOUND OR v_route.route_type IS DISTINCT FROM 'warehouse'
   OR v_route.stage IS DISTINCT FROM 'in_warehouse' OR v_route.warehouse_item_id IS NULL THEN
  RAISE EXCEPTION 'مسار المخزن غير صحيح' USING ERRCODE='23514'; END IF;
 SELECT * INTO v_item FROM public.barq_warehouse_items WHERE id=v_route.warehouse_item_id FOR UPDATE;
 IF NOT FOUND OR v_item.order_id IS DISTINCT FROM v_order.id OR v_item.branch_id IS DISTINCT FROM v_branch
  OR v_item.status IS DISTINCT FROM 'stored' THEN
  RAISE EXCEPTION 'الطرد ليس محفوظاً في مخزن هذا الفرع' USING ERRCODE='23514'; END IF;
 v_code:=public.barq_v29_verify_receipt(v_order.id,p_scan);
 UPDATE public.barq_warehouse_items SET status='released',released_at=now(),released_by=auth.uid(),
   receiver_name=v_name WHERE id=v_item.id;
 UPDATE public.barq_branch_transfers SET transfer_status='in_transit',transport_name=v_name,
   transport_reference=v_ref,handed_over_by=auth.uid(),handed_over_at=now()
   WHERE id=v_t.id;
 PERFORM public.barq_v29_log(v_order.id,'v39_branch_dispatch_transfer',v_code,v_branch);
END;
$fn$;

-- Physical receiving at destination; scans expected receipt and prevents duplicate inventory.
CREATE OR REPLACE FUNCTION public.barq_v39_branch_receive_transfer(
 p_transfer_id uuid,p_scan text,p_shelf text,p_condition text DEFAULT 'good'
) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $fn$
DECLARE v_branch uuid;v_t public.barq_branch_transfers%ROWTYPE;v_order public.orders%ROWTYPE;
 v_route public.barq_order_routes%ROWTYPE;v_old public.barq_warehouse_items%ROWTYPE;
 v_branch_gov text;v_new uuid;v_code text;v_shelf text:=btrim(coalesce(p_shelf,''));
BEGIN
 v_branch:=public.barq_v39_branch_id();
 SELECT b.governorate INTO v_branch_gov FROM public.barq_branches b WHERE b.id=v_branch;
 IF length(v_shelf) NOT BETWEEN 1 AND 100 OR p_condition NOT IN ('good','damaged','unknown')
    OR p_condition IS NULL THEN RAISE EXCEPTION 'الرف أو حالة البضاعة غير صالحة' USING ERRCODE='22023'; END IF;
 SELECT * INTO v_t FROM public.barq_branch_transfers WHERE id=p_transfer_id FOR UPDATE;
 IF NOT FOUND OR v_t.to_branch_id IS DISTINCT FROM v_branch
    OR v_t.transfer_status IS DISTINCT FROM 'in_transit'
    OR v_t.received_warehouse_item_id IS NOT NULL THEN
  RAISE EXCEPTION 'الطرد ليس بالطريق إلى فرعك أو تم استلامه مسبقاً' USING ERRCODE='23514'; END IF;
 SELECT * INTO v_order FROM public.orders WHERE id=v_t.order_id FOR UPDATE;
 IF NOT FOUND OR v_order.status IS DISTINCT FROM 'picked_up'
    OR v_order.delivery_governorate IS DISTINCT FROM v_branch_gov
    OR (v_order.destination_branch_id IS NOT NULL AND v_order.destination_branch_id IS DISTINCT FROM v_branch) THEN
  RAISE EXCEPTION 'حالة الطلب أو محافظته غير متوافقة مع فرعك' USING ERRCODE='23514'; END IF;
 SELECT * INTO v_route FROM public.barq_order_routes WHERE order_id=v_order.id FOR UPDATE;
 IF NOT FOUND OR v_route.route_type IS DISTINCT FROM 'warehouse'
    OR v_route.stage IS DISTINCT FROM 'in_warehouse' OR v_route.warehouse_item_id IS NULL THEN
  RAISE EXCEPTION 'لا يوجد مسار مخزن صحيح لهذه الشحنة' USING ERRCODE='23514'; END IF;
 SELECT * INTO v_old FROM public.barq_warehouse_items WHERE id=v_route.warehouse_item_id FOR UPDATE;
 IF NOT FOUND OR v_old.order_id IS DISTINCT FROM v_order.id
   OR v_old.branch_id IS DISTINCT FROM v_t.from_branch_id OR v_old.status IS DISTINCT FROM 'released' THEN
  RAISE EXCEPTION 'الشحنة لم تخرج رسمياً من مخزن الانطلاق' USING ERRCODE='23514'; END IF;
 IF EXISTS (SELECT 1 FROM public.barq_warehouse_items w WHERE w.order_id=v_order.id AND w.branch_id=v_branch)
  OR EXISTS (SELECT 1 FROM public.barq_warehouse_items w WHERE w.order_id=v_order.id AND w.status='stored') THEN
  RAISE EXCEPTION 'الطرد مسجل مسبقاً داخل مخزن' USING ERRCODE='23505'; END IF;
 v_code:=public.barq_v29_verify_receipt(v_order.id,p_scan);
 INSERT INTO public.barq_warehouse_items
   (id,order_id,branch_id,merchant_id,description,quantity,shelf,condition,status,notes,received_at,received_by)
 VALUES(pg_catalog.gen_random_uuid(),v_order.id,v_branch,v_order.merchant_id,
   coalesce(nullif(v_order.goods_type,''),'طرد'),1,v_shelf,p_condition,'stored',
   'V39 استلام تحويل بالباركود',now(),auth.uid()) RETURNING id INTO v_new;
 UPDATE public.barq_order_routes SET warehouse_item_id=v_new,updated_at=now() WHERE order_id=v_order.id;
 UPDATE public.barq_branch_transfers SET transfer_status='received',received_at=now(),
  received_by=auth.uid(),received_warehouse_item_id=v_new WHERE id=v_t.id;
 PERFORM public.barq_v29_log(v_order.id,'v39_branch_receive_transfer',v_code,v_branch);
 RETURN v_new;
END;
$fn$;

-- Final-mile assignment works for any branch: courier must be ACTIVE, available, SAME branch.
CREATE OR REPLACE FUNCTION public.barq_v39_branch_assign_final_driver(
 p_order_id uuid,p_driver_id uuid,p_scan text
) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $fn$
DECLARE v_branch uuid;v_gov text;v_order public.orders%ROWTYPE;
 v_route public.barq_order_routes%ROWTYPE;v_item public.barq_warehouse_items%ROWTYPE;
 v_lm public.barq_last_mile_v28%ROWTYPE;v_code text;
BEGIN
 v_branch:=public.barq_v39_branch_id();
 SELECT governorate INTO v_gov FROM public.barq_branches WHERE id=v_branch;
 IF p_order_id IS NULL OR p_driver_id IS NULL THEN RAISE EXCEPTION 'حدد المندوب والطرد' USING ERRCODE='22023'; END IF;
 SELECT * INTO v_order FROM public.orders WHERE id=p_order_id FOR UPDATE;
 IF NOT FOUND OR v_order.status IS DISTINCT FROM 'picked_up'
    OR v_order.delivery_governorate IS DISTINCT FROM v_gov THEN
  RAISE EXCEPTION 'حالة الطلب أو وجهته لا تسمح بتوزيعه من هذا الفرع' USING ERRCODE='23514'; END IF;
 IF EXISTS (SELECT 1 FROM public.barq_branch_transfers t WHERE t.order_id=p_order_id
        AND t.transfer_status IN ('prepared','in_transit')) THEN
  RAISE EXCEPTION 'الطلب ما زال في مرحلة النقل بين الفروع' USING ERRCODE='23514'; END IF;
 SELECT * INTO v_route FROM public.barq_order_routes WHERE order_id=p_order_id FOR UPDATE;
 IF NOT FOUND OR v_route.route_type IS DISTINCT FROM 'warehouse'
   OR v_route.warehouse_item_id IS NULL THEN
  RAISE EXCEPTION 'الطلب غير مسجل على رف مخزن الفرع' USING ERRCODE='23514'; END IF;
 SELECT * INTO v_item FROM public.barq_warehouse_items WHERE id=v_route.warehouse_item_id FOR UPDATE;
 IF NOT FOUND OR v_item.order_id IS DISTINCT FROM p_order_id
   OR v_item.branch_id IS DISTINCT FROM v_branch OR v_item.status IS DISTINCT FROM 'stored' THEN
  RAISE EXCEPTION 'الطرد ليس محفوظاً على رف الفرع' USING ERRCODE='23514'; END IF;
 IF NOT EXISTS (SELECT 1 FROM public.drivers d JOIN public.profiles p ON p.id=d.user_id
   WHERE d.id=p_driver_id AND d.branch_id=v_branch AND d.is_active IS TRUE
     AND d.is_available IS TRUE AND p.role='driver') THEN
  RAISE EXCEPTION 'اختار مندوباً فعالاً ومتاحاً من نفس الفرع' USING ERRCODE='23514'; END IF;
 SELECT * INTO v_lm FROM public.barq_last_mile_v28 WHERE order_id=p_order_id FOR UPDATE;
 IF FOUND AND (v_lm.branch_id IS DISTINCT FROM v_branch OR v_lm.state IS DISTINCT FROM 'assigned') THEN
  RAISE EXCEPTION 'الطلب محجوز لمخزن آخر أو خرج سابقاً للمندوب' USING ERRCODE='23514'; END IF;
 v_code:=public.barq_v29_verify_receipt(p_order_id,p_scan);
 INSERT INTO public.barq_last_mile_v28(order_id,branch_id,warehouse_item_id,driver_id,assigned_by)
 VALUES(p_order_id,v_branch,v_item.id,p_driver_id,auth.uid())
 ON CONFLICT(order_id) DO UPDATE SET driver_id=excluded.driver_id,assigned_by=auth.uid(),assigned_at=now()
 WHERE public.barq_last_mile_v28.state='assigned' AND public.barq_last_mile_v28.branch_id=v_branch;
 PERFORM public.barq_v29_log(p_order_id,'v39_assign_final_driver',v_code,v_branch);
END;
$fn$;

-- Handover OUT of warehouse is separate from final barcode delivery to customer.
CREATE OR REPLACE FUNCTION public.barq_v39_branch_handover_final(
 p_order_id uuid,p_scan text
) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $fn$
DECLARE v_branch uuid;v_lm public.barq_last_mile_v28%ROWTYPE;
 v_order public.orders%ROWTYPE;v_item public.barq_warehouse_items%ROWTYPE;
 v_name text;v_code text;v_gov text;
BEGIN
 v_branch:=public.barq_v39_branch_id();
 SELECT governorate INTO v_gov FROM public.barq_branches WHERE id=v_branch;
 SELECT * INTO v_lm FROM public.barq_last_mile_v28 WHERE order_id=p_order_id FOR UPDATE;
 IF NOT FOUND OR v_lm.branch_id IS DISTINCT FROM v_branch OR v_lm.state IS DISTINCT FROM 'assigned' THEN
  RAISE EXCEPTION 'الطرد ليس معيّناً لمندوب في فرعك أو سبق خروجه' USING ERRCODE='23514'; END IF;
 SELECT * INTO v_order FROM public.orders WHERE id=p_order_id FOR UPDATE;
 IF NOT FOUND OR v_order.status IS DISTINCT FROM 'picked_up'
    OR v_order.delivery_governorate IS DISTINCT FROM v_gov THEN
  RAISE EXCEPTION 'حالة الطلب غير مناسبة للخروج من هذا الفرع' USING ERRCODE='23514'; END IF;
 IF NOT EXISTS (SELECT 1 FROM public.barq_order_routes r WHERE r.order_id=p_order_id
        AND r.route_type='warehouse' AND r.warehouse_item_id=v_lm.warehouse_item_id) THEN
  RAISE EXCEPTION 'مسار الطرد غير مرتبط بمخزن الفرع' USING ERRCODE='23514'; END IF;
 IF EXISTS (SELECT 1 FROM public.barq_branch_transfers t WHERE t.order_id=p_order_id
        AND t.transfer_status IN ('prepared','in_transit')) THEN
  RAISE EXCEPTION 'الطرد ما زال ضمن شحنة ناقل' USING ERRCODE='23514'; END IF;
 SELECT * INTO v_item FROM public.barq_warehouse_items WHERE id=v_lm.warehouse_item_id FOR UPDATE;
 IF NOT FOUND OR v_item.order_id IS DISTINCT FROM p_order_id
  OR v_item.branch_id IS DISTINCT FROM v_branch OR v_item.status IS DISTINCT FROM 'stored' THEN
  RAISE EXCEPTION 'الطرد غير موجود فعلياً على رف مخزنك' USING ERRCODE='23514'; END IF;
 SELECT p.full_name INTO v_name FROM public.drivers d JOIN public.profiles p ON p.id=d.user_id
 WHERE d.id=v_lm.driver_id AND d.branch_id=v_branch AND d.is_active IS TRUE AND p.role='driver';
 IF NOT FOUND THEN RAISE EXCEPTION 'المندوب غير فعال أو ليس تابعاً لفرعك' USING ERRCODE='23514'; END IF;
 v_code:=public.barq_v29_verify_receipt(p_order_id,p_scan);
 UPDATE public.barq_warehouse_items SET status='released',released_at=now(),released_by=auth.uid(),
  receiver_name=coalesce(nullif(v_name,''),'مندوب الفرع') WHERE id=v_item.id;
 UPDATE public.barq_last_mile_v28 SET state='out_for_delivery',handed_over_by=auth.uid(),
  handed_over_at=now(),original_driver_id=v_order.driver_id WHERE order_id=p_order_id;
 UPDATE public.orders SET driver_id=v_lm.driver_id,status='on_the_way',updated_at=now() WHERE id=p_order_id;
 PERFORM public.barq_v29_log(p_order_id,'v39_handover_final',v_code,v_branch);
END;
$fn$;

-- PUBLIC/ANON may NEVER invoke the mutation RPCs.
REVOKE ALL ON FUNCTION public.barq_v39_branch_id() FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.barq_v39_branch_operations() FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.barq_v39_branch_prepare_transfer(uuid,uuid,text) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.barq_v39_branch_dispatch_transfer(uuid,text,text,text) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.barq_v39_branch_receive_transfer(uuid,text,text,text) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.barq_v39_branch_assign_final_driver(uuid,uuid,text) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.barq_v39_branch_handover_final(uuid,text) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.barq_v39_branch_id() TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_v39_branch_operations() TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_v39_branch_prepare_transfer(uuid,uuid,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_v39_branch_dispatch_transfer(uuid,text,text,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_v39_branch_receive_transfer(uuid,text,text,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_v39_branch_assign_final_driver(uuid,uuid,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_v39_branch_handover_final(uuid,text) TO authenticated;
COMMIT;

SELECT
 to_regprocedure('public.barq_v39_branch_id()') IS NOT NULL AS scope_ready,
 to_regprocedure('public.barq_v39_branch_operations()') IS NOT NULL AS dashboard_ready,
 to_regprocedure('public.barq_v39_branch_prepare_transfer(uuid,uuid,text)') IS NOT NULL AS prepare_ready,
 to_regprocedure('public.barq_v39_branch_dispatch_transfer(uuid,text,text,text)') IS NOT NULL AS dispatch_ready,
 to_regprocedure('public.barq_v39_branch_receive_transfer(uuid,text,text,text)') IS NOT NULL AS receiving_ready,
 to_regprocedure('public.barq_v39_branch_assign_final_driver(uuid,uuid,text)') IS NOT NULL AS assign_ready,
 to_regprocedure('public.barq_v39_branch_handover_final(uuid,text)') IS NOT NULL AS handover_ready,
 to_regprocedure('public.barq_driver_deliver_by_scan_v29(uuid,text,boolean)') IS NOT NULL AS customer_scan_ready,
 to_regprocedure('public.barq_branch_receive_pickup_v29(uuid,text,text,text)') IS NOT NULL AS pickup_scan_ready,
 to_regprocedure('public.barq_driver_final_mile_v28()') IS NOT NULL AS courier_list_ready,
 to_regprocedure('public.barq_v38_branch_context()') IS NOT NULL AS branch_context_ready;
