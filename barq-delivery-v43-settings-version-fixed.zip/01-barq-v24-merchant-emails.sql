-- BARQ V24 | Show merchant account login emails to the verified general admin.
-- Run in Supabase SQL Editor BEFORE uploading the V24 site.
-- Read-only function: does not modify merchants, authentication users, branches, or orders.
-- Never put service_role or secret keys in barq-config.js or browser code.

CREATE OR REPLACE FUNCTION public.barq_admin_merchant_emails_v24()
RETURNS TABLE (merchant_id uuid, email text)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $function$
BEGIN
  -- The signed-in user must be the general admin. Checking UI role alone is not safe.
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid() AND p.role = 'admin'
  ) THEN
    RAISE EXCEPTION 'غير مصرح: عرض إيميلات المحلات للمدير العام فقط'
      USING ERRCODE = '42501';
  END IF;

  RETURN QUERY
  SELECT m.id, u.email::text
  FROM public.merchants m
  LEFT JOIN auth.users u ON u.id = m.owner_id;
END;
$function$;

-- Prevent public/anonymous execution; only authenticated users can call it,
-- and only a user with profiles.role='admin' can receive results.
REVOKE ALL ON FUNCTION public.barq_admin_merchant_emails_v24() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.barq_admin_merchant_emails_v24() FROM anon;
GRANT EXECUTE ON FUNCTION public.barq_admin_merchant_emails_v24() TO authenticated;

-- This check works directly in SQL Editor (calling the function there
-- usually has no auth.uid() and will be rejected by design).
SELECT
  to_regprocedure('public.barq_admin_merchant_emails_v24()') IS NOT NULL AS function_ready,
  has_function_privilege('authenticated', 'public.barq_admin_merchant_emails_v24()', 'EXECUTE') AS authenticated_can_invoke,
  has_function_privilege('anon', 'public.barq_admin_merchant_emails_v24()', 'EXECUTE') AS anonymous_cannot_invoke_check;
-- Expected: true, true, FALSE for the last column.
