-- BARQ V30 | 2026-11-15 | V29 SQL syntax fix; V29 RPC function names retained for app compatibility.
-- Fixes ELSIF CASE nesting ambiguity in driver state transitions; no changes to table data.
-- Do NOT rerun the faulty V29 SQL; use this corrected complete transaction.
-- Execute after V26, V27 and V28. Backup the database before running.
-- Existing orders, warehouses and branch transfers are not deleted or reset.
-- Each physical transition requires a matching printed receipt code (QR / Code128 payload).
-- A scanner keyboard and typed text are indistinguishable to a website. Confirm physical custody separately.

BEGIN;

CREATE TABLE IF NOT EXISTS public.barq_scan_events_v29 (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE RESTRICT,
 branch_id uuid REFERENCES public.barq_branches(id),
 actor_id uuid NOT NULL,
 action text NOT NULL,
 receipt_code text NOT NULL,
 tx_number bigint NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS barq_v29_scan_history_order_idx ON public.barq_scan_events_v29(order_id,created_at DESC);
ALTER TABLE public.barq_scan_events_v29 ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.barq_scan_events_v29 FROM PUBLIC, anon, authenticated;
REVOKE ALL ON SEQUENCE public.barq_scan_events_v29_id_seq FROM PUBLIC, anon, authenticated;

-- Internal helper only. Extract BRQ-<32 hex> also from an existing QR URL.
CREATE OR REPLACE FUNCTION public.barq_v29_verify_receipt(p_order_id uuid,p_scanned text)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_expected text; v_scan text;
BEGIN
 IF p_order_id IS NULL OR length(btrim(coalesce(p_scanned,''))) NOT BETWEEN 7 AND 600 THEN
  RAISE EXCEPTION 'امسح رمز الوصل الصحيح أولاً' USING ERRCODE='22023';
 END IF;
 SELECT coalesce(nullif(btrim(o.receipt_code),''),o.id::text) INTO v_expected
 FROM public.orders o WHERE o.id=p_order_id;
 IF NOT FOUND THEN RAISE EXCEPTION 'الطلب غير موجود' USING ERRCODE='23514'; END IF;
 v_scan := upper(substring(p_scanned from 'BRQ-[0-9A-Fa-f]{32}'));
 IF v_scan IS NULL THEN v_scan := btrim(p_scanned); END IF;
 IF upper(v_scan) IS DISTINCT FROM upper(v_expected) THEN
  RAISE EXCEPTION 'باركود الوصل لا يطابق هذا الطرد' USING ERRCODE='23514';
 END IF;
 RETURN v_expected;
END; $$;

CREATE OR REPLACE FUNCTION public.barq_v29_log(p_order uuid,p_action text,p_code text,p_branch uuid DEFAULT NULL)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'سجل الدخول أولاً' USING ERRCODE='42501'; END IF;
 INSERT INTO public.barq_scan_events_v29(order_id,branch_id,actor_id,action,receipt_code,tx_number)
 VALUES (p_order,p_branch,auth.uid(),p_action,p_code,txid_current());
END; $$;
REVOKE ALL ON FUNCTION public.barq_v29_verify_receipt(uuid,text) FROM PUBLIC,anon,authenticated;
REVOKE ALL ON FUNCTION public.barq_v29_log(uuid,text,text,uuid) FROM PUBLIC,anon,authenticated;

-- Driver pickup from merchant, or direct-delivery status, both require a scanned parcel label.
CREATE OR REPLACE FUNCTION public.barq_driver_advance_by_scan_v29(
 p_order_id uuid,p_next_status text,p_scan text,p_handed_to_customer boolean DEFAULT false)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_driver uuid; v_order public.orders%ROWTYPE; v_code text; v_origin text; v_dest text; v_route text;
BEGIN
 SELECT d.id INTO v_driver FROM public.drivers d
 JOIN public.profiles p ON p.id=d.user_id
 WHERE d.user_id=auth.uid() AND p.role='driver' AND d.is_active IS TRUE LIMIT 1;
 IF v_driver IS NULL THEN RAISE EXCEPTION 'فقط المندوب الفعّال يستطيع مسح هذا الطرد' USING ERRCODE='42501'; END IF;
 SELECT * INTO v_order FROM public.orders WHERE id=p_order_id AND driver_id=v_driver FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'الطرد ليس ضمن عهدتك' USING ERRCODE='42501'; END IF;
 v_code:=public.barq_v29_verify_receipt(p_order_id,p_scan);
 IF p_next_status='picked_up' AND v_order.status='assigned' THEN
  PERFORM public.barq_v29_log(p_order_id,'merchant_pickup',v_code,NULL);
 ELSIF (
     (p_next_status = 'on_the_way' AND v_order.status = 'picked_up')
     OR
     (p_next_status = 'delivered' AND v_order.status = 'on_the_way')
   ) THEN
  SELECT r.route_type INTO v_route FROM public.barq_order_routes r WHERE r.order_id=p_order_id;
  SELECT b.governorate,o.delivery_governorate INTO v_origin,v_dest
  FROM public.orders o JOIN public.merchants m ON m.id=o.merchant_id
  LEFT JOIN public.barq_branches b ON b.id=coalesce(o.origin_branch_id,m.branch_id)
  WHERE o.id=p_order_id;
  IF v_route IS DISTINCT FROM 'direct' OR replace(btrim(coalesce(v_origin,'')),'البصره','البصرة')
     IS DISTINCT FROM replace(btrim(coalesce(v_dest,'')),'البصره','البصرة') THEN
   RAISE EXCEPTION 'هذا الطلب ليس توصيلاً مباشراً؛ لا تستخدم زر التوصيل المحلي' USING ERRCODE='23514';
  END IF;
  IF p_next_status='delivered' AND NOT coalesce(p_handed_to_customer,false) THEN
   RAISE EXCEPTION 'لازم تأكد التسليم الفعلي للزبون' USING ERRCODE='22023';
  END IF;
  IF p_next_status = 'delivered' THEN
   PERFORM public.barq_v29_log(p_order_id,'direct_customer_delivery',v_code,NULL);
  ELSE
   PERFORM public.barq_v29_log(p_order_id,'direct_on_the_way',v_code,NULL);
  END IF;
 ELSE
  RAISE EXCEPTION 'انتقال الحالة غير مسموح أو تم تنفيذه سابقاً' USING ERRCODE='23514';
 END IF;
 PERFORM public.driver_advance_order(p_order_id,p_next_status);
END; $$;

-- Driver arrives at origin warehouse (scans the same physical label).
CREATE OR REPLACE FUNCTION public.barq_driver_arrive_warehouse_v29(p_order_id uuid,p_scan text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_code text;
BEGIN
 v_code:=public.barq_v29_verify_receipt(p_order_id,p_scan);
 PERFORM public.barq_driver_arrive_warehouse_v26(p_order_id);
 PERFORM public.barq_v29_log(p_order_id,'arrive_origin_warehouse',v_code,NULL);
END; $$;

-- Baghdad local pickup from courier to warehouse; original V26 RPC validates manager & stage.
CREATE OR REPLACE FUNCTION public.barq_branch_receive_pickup_v29(p_order_id uuid,p_scan text,p_shelf text,p_condition text DEFAULT 'good')
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_item uuid; v_code text; v_branch uuid;
BEGIN
 v_code:=public.barq_v29_verify_receipt(p_order_id,p_scan);
 v_item:=public.barq_branch_receive_pickup_v26(p_order_id,p_shelf,p_condition);
 SELECT branch_id INTO v_branch FROM public.barq_warehouse_items WHERE id=v_item;
 PERFORM public.barq_v29_log(p_order_id,'origin_warehouse_receive',v_code,v_branch);
 RETURN v_item;
END; $$;

CREATE OR REPLACE FUNCTION public.barq_branch_prepare_to_bas_v29(p_order_id uuid,p_scan text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_transfer uuid; v_code text; v_branch uuid;
BEGIN
 v_code:=public.barq_v29_verify_receipt(p_order_id,p_scan);
 v_transfer:=public.barq_branch_prepare_to_bas_v27(p_order_id);
 SELECT from_branch_id INTO v_branch FROM public.barq_branch_transfers WHERE id=v_transfer;
 PERFORM public.barq_v29_log(p_order_id,'baghdad_prepare_dispatch',v_code,v_branch);
 RETURN v_transfer;
END; $$;

CREATE OR REPLACE FUNCTION public.barq_branch_handover_to_bas_v29(
 p_transfer_id uuid,p_scan text,p_transport_name text,p_transport_reference text DEFAULT NULL)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_order uuid; v_branch uuid; v_code text;
BEGIN
 SELECT order_id,from_branch_id INTO v_order,v_branch FROM public.barq_branch_transfers WHERE id=p_transfer_id;
 IF v_order IS NULL THEN RAISE EXCEPTION 'التحويل غير موجود' USING ERRCODE='23514'; END IF;
 v_code:=public.barq_v29_verify_receipt(v_order,p_scan);
 PERFORM public.barq_branch_handover_to_bas_v27(p_transfer_id,p_transport_name,p_transport_reference);
 PERFORM public.barq_v29_log(v_order,'baghdad_handover_to_carrier',v_code,v_branch);
END; $$;

CREATE OR REPLACE FUNCTION public.barq_bas_receive_from_bgd_v29(
 p_transfer_id uuid,p_scan text,p_shelf text,p_condition text DEFAULT 'good')
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_order uuid; v_branch uuid; v_code text; v_item uuid;
BEGIN
 SELECT order_id,to_branch_id INTO v_order,v_branch FROM public.barq_branch_transfers WHERE id=p_transfer_id;
 IF v_order IS NULL THEN RAISE EXCEPTION 'التحويل غير موجود' USING ERRCODE='23514'; END IF;
 v_code:=public.barq_v29_verify_receipt(v_order,p_scan);
 v_item:=public.barq_bas_receive_from_bgd_v27(p_transfer_id,v_code,p_shelf,p_condition);
 PERFORM public.barq_v29_log(v_order,'basra_warehouse_receive',v_code,v_branch);
 RETURN v_item;
END; $$;

CREATE OR REPLACE FUNCTION public.barq_bas_assign_final_driver_v29(p_order_id uuid,p_driver_id uuid,p_scan text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_branch uuid; v_code text;
BEGIN
 v_code:=public.barq_v29_verify_receipt(p_order_id,p_scan);
 PERFORM public.barq_bas_assign_final_driver_v28(p_order_id,p_driver_id);
 SELECT branch_id INTO v_branch FROM public.barq_last_mile_v28 WHERE order_id=p_order_id;
 PERFORM public.barq_v29_log(p_order_id,'basra_assign_final_driver',v_code,v_branch);
END; $$;

CREATE OR REPLACE FUNCTION public.barq_bas_handover_final_v29(p_order_id uuid,p_scan text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_branch uuid; v_code text;
BEGIN
 v_code:=public.barq_v29_verify_receipt(p_order_id,p_scan);
 PERFORM public.barq_bas_handover_final_v28(p_order_id,v_code);
 SELECT branch_id INTO v_branch FROM public.barq_last_mile_v28 WHERE order_id=p_order_id;
 PERFORM public.barq_v29_log(p_order_id,'basra_handover_to_courier',v_code,v_branch);
END; $$;

-- Database-level protection against status-change shortcuts on new and existing orders.
-- Scan events are inserted by V29 RPCs in the same transaction; ordinary clients cannot insert them.
CREATE OR REPLACE FUNCTION public.barq_v29_guard_order_status()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_action text;
BEGIN
 IF NEW.status IS NOT DISTINCT FROM OLD.status THEN RETURN NEW; END IF;
 IF NEW.status='picked_up' AND OLD.status IS DISTINCT FROM 'picked_up' THEN v_action:='merchant_pickup';
 ELSIF NEW.status='delivered' AND OLD.status IS DISTINCT FROM 'delivered' THEN
  IF EXISTS (SELECT 1 FROM public.barq_last_mile_v28 lm WHERE lm.order_id=NEW.id)
  THEN v_action:='basra_customer_delivery'; ELSE v_action:='direct_customer_delivery'; END IF;
 ELSE RETURN NEW;
 END IF;
 IF NOT EXISTS (
  SELECT 1 FROM public.barq_scan_events_v29 se
  WHERE se.order_id=NEW.id AND se.action=v_action AND se.actor_id=auth.uid()
   AND se.tx_number=txid_current()
 ) THEN
  RAISE EXCEPTION 'لا يمكن تغيير حالة الطرد بدون مسح وصل برق من الواجهة الجديدة V29' USING ERRCODE='23514';
 END IF;
 RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS barq_v29_guard_order_status_trigger ON public.orders;
CREATE TRIGGER barq_v29_guard_order_status_trigger BEFORE UPDATE OF status ON public.orders
 FOR EACH ROW EXECUTE FUNCTION public.barq_v29_guard_order_status();
REVOKE ALL ON FUNCTION public.barq_v29_guard_order_status() FROM PUBLIC,anon,authenticated;

-- Customer delivery guard runs BEFORE the V29 post-update event; insert audit before v28 RPC.
CREATE OR REPLACE FUNCTION public.barq_driver_deliver_by_scan_v29(
 p_order_id uuid,p_scan text,p_recipient_handover boolean)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_branch uuid; v_code text;
BEGIN
 IF NOT coalesce(p_recipient_handover,false) THEN
   RAISE EXCEPTION 'أكد التسليم الفعلي قبل حفظ العملية' USING ERRCODE='22023';
 END IF;
 v_code:=public.barq_v29_verify_receipt(p_order_id,p_scan);
 SELECT branch_id INTO v_branch FROM public.barq_last_mile_v28 WHERE order_id=p_order_id;
 PERFORM public.barq_v29_log(p_order_id,'basra_customer_delivery',v_code,v_branch);
 PERFORM public.barq_driver_deliver_by_qr_v28(p_order_id,v_code,p_recipient_handover);
END; $$;

-- Existing BAS -> BGD transfer path (V22), now with mandatory parcel-code match.
CREATE OR REPLACE FUNCTION public.barq_admin_prepare_branch_transfer_v29(
 p_order_id uuid,p_target_branch_code text,p_notes text,p_scan text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_code text; v_branch uuid;
BEGIN
 v_code:=public.barq_v29_verify_receipt(p_order_id,p_scan);
 PERFORM public.barq_admin_prepare_branch_transfer(p_order_id,p_target_branch_code,p_notes);
 SELECT t.from_branch_id INTO v_branch FROM public.barq_branch_transfers t
 WHERE t.order_id=p_order_id AND t.transfer_status='prepared' ORDER BY t.created_at DESC LIMIT 1;
 PERFORM public.barq_v29_log(p_order_id,'prepare_branch_transfer',v_code,v_branch);
END; $$;

CREATE OR REPLACE FUNCTION public.barq_admin_handover_branch_transfer_v29(
 p_transfer_id uuid,p_transport_name text,p_transport_reference text,p_scan text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_order uuid; v_branch uuid; v_code text;
BEGIN
 SELECT t.order_id,t.from_branch_id INTO v_order,v_branch
 FROM public.barq_branch_transfers t WHERE t.id=p_transfer_id;
 IF v_order IS NULL THEN RAISE EXCEPTION 'التحويل غير موجود' USING ERRCODE='23514'; END IF;
 v_code:=public.barq_v29_verify_receipt(v_order,p_scan);
 PERFORM public.barq_admin_handover_branch_transfer(p_transfer_id,p_transport_name,p_transport_reference);
 PERFORM public.barq_v29_log(v_order,'handover_branch_transfer',v_code,v_branch);
END; $$;

CREATE OR REPLACE FUNCTION public.barq_branch_receive_transfer_by_scan_v29(
 p_scan_value text,p_shelf text,p_condition text DEFAULT 'good')
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_code text; v_order uuid; v_branch uuid;
BEGIN
 v_code:=coalesce(upper(substring(p_scan_value from 'BRQ-[0-9A-Fa-f]{32}')),btrim(p_scan_value));
 SELECT o.id INTO v_order FROM public.orders o
 WHERE upper(coalesce(nullif(btrim(o.receipt_code),''),o.id::text))=upper(v_code) LIMIT 1;
 IF v_order IS NULL THEN RAISE EXCEPTION 'وصل غير معروف' USING ERRCODE='23514'; END IF;
 v_code:=public.barq_v29_verify_receipt(v_order,p_scan_value);
 PERFORM public.barq_branch_receive_transfer_by_qr(p_scan_value,p_shelf,p_condition);
 SELECT branch_id INTO v_branch FROM public.barq_warehouse_items
 WHERE order_id=v_order AND status='stored' ORDER BY received_at DESC LIMIT 1;
 PERFORM public.barq_v29_log(v_order,'receive_branch_transfer',v_code,v_branch);
END; $$;

-- Return only logged-in driver's parcel codes for scanner UI (never all customer orders).
CREATE OR REPLACE FUNCTION public.barq_driver_receipts_v29()
RETURNS TABLE (order_id uuid, receipt_code text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_driver uuid;
BEGIN
 SELECT d.id INTO v_driver FROM public.drivers d JOIN public.profiles p ON p.id=d.user_id
 WHERE d.user_id=auth.uid() AND p.role='driver' AND d.is_active IS TRUE LIMIT 1;
 IF v_driver IS NULL THEN RETURN; END IF;
 RETURN QUERY SELECT o.id,coalesce(nullif(btrim(o.receipt_code),''),o.id::text)
 FROM public.orders o WHERE o.driver_id=v_driver AND o.status IN ('assigned','picked_up','on_the_way','delivered')
 ORDER BY o.created_at DESC LIMIT 300;
END; $$;

-- General admin can audit scanned transitions without granting table access to clients.
CREATE OR REPLACE FUNCTION public.barq_admin_scan_history_v29(p_scan text DEFAULT NULL)
RETURNS TABLE (
 order_id uuid, receipt_code text, action text, actor_name text, branch_name text, scanned_at timestamptz
)
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_filter text;
BEGIN
 IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id=auth.uid() AND role='admin')
 THEN RAISE EXCEPTION 'سجل الباركود للإدارة العامة فقط' USING ERRCODE='42501'; END IF;
 IF length(coalesce(p_scan,''))>600 THEN RAISE EXCEPTION 'بحث طويل جداً' USING ERRCODE='22023'; END IF;
 v_filter:=upper(coalesce(nullif(btrim(p_scan),''),''));
 IF v_filter<>'' THEN
  v_filter:=coalesce(upper(substring(v_filter from 'BRQ-[0-9A-F]{32}')),v_filter);
 END IF;
 RETURN QUERY SELECT e.order_id,o.receipt_code,e.action,coalesce(p.full_name,'بدون اسم'),
  coalesce(b.name,'—'),e.created_at
 FROM public.barq_scan_events_v29 e JOIN public.orders o ON o.id=e.order_id
 LEFT JOIN public.profiles p ON p.id=e.actor_id LEFT JOIN public.barq_branches b ON b.id=e.branch_id
 WHERE v_filter='' OR upper(coalesce(nullif(btrim(o.receipt_code),''),o.id::text))=v_filter
 ORDER BY e.created_at DESC,e.id DESC LIMIT 200;
END; $$;

-- Older state-changing RPC calls are deliberately disabled for clients; V29 wrappers invoke them internally.
-- This ensures an old cached V28 page cannot bypass scanning during the new workflow.
REVOKE EXECUTE ON FUNCTION public.barq_driver_arrive_warehouse_v26(uuid) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_branch_receive_pickup_v26(uuid,text,text) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_branch_prepare_to_bas_v27(uuid) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_branch_handover_to_bas_v27(uuid,text,text) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_bas_receive_from_bgd_v27(uuid,text,text,text) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_bas_assign_final_driver_v28(uuid,uuid) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_bas_handover_final_v28(uuid,text) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_driver_deliver_by_qr_v28(uuid,text,boolean) FROM PUBLIC,anon,authenticated;
DO $$
DECLARE sig text;
BEGIN
 FOREACH sig IN ARRAY ARRAY[
  'public.driver_advance_order(uuid,text)',
  'public.barq_admin_prepare_branch_transfer(uuid,text,text)',
  'public.barq_admin_handover_branch_transfer(uuid,text,text)',
  'public.barq_branch_receive_transfer_by_qr(text,text,text)'
 ] LOOP
  IF to_regprocedure(sig) IS NOT NULL THEN
   EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC,anon,authenticated',sig);
  END IF;
 END LOOP;
END $$;


-- Only authenticated users can invoke public workflow RPCs (each RPC also checks its live role).
REVOKE EXECUTE ON FUNCTION public.barq_admin_prepare_branch_transfer_v29(uuid,text,text,text) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_admin_handover_branch_transfer_v29(uuid,text,text,text) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_branch_receive_transfer_by_scan_v29(text,text,text) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_driver_advance_by_scan_v29(uuid,text,text,boolean) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_driver_arrive_warehouse_v29(uuid,text) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_branch_receive_pickup_v29(uuid,text,text,text) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_branch_prepare_to_bas_v29(uuid,text) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_branch_handover_to_bas_v29(uuid,text,text,text) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_bas_receive_from_bgd_v29(uuid,text,text,text) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_bas_assign_final_driver_v29(uuid,uuid,text) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_bas_handover_final_v29(uuid,text) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_driver_deliver_by_scan_v29(uuid,text,boolean) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_driver_receipts_v29() FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_admin_scan_history_v29(text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_prepare_branch_transfer_v29(uuid,text,text,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_handover_branch_transfer_v29(uuid,text,text,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_branch_receive_transfer_by_scan_v29(text,text,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_driver_advance_by_scan_v29(uuid,text,text,boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_driver_arrive_warehouse_v29(uuid,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_branch_receive_pickup_v29(uuid,text,text,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_branch_prepare_to_bas_v29(uuid,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_branch_handover_to_bas_v29(uuid,text,text,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_bas_receive_from_bgd_v29(uuid,text,text,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_bas_assign_final_driver_v29(uuid,uuid,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_bas_handover_final_v29(uuid,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_driver_deliver_by_scan_v29(uuid,text,boolean) TO authenticated;

GRANT EXECUTE ON FUNCTION public.barq_driver_receipts_v29() TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_scan_history_v29(text) TO authenticated;

COMMIT;

SELECT
 to_regprocedure('public.barq_admin_prepare_branch_transfer_v29(uuid,text,text,text)') IS NOT NULL AS reverse_prepare_ready,
 to_regprocedure('public.barq_admin_handover_branch_transfer_v29(uuid,text,text,text)') IS NOT NULL AS reverse_handover_ready,
 to_regprocedure('public.barq_branch_receive_transfer_by_scan_v29(text,text,text)') IS NOT NULL AS reverse_receive_ready,
 to_regprocedure('public.barq_driver_advance_by_scan_v29(uuid,text,text,boolean)') IS NOT NULL AS driver_scan_ready,
 to_regprocedure('public.barq_driver_arrive_warehouse_v29(uuid,text)') IS NOT NULL AS driver_warehouse_ready,
 to_regprocedure('public.barq_branch_receive_pickup_v29(uuid,text,text,text)') IS NOT NULL AS baghdad_warehouse_ready,
 to_regprocedure('public.barq_branch_prepare_to_bas_v29(uuid,text)') IS NOT NULL AS baghdad_prepare_ready,
 to_regprocedure('public.barq_branch_handover_to_bas_v29(uuid,text,text,text)') IS NOT NULL AS baghdad_dispatch_ready,
 to_regprocedure('public.barq_bas_receive_from_bgd_v29(uuid,text,text,text)') IS NOT NULL AS basra_receive_ready,
 to_regprocedure('public.barq_bas_assign_final_driver_v29(uuid,uuid,text)') IS NOT NULL AS basra_assign_ready,
 to_regprocedure('public.barq_bas_handover_final_v29(uuid,text)') IS NOT NULL AS basra_handover_ready,
 to_regprocedure('public.barq_driver_deliver_by_scan_v29(uuid,text,boolean)') IS NOT NULL AS delivery_scan_ready,
 to_regprocedure('public.barq_driver_receipts_v29()') IS NOT NULL AS courier_receipts_ready,
 to_regprocedure('public.barq_admin_scan_history_v29(text)') IS NOT NULL AS scan_history_ready;
