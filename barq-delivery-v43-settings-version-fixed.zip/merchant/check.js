
    'use strict';
    const $=id=>document.getElementById(id);
    const CFG_KEY='delivery_merchant_public_config_v1';
    let sb=null,user=null,shops=[],orders=[],view='orders',filter='all',channel=null,poll=null,fetching=false;
    let followedOrderId=null,pickupMapPoll=null,pickupMapFetching=false,lastPickupLocationKey='';
    let pickupLiveMap=null,pickupLiveMarker=null,pickupAccuracyCircle=null,pickupMapChannel=null,pickupMapFollow=true,pickupMapAnimation=null;
    $('deliveryGoodsType').addEventListener('change',()=>{const custom=$('deliveryGoodsType').value==='أخرى';$('deliveryGoodsOtherWrap').classList.toggle('hidden',!custom);$('deliveryGoodsOther').required=custom;if(!custom)$('deliveryGoodsOther').value='';});
    const statuses={pending:'بانتظار التوزيع',assigned:'تم تعيين المندوب',picked_up:'تم استلام الطلب',on_the_way:'بالطريق للزبون',delivered:'تم التسليم',cancelled:'ملغي',returned:'راجع'};
    const html=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const money=x=>Number(x||0).toLocaleString('en-US');
    const short=x=>'#'+String(x||'').slice(0,8).toUpperCase();

    let barqBalanceBusy=false;
    async function barqLoadMerchantBalance(){
      if(!sb||!user||barqBalanceBusy)return;
      barqBalanceBusy=true;
      const refreshButton=$('barqBalanceRefresh');refreshButton.disabled=true;
      $('barqBalanceError').textContent='';$('barqBalanceError').classList.add('hidden');
      try{
        const {data,error}=await sb.rpc('barq_merchant_financial_balance');
        if(error)throw error;
        const rows=Array.isArray(data)?data:[];
        let due=0,paid=0,balance=0,unpaid=0;
        for(const r of rows){
          due+=Number(r.total_due_iqd||0);
          paid+=Number(r.total_paid_iqd||0);
          balance+=Number(r.balance_iqd||0);
          unpaid+=Number(r.unpaid_orders||0);
        }
        $('barqBalanceAmount').innerHTML=money(balance)+' <small>د.ع</small>';
        $('barqBalanceDue').textContent=money(due)+' د.ع';
        $('barqBalancePaid').textContent=money(paid)+' د.ع';
        $('barqBalanceOrders').textContent=money(unpaid);
        $('barqBalanceShops').textContent=rows.length>1
          ?rows.map(r=>`${r.merchant_name}: ${money(r.balance_iqd||0)} د.ع`).join('  |  ')
          :'';
      }catch(e){
        $('barqBalanceAmount').innerHTML='— <small>د.ع</small>';
        $('barqBalanceDue').textContent='—';$('barqBalancePaid').textContent='—';$('barqBalanceOrders').textContent='—';
        $('barqBalanceShops').textContent='';
        $('barqBalanceError').textContent='تعذر جلب الرصيد: '+(e.message||e)+'. تأكد من تشغيل كود SQL الخاص بالرصيد.';
        $('barqBalanceError').classList.remove('hidden');
      }finally{barqBalanceBusy=false;refreshButton.disabled=false;}
    }
    $('barqBalanceRefresh').addEventListener('click',barqLoadMerchantBalance);

    function msg(id,s){$(id).textContent=s||'';$(id).classList.toggle('hidden',!s);}
    function show(id){['setupPage','loginPage','appPage'].forEach(k=>$(k).classList.toggle('hidden',k!==id));}
    function config(){const c=window.BARQ_CONFIG;return c&&validUrl(c.url)&&typeof c.key==='string'&&c.key.startsWith('sb_publishable_')?c:null}
    function validUrl(s){try{const u=new URL(s);return u.protocol==='https:'&&/^[a-z0-9-]+\.supabase\.co$/i.test(u.hostname)&&(u.pathname==='/'||!u.pathname)}catch{return false}}
    function init(cfg){if(!window.supabase?.createClient)throw Error('تعذر تحميل مكتبة Supabase. تأكد من وجود الإنترنت.');sb=window.supabase.createClient(cfg.url,cfg.key,{auth:{storageKey:'delivery_merchant_session_v1',persistSession:true,autoRefreshToken:true,detectSessionInUrl:false}});}
    async function boot(){const cfg=config();if(!cfg){show('loginPage');msg('loginError','إعدادات الاتصال لم يجهزها مدير النظام بعد. تواصل مع الإدارة.');return}try{init(cfg);const {data,error}=await sb.auth.getSession();if(error)throw error;if(!data.session?.user){show('loginPage');return}await enter(data.session.user)}catch(e){show('loginPage');msg('loginError',e.message||'تعذر فتح التطبيق')}}
    async function checkMerchant(u){const {data,error}=await sb.from('profiles').select('role,full_name').eq('id',u.id).single();if(error)throw Error('تعذر قراءة ملف الحساب: '+error.message);if(data?.role!=='merchant')throw Error('هذا الحساب ليس حساب محل. سجّل دخول بحساب المحل المسجل لدى الشركة.');return data}
    async function loadShops(){const {data,error}=await sb.from('merchants').select('id,name,merchant_type,phone,address,is_active').eq('owner_id',user.id).order('created_at',{ascending:false});if(error)throw error;shops=data||[];const active=shops.filter(s=>s.is_active);$('merchantSelect').innerHTML=active.map(s=>`<option value="${html(s.id)}">${html(s.name)}</option>`).join('')||'<option value="">لا يوجد محل نشط</option>';$('createBtn').disabled=!active.length;$('shopList').innerHTML=shops.map(s=>`<div class="order"><div class="order-header"><strong>${html(s.name)}</strong><span class="status ${s.is_active?'delivered':'cancelled'}">${s.is_active?'نشط':'موقوف'}</span></div><div class="order-meta">${s.merchant_type==='restaurant'?'مطعم':'محل'} — ${html(s.address||'بدون عنوان')}</div><div class="order-meta">هاتف: ${html(s.phone||'—')}</div></div>`).join('')||'<div class="empty">ما عندك أي محل مرتبط بهذا الحساب. تواصل مع مدير الشركة.</div>';return active}
    async function refresh(){if(fetching||!sb||!user)return;fetching=true;$('refreshBtn').disabled=true;try{msg('appError','');const ids=shops.map(s=>s.id);if(!ids.length){orders=[];render();return}const {data,error}=await sb.from('orders').select('id,receipt_code,merchant_id,customer_name,customer_phone,delivery_address,delivery_governorate,goods_type,order_amount_iqd,delivery_fee_iqd,collection_method,status,driver_id,notes,created_at').in('merchant_id',ids).order('created_at',{ascending:false}).limit(200);if(error)throw error;orders=data||[];render();if(followedOrderId&&!orders.some(o=>o.id===followedOrderId&&o.status==='assigned'&&o.driver_id))closePickupMap()}catch(e){msg('appError','تعذر تحميل الطلبات: '+(e.message||e))}finally{fetching=false;$('refreshBtn').disabled=false;await barqLoadMerchantBalance();}}
    function render(){const active=orders.filter(o=>!['delivered','cancelled','returned'].includes(o.status));const done=orders.filter(o=>o.status==='delivered');$('totalCount').textContent=money(orders.length);$('activeCount').textContent=money(active.length);$('doneCount').textContent=money(done.length);const vis=filter==='delivered'?done:filter==='active'?active:orders;$('ordersList').innerHTML=vis.length?vis.map(o=>{const s=shops.find(x=>x.id===o.merchant_id);const dt=o.created_at?new Date(o.created_at).toLocaleString('ar-IQ',{dateStyle:'medium',timeStyle:'short'}):'';return `<article class="order"><div class="order-header"><div><div class="order-id">طلب ${html(short(o.id))}</div><div class="order-meta barq-code">${html(o.receipt_code||'—')}</div><div class="order-meta">${html(dt)} · ${html(s?.name||'المحل')}</div></div><span class="status ${html(o.status)}">${html(statuses[o.status]||o.status)}</span></div><div class="details"><div class="detail"><label>الزبون</label><strong>${html(o.customer_name)}</strong></div><div class="detail"><label>رقم الهاتف</label><strong dir="ltr">${html(o.customer_phone)}</strong></div><div class="detail"><label>المحافظة</label><strong>${html(o.delivery_governorate||'غير محددة')}</strong></div><div class="detail"><label>نوع البضاعة</label><strong>${html(o.goods_type||'غير محدد')}</strong></div><div class="detail"><label>عنوان التوصيل</label><strong>${html(o.delivery_address)}</strong></div><div class="detail"><label>مبلغ الطلب / التوصيل</label><strong>${money(o.order_amount_iqd)} / ${money(o.delivery_fee_iqd)} د.ع</strong></div><div class="detail"><label>طريقة التحصيل</label><strong>${o.collection_method==='full_cod'?'المندوب يستلم الكل':o.collection_method==='delivery_fee_only'?'المندوب يستلم التوصيل فقط':'تحتاج تحديد من الإدارة'}</strong></div></div>${o.notes?`<div class="order-note">ملاحظات: ${html(o.notes)}</div>`:''}${o.receipt_code?`<button type="button" class="barq-qr-subtle" data-show-receipt="${html(o.id)}" style="margin-top:12px">▦ عرض QR الوصل</button><button type="button" class="barq-qr-subtle" data-view-receipt="${html(o.id)}" style="margin-top:12px;margin-right:7px">🧾 تفاصيل الوصل</button>`:''}${o.status==='assigned'&&o.driver_id?`<div class="pickup-map-action"><button type="button" class="pickup-map-trigger" data-track-driver="${html(o.id)}">📍 متابعة موقع المندوب قبل الاستلام</button><small>الخريطة تتحرّك مباشرة مع تحديثات GPS ما دام التطبيق مفتوحاً</small></div>`:''}</article>`}).join(''):'<div class="empty">ماكو طلبات بهذا التصنيف حالياً.<br>امسح QR لوصل مطبوع من شركة برق حتى تفتح طلباً جديداً.</div>'}
    function pickupMapReady(){
      if(pickupLiveMap)return true;
      if(!window.L)return false;  // Older browser/network: keep iframe fallback.
      $('pickupMapCanvas').classList.remove('hidden');
      pickupLiveMap=L.map('pickupMapCanvas',{zoomControl:true,attributionControl:true,preferCanvas:true});
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
        maxZoom:19,attribution:'&copy; OpenStreetMap contributors'
      }).addTo(pickupLiveMap);
      pickupLiveMap.on('dragstart zoomstart',()=>{pickupMapFollow=false});
      return true;
    }
    function pickupLocationVisible(data){
      if(!data)return false;
      const age=Date.now()-Date.parse(data.updated_at);
      return Number.isFinite(age)&&age>=-30000&&age<120000;
    }
    function drawLivePickupPosition(data){
      const lat=Number(data.latitude),lng=Number(data.longitude);
      if(!Number.isFinite(lat)||!Number.isFinite(lng)||Math.abs(lat)>90||Math.abs(lng)>180)throw Error('إحداثيات غير صالحة');
      const time=new Date(data.updated_at).toLocaleTimeString('ar-IQ',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
      const seconds=Math.max(0,Math.floor((Date.now()-Date.parse(data.updated_at))/1000));
      $('pickupMapState').textContent='🟢 تتبع مباشر · آخر موقع قبل '+seconds+' ثانية · الساعة '+time+(data.accuracy_m==null?'':' · الدقة التقريبية '+Math.round(data.accuracy_m)+' متر');
      const coordKey=lat.toFixed(7)+','+lng.toFixed(7);
      $('pickupMapOpenLink').href='https://www.openstreetmap.org/?mlat='+encodeURIComponent(lat)+'&mlon='+encodeURIComponent(lng)+'#map=17/'+encodeURIComponent(lat)+'/'+encodeURIComponent(lng);
      $('pickupMapOpenLink').classList.remove('hidden');
      if(pickupMapReady()){
        $('pickupMapFrame').classList.add('hidden');$('pickupMapFrame').removeAttribute('src');
        const next=L.latLng(lat,lng);
        if(!pickupLiveMarker){
          const icon=L.divIcon({className:'',html:'<div class="barq-live-pin"></div>',iconSize:[24,24],iconAnchor:[12,12]});
          pickupLiveMarker=L.marker(next,{icon}).addTo(pickupLiveMap);
          pickupLiveMap.setView(next,17,{animate:false});
          setTimeout(()=>pickupLiveMap?.invalidateSize(),150);
          pickupMapFollow=true;
        }else if(coordKey!==lastPickupLocationKey){
          if(pickupMapAnimation)cancelAnimationFrame(pickupMapAnimation);
          const previous=pickupLiveMarker.getLatLng();
          const start=performance.now(),duration=900;
          function tick(now){
            if(!pickupLiveMarker)return;
            const t=Math.min(1,(now-start)/duration),ease=t*t*(3-2*t);
            pickupLiveMarker.setLatLng([previous.lat+(lat-previous.lat)*ease,previous.lng+(lng-previous.lng)*ease]);
            if(t<1)pickupMapAnimation=requestAnimationFrame(tick);else pickupMapAnimation=null;
          }
          pickupMapAnimation=requestAnimationFrame(tick);
          if(pickupMapFollow)pickupLiveMap.panTo(next,{animate:true,duration:0.9});
        }
        if(Number.isFinite(Number(data.accuracy_m))&&data.accuracy_m!==null){
          const a=Math.max(1,Math.min(1000,Number(data.accuracy_m)));
          if(!pickupAccuracyCircle)pickupAccuracyCircle=L.circle(next,{radius:a,color:'#fc851f',weight:1,fillColor:'#fc851f',fillOpacity:.08}).addTo(pickupLiveMap);
          else pickupAccuracyCircle.setLatLng(next).setRadius(a);
        }
      }else if(coordKey!==lastPickupLocationKey){
        const box=0.004,bbox=[lng-box,lat-box,lng+box,lat+box].join(',');
        $('pickupMapFrame').src='https://www.openstreetmap.org/export/embed.html?bbox='+encodeURIComponent(bbox)+'&layer=mapnik&marker='+encodeURIComponent(lat+','+lng);
        $('pickupMapFrame').classList.remove('hidden');
      }
      lastPickupLocationKey=coordKey;
    }
    function startPickupRealtime(driverId){
      if(!sb||!driverId)return;
      pickupMapChannel=sb.channel('pickup-live-'+driverId+'-'+Date.now())
        .on('postgres_changes',{event:'*',schema:'public',table:'driver_pickup_locations',filter:'driver_id=eq.'+driverId},()=>{if(followedOrderId&&!document.hidden)updatePickupMap()})
        .subscribe();
    }
    function openPickupMap(orderId){
      const o=orders.find(x=>x.id===orderId&&x.status==='assigned'&&x.driver_id);
      if(!o)return;
      closePickupMap();followedOrderId=orderId;pickupMapFollow=true;
      $('pickupMapModal').classList.remove('hidden');$('pickupMapModal').setAttribute('aria-hidden','false');
      $('pickupMapOrder').textContent='طلب '+short(o.id);
      $('pickupMapState').textContent='جاري الاتصال بموقع المندوب المباشر...';
      $('pickupMapFrame').classList.add('hidden');$('pickupMapOpenLink').classList.add('hidden');
      startPickupRealtime(o.driver_id);
      updatePickupMap();
      // Fallback when Realtime is delayed, disconnected, or not published.
      pickupMapPoll=setInterval(()=>{if(!document.hidden)updatePickupMap()},4000);
    }
    function closePickupMap(){
      followedOrderId=null;lastPickupLocationKey='';pickupMapFollow=true;
      if(pickupMapPoll!==null){clearInterval(pickupMapPoll);pickupMapPoll=null;}
      if(pickupMapChannel&&sb){sb.removeChannel(pickupMapChannel);pickupMapChannel=null;}
      if(pickupMapAnimation){cancelAnimationFrame(pickupMapAnimation);pickupMapAnimation=null;}
      if(pickupLiveMap){pickupLiveMap.remove();pickupLiveMap=null;pickupLiveMarker=null;pickupAccuracyCircle=null;}
      $('pickupMapCanvas').classList.add('hidden');
      $('pickupMapFrame').removeAttribute('src');$('pickupMapFrame').classList.add('hidden');$('pickupMapOpenLink').classList.add('hidden');
      $('pickupMapModal').classList.add('hidden');$('pickupMapModal').setAttribute('aria-hidden','true');
    }
    async function updatePickupMap(){
      if(!followedOrderId||pickupMapFetching)return;
      const order=orders.find(o=>o.id===followedOrderId&&o.status==='assigned'&&o.driver_id);
      if(!order){closePickupMap();return;}
      pickupMapFetching=true;
      try{
        const {data,error}=await sb.from('driver_pickup_locations')
          .select('driver_id,latitude,longitude,accuracy_m,updated_at')
          .eq('driver_id',order.driver_id).maybeSingle();
        if(error)throw error;
        if(followedOrderId!==order.id)return;
        if(!pickupLocationVisible(data)){
          $('pickupMapState').textContent='بانتظار مشاركة المندوب لموقع GPS المباشر، أو توقّف تحديث الموقع. لازم يبقى تطبيق المندوب مفتوحاً.';
          if(pickupLiveMap){pickupLiveMap.remove();pickupLiveMap=null;pickupLiveMarker=null;pickupAccuracyCircle=null;}
          $('pickupMapCanvas').classList.add('hidden');
          $('pickupMapFrame').classList.add('hidden');$('pickupMapFrame').removeAttribute('src');$('pickupMapOpenLink').classList.add('hidden');lastPickupLocationKey='';return;
        }
        drawLivePickupPosition(data);
      }catch(e){if(followedOrderId)$('pickupMapState').textContent='تعذّر تحديث الموقع المباشر: '+String(e.message||e);}
      finally{pickupMapFetching=false;}
    }
    function setView(v){if(v==='scan'){if(barqActiveCode){v='new'}else{barqScannerOpen();return;}}if(v==='new'&&!barqActiveCode){barqScannerOpen();return;}if(v!=='orders'&&followedOrderId)closePickupMap();view=v;[['orders','ordersView'],['new','newView'],['account','accountView']].forEach(([name,id])=>$(id).classList.toggle('hidden',name!==v));document.querySelectorAll('[data-view]').forEach(x=>x.classList.toggle('active',x.dataset.view===v||(v==='new'&&x.dataset.view==='scan')));msg('appError','');}
    function unsubscribe(){closePickupMap();if(channel&&sb){sb.removeChannel(channel);channel=null}if(poll){clearInterval(poll);poll=null}}
    function subscribe(){unsubscribe();channel=sb.channel('merchant-orders-'+user.id).on('postgres_changes',{event:'*',schema:'public',table:'orders'},()=>refresh()).subscribe();poll=setInterval(()=>{if(!document.hidden)refresh()},30000)}
    async function enter(u){const info=await checkMerchant(u);user=u;await loadShops();$('welcome').textContent='هلا، '+(info.full_name||shops.find(s=>s.is_active)?.name||'صاحب المحل')+' 👋';show('appPage');setView('orders');await refresh();subscribe();await barqOpenPhoneCameraReceipt()}
    $('loginForm').addEventListener('submit',async e=>{e.preventDefault();msg('loginError','');$('loginBtn').disabled=true;try{if(!sb)throw Error('الاتصال غير مهيأ من الإدارة.');const {data,error}=await sb.auth.signInWithPassword({email:$('email').value.trim(),password:$('password').value});if(error)throw error;$('password').value='';await enter(data.user)}catch(err){await sb?.auth.signOut();msg('loginError',err.message||'فشل الدخول')}finally{$('loginBtn').disabled=false}});
    $('logoutBtn').addEventListener('click',async()=>{unsubscribe();await sb?.auth.signOut();user=null;shops=[];orders=[];barqActiveCode='';barqScannerClose();show('loginPage')});
    document.querySelectorAll('[data-view]').forEach(x=>x.addEventListener('click',()=>setView(x.dataset.view)));
    document.querySelectorAll('[data-filter]').forEach(x=>x.addEventListener('click',()=>{filter=x.dataset.filter;document.querySelectorAll('[data-filter]').forEach(k=>k.classList.toggle('selected',k.dataset.filter===filter));render()}));
    $('refreshBtn').addEventListener('click',refresh);
    $('ordersList').addEventListener('click',e=>{const b=e.target.closest('[data-track-driver]');if(b)openPickupMap(b.dataset.trackDriver);const r=e.target.closest('[data-show-receipt]');if(r)barqShowExistingReceipt(r.dataset.showReceipt);const v=e.target.closest('[data-view-receipt]');if(v){const o=orders.find(x=>x.id===v.dataset.viewReceipt);if(o)barqShowUsedReceiptDetails(o,null)}});
    $('pickupMapClose').addEventListener('click',closePickupMap);
    $('pickupMapModal').addEventListener('click',e=>{if(e.target===$('pickupMapModal'))closePickupMap();});
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&followedOrderId)closePickupMap();});
    $('reloadShops').addEventListener('click',async()=>{try{await loadShops();await refresh();msg('appNotice','تم تحديث بيانات المحل.')}catch(e){msg('appError',e.message||'فشل التحديث')}});
    function positiveInteger(v,label){const n=Number(v);if(!Number.isSafeInteger(n)||n<0||n>2000000000)throw Error(label+' يجب أن يكون رقماً صحيحاً لا يقل عن صفر.');return n}
    $('collectionMethod').addEventListener('change',()=>{$('collectionHelp').textContent=$('collectionMethod').value==='full_cod'?'المندوب يجمع مبلغ الطلب وأجرة التوصيل من الزبون.':'المحل يكون مستلم مبلغ الطلب، والمندوب يجمع أجرة التوصيل فقط.'});
    $('newOrderForm').addEventListener('submit',async e=>{e.preventDefault();msg('appError','');msg('appNotice','');const b=$('createBtn');b.disabled=true;b.textContent='جاري إرسال الطلب...';try{if(!barqActiveCode)throw Error('لا يمكن فتح وصل جديد بدون مسح QR صادر من مدير برق.');const id=$('merchantSelect').value;if(!shops.some(s=>s.id===id&&s.is_active))throw Error('اختار محلاً نشطاً.');const customer=$('customerName').value.trim(),phone=$('customerPhone').value.trim(),address=$('deliveryAddress').value.trim();if(customer.length<2||phone.length<6||address.length<4)throw Error('تأكد من اسم الزبون ورقم الهاتف والعنوان.');const goods=$('deliveryGoodsType').value==='أخرى' ? $('deliveryGoodsOther').value.trim() : $('deliveryGoodsType').value;const governorate=$('deliveryGovernorate').value;if(!governorate||goods.length<2||goods.length>80)throw Error('اختار المحافظة ونوع البضاعة بشكل صحيح.');const payload={p_merchant_id:id,p_customer_name:customer,p_customer_phone:phone,p_delivery_address:address,p_delivery_governorate:governorate,p_goods_type:goods,p_order_amount_iqd:positiveInteger($('orderAmount').value,'مبلغ الطلب'),p_delivery_fee_iqd:positiveInteger($('deliveryFee').value,'أجرة التوصيل'),p_notes:$('notes').value.trim()||null,p_collection_method:$('collectionMethod').value};const {data,error}=await sb.rpc('barq_merchant_create_scanned_order',{...payload,p_code:barqActiveCode});if(error)throw error;barqActiveCode='';barqActiveNumber=null;barqUpdateScannedState();$('newOrderForm').reset();$('deliveryGoodsOtherWrap').classList.add('hidden');$('deliveryGoodsOther').required=false;msg('appNotice','تم إرسال الطلب '+short(data)+' إلى الإدارة بنجاح ✅');setView('orders');await refresh()}catch(err){msg('appError','تعذّر حفظ الطلب: '+(err.message||err))}finally{b.disabled=!shops.some(s=>s.is_active)||!barqActiveCode;b.textContent='حفظ الطلب وإرساله للإدارة'}});
    document.addEventListener('visibilitychange',()=>{if(!document.hidden&&user){refresh();if(followedOrderId)updatePickupMap();}});

    // BARQ V13: QR deep links contain only an opaque receipt code; no customer data.
    let barqActiveCode='',barqActiveNumber=null,barqVideoStream=null,barqVideoTimer=null,barqVerifyBusy=false;
    let barqLastPrint=null;
    function barqUpdateScannedState(){
      $('barqReceiptStateText').textContent=barqActiveCode
        ? '✅ تم فتح الوصل المطبوع رقم '+(barqActiveNumber||barqActiveCode)+' — عند الحفظ يرتبط بنفس الوصل مرة واحدة.'
        : 'امسح QR الوصل المطبوع الصادر من مدير شركة برق، حتى ينفتح نموذج الزبون والطلب.';
      $('barqClearScanned').style.display=barqActiveCode?'inline-flex':'none';$('merchantSelect').disabled=!!barqActiveCode;
    }
    function barqParseCode(raw){
      const val=String(raw||'').trim();
      if(/^BRQ-[A-F0-9]{32}$/i.test(val))return val.toUpperCase();
      try{
        const url=new URL(val);
        // Only a receipt deep-link to a merchant app; database access still checks ownership.
        if(url.protocol!=='https:'||!url.pathname.replace(/\/+$/,'').endsWith('/merchant'))return null;
        const code=new URLSearchParams(url.hash.replace(/^#/, '')).get('receipt')||url.searchParams.get('receipt');
        return /^BRQ-[A-F0-9]{32}$/i.test(code||'')?code.toUpperCase():null;
      }catch{return null;}
    }
    async function barqOpenPhoneCameraReceipt(){
      const params=new URLSearchParams(window.location.hash.replace(/^#/,''));
      const requested=params.get('receipt')||new URLSearchParams(window.location.search).get('receipt');
      if(!requested||!sb||!user)return;
      barqScannerOpen();
      // Remove the code from browser history as soon as it has been taken into the app.
      window.history.replaceState(null,'',window.location.pathname);
      await barqValidateCode(requested);
    }
    function barqScannerOpen(){
      if(!sb||!user)return;
      if(!shops.some(s=>s.is_active)){msg('appError','لا يوجد محل نشط مرتبط بحسابك. تواصل مع الإدارة.');return;}
      $('barqScannerModal').classList.remove('hidden');
      $('barqScanMessage').textContent='صوّر QR مطبوعاً بكاميرا الهاتف، أو اختر صورة واضحة للباركود.';
    }
    function barqStopVideo(){
      if(barqVideoTimer){clearInterval(barqVideoTimer);barqVideoTimer=null;}
      if(barqVideoStream){barqVideoStream.getTracks().forEach(t=>t.stop());barqVideoStream=null;}
      $('barqCameraVideo').srcObject=null;
      $('barqCameraVideo').classList.add('hidden');
    }
    function barqScannerClose(){barqStopVideo();$('barqScannerModal').classList.add('hidden');}
    async function barqValidateCode(raw){
      const code=barqParseCode(raw);
      if(!code){$('barqScanMessage').textContent='❌ هذا مو رمز وصل برق صالح. تأكد أنه صادر من مدير شركة برق.';return;}
      if(barqVerifyBusy)return;barqVerifyBusy=true;
      try{
        const {data,error}=await sb.rpc('barq_merchant_resolve_receipt',{p_code:code});
        if(error)throw error;
        const rec=data?.[0];
        if(!rec)throw Error('هذا الوصل مو مخصص لأي محل بحسابك، أو الرقم غير موجود.');
        if(!shops.some(s=>s.id===rec.receipt_merchant_id&&s.is_active))throw Error('المحل المخصص للوصل غير نشط.');
        $('merchantSelect').value=rec.receipt_merchant_id;
        if(rec.receipt_status==='used'){
          barqScannerClose();barqActiveCode='';barqActiveNumber=null;barqUpdateScannedState();
          setView('orders');
          if(!rec.existing_order_id){
            msg('appError','هذا الوصل مسجّل كمستخدم، لكن ما مرتبط بطلب ظاهر. تواصل مع إدارة برق برقم الوصل '+(rec.receipt_number||code));
            return;
          }
          const r=await sb.from('orders')
            .select('id,receipt_code,merchant_id,customer_name,customer_phone,delivery_address,delivery_governorate,goods_type,order_amount_iqd,delivery_fee_iqd,collection_method,status,notes,created_at')
            .eq('id',rec.existing_order_id)
            .eq('merchant_id',rec.receipt_merchant_id)
            .maybeSingle();
          if(r.error)throw r.error;
          if(!r.data)throw Error('ما تمكنّا نعرض معلومات الوصل القديم. تأكد من صلاحية حساب المحل.');
          barqShowUsedReceiptDetails(r.data,rec.receipt_number||null);
          return;
        }
        barqActiveCode=code;barqActiveNumber=rec.receipt_number||null;
        barqUpdateScannedState();barqScannerClose();setView('new');
        msg('appNotice','✅ انفتح الوصل '+(barqActiveNumber||code)+' باسم محلك. املأ معلومات الزبون والطلب، ثم احفظه.');
        $('customerName').focus();
      }catch(e){$('barqScanMessage').textContent='❌ '+(e.message||e);}finally{barqVerifyBusy=false;}
    }
    async function barqScanBitmap(source){
      const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d',{willReadFrequently:true});
      const width=source.videoWidth||source.naturalWidth||source.width;
      const height=source.videoHeight||source.naturalHeight||source.height;
      if(!width||!height)throw Error('الصورة غير واضحة');
      const scale=Math.min(1,1300/Math.max(width,height));
      canvas.width=Math.max(1,Math.round(width*scale));canvas.height=Math.max(1,Math.round(height*scale));
      ctx.drawImage(source,0,0,canvas.width,canvas.height);
      if('BarcodeDetector' in window){
        try{const native=new BarcodeDetector({formats:['qr_code']});const list=await native.detect(canvas);if(list.length)return list[0].rawValue;}catch(e){}
      }
      if(typeof window.jsQR!=='function')throw Error('تعذر تحميل قارئ QR. تأكد من الإنترنت أو أدخل الرمز يدوياً.');
      const pixels=ctx.getImageData(0,0,canvas.width,canvas.height);
      return window.jsQR(pixels.data,pixels.width,pixels.height,{inversionAttempts:'attemptBoth'})?.data||null;
    }
    $('barqStartCamera').addEventListener('click',async()=>{
      barqStopVideo();
      try{
        if(!navigator.mediaDevices?.getUserMedia)throw Error('الكاميرا غير مدعومة بهذا المتصفح. استخدم تصوير صورة بدلاً منها.');
        barqVideoStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false});
        const video=$('barqCameraVideo');video.srcObject=barqVideoStream;video.classList.remove('hidden');await video.play();
        $('barqScanMessage').textContent='قرّب QR من الكاميرا وخليه داخل الصورة.';
        let working=false;
        barqVideoTimer=setInterval(async()=>{
          if(working||video.readyState<2||barqVerifyBusy)return;
          working=true;
          try{const code=await barqScanBitmap(video);if(code)await barqValidateCode(code);}catch(e){}finally{working=false;}
        },600);
      }catch(e){barqStopVideo();$('barqScanMessage').textContent='❌ '+(e.message||e);}
    });
    $('barqStopCamera').addEventListener('click',barqStopVideo);
    $('barqScannerClose').addEventListener('click',barqScannerClose);
    $('barqScanFromForm').addEventListener('click',barqScannerOpen);
    $('barqScanHero').addEventListener('click',barqScannerOpen);
    $('barqScanOrders').addEventListener('click',barqScannerOpen);
    $('barqClearScanned').addEventListener('click',()=>{barqActiveCode='';barqActiveNumber=null;barqUpdateScannedState();setView('orders');});
    $('merchantSelect').addEventListener('change',()=>{if(barqActiveCode){barqActiveCode='';barqActiveNumber=null;barqUpdateScannedState();setView('orders');}});
    $('barqQRPhoto').addEventListener('change',async e=>{
      const file=e.target.files?.[0];if(!file)return;
      const url=URL.createObjectURL(file),img=new Image();
      try{
        await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=reject;img.src=url;});
        const code=await barqScanBitmap(img);if(code)await barqValidateCode(code);
        else $('barqScanMessage').textContent='ما قريت QR بهالصورة. جرّب صورة أقرب وأوضح.';
      }catch(err){$('barqScanMessage').textContent='تعذر قراءة الصورة: '+(err.message||err);}
      finally{URL.revokeObjectURL(url);e.target.value='';}
    });
    function barqMakeQR(mount,code,size=160){
      mount.innerHTML='';
      if(!window.QRCode){mount.textContent='تعذر تحميل مكتبة QR؛ الرمز النصي موجود.';return;}
      new window.QRCode(mount,{text:code,width:size,height:size,correctLevel:QRCode.CorrectLevel.M});
    }
    function barqPrintCard(title,code){
      const card=$('barqMerchantQR');const img=card.querySelector('img')||card.querySelector('canvas');
      const src=img?.tagName==='CANVAS'?img.toDataURL('image/png'):img?.src;
      if(!src){alert('QR مو جاهز للطباعة. تأكد من الإنترنت.');return;}
      const win=window.open('','_blank');if(!win){alert('اسمح بالنوافذ المنبثقة حتى تطبع الوصل.');return;}
      win.document.write('<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>وصل برق</title><body style="font-family:Tahoma;text-align:center;padding:25px"><h2>⚡ برق للتوصيل السريع</h2><p>'+html(title)+'</p><img width="220" height="220" src="'+src+'"><p style="font:13px monospace;direction:ltr">'+html(code)+'</p><script>window.onload=()=>window.print()<\\/script></body></html>'.replace('<\\/script>','<\/script>'));
      win.document.close();
    }
    function barqShowUsedReceiptDetails(o,receiptNumber){
      // Data originates from a query restricted to the currently signed-in merchant.
      const dt=o.created_at?new Date(o.created_at).toLocaleString('ar-IQ',{dateStyle:'medium',timeStyle:'short'}):'—';
      const label=(name,value,wide=false)=>`<div class="barq-used-cell${wide?' wide':''}"><label>${html(name)}</label><strong>${html(value??'—')}</strong></div>`;
      const collection=o.collection_method==='full_cod'?'المندوب يستلم مبلغ الطلب وأجرة التوصيل':o.collection_method==='delivery_fee_only'?'المندوب يستلم أجرة التوصيل فقط':'غير محدد';
      $('barqUsedReceiptDetails').innerHTML=`
        <div class="barq-used-title">وصل رقم ${html(receiptNumber||o.receipt_code||short(o.id))}</div>
        <div class="barq-used-grid">
          ${label('رقم الطلب',short(o.id))}
          ${label('حالة الطلب',statuses[o.status]||o.status)}
          ${label('تاريخ إنشاء الوصل',dt,true)}
          ${label('اسم الزبون',o.customer_name)}
          ${label('رقم هاتف الزبون',o.customer_phone)}
          ${label('محافظة التوصيل',o.delivery_governorate||'—')}
          ${label('نوع البضاعة',o.goods_type||'—')}
          ${label('عنوان التوصيل',o.delivery_address,true)}
          ${label('مبلغ الطلب',money(o.order_amount_iqd)+' د.ع')}
          ${label('أجرة التوصيل',money(o.delivery_fee_iqd)+' د.ع')}
          ${label('طريقة التحصيل',collection,true)}
          ${o.notes?label('ملاحظات',o.notes,true):''}
        </div>`;
      $('barqUsedReceiptModal').classList.remove('hidden');
    }
    $('barqUsedReceiptClose').addEventListener('click',()=>$('barqUsedReceiptModal').classList.add('hidden'));
    $('barqUsedReceiptModal').addEventListener('click',e=>{if(e.target===$('barqUsedReceiptModal'))$('barqUsedReceiptModal').classList.add('hidden')});
    function barqShowExistingReceipt(orderId,record=null){
      const o=record||orders.find(x=>x.id===orderId);if(!o||!o.receipt_code)return;
      barqLastPrint={code:o.receipt_code,title:'طلب '+short(o.id)+' — '+o.customer_name};
      $('barqReceiptDetail').textContent='الزبون: '+o.customer_name+' | هاتف: '+o.customer_phone+' | عنوان: '+o.delivery_address;
      $('barqMerchantQrCode').textContent=o.receipt_code;
      barqMakeQR($('barqMerchantQR'),o.receipt_code,175);
      $('barqShowReceiptModal').classList.remove('hidden');
    }
    $('barqReceiptClose').addEventListener('click',()=>$('barqShowReceiptModal').classList.add('hidden'));
    $('barqPrintSingle').addEventListener('click',()=>{if(barqLastPrint)barqPrintCard(barqLastPrint.title,barqLastPrint.code)});
    document.addEventListener('visibilitychange',()=>{if(document.hidden)barqStopVideo();});

    boot();
