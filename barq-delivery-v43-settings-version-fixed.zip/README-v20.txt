برق V20 — إصلاح تأكيد استلام طرود المحافظات + باركود المخزن.
1) شغّل barq-v20-01-fix-warehouse-rpc.sql في Supabase SQL Editor.
2) شغّل barq-v20-02-confirm-by-qr.sql (New Query مستقل).
3) جهّز ZIP من barq-v20-configure.html باستخدام Project URL وPublishable key فقط.
4) Cloudflare Pages / barq-delivery / Create deployment وارفع ZIP الناتج.
5) من لوحة المدير: مخزن الشركة / شحن المحافظات / 📷 مسح QR.
تأكد أولاً أن المندوب حدّد مسار المحافظات ثم ضغط "وصلت للشركة"؛ قبل ذلك سيرفض الخادم التأكيد.
المسح يوثّق استلام الطرد بالمخزن فقط، ولا يؤكد تسليمه للزبون أو تحصيل قيمته.
لم تتغير واجهات المندوب والمحل ولا حساباتهم.
