-- BARQ V43: Merchant account username / phone aliases and a verified-admin-only driver email view.
-- Run once after V36 and V42. No modification of existing orders, passwords, barcode, or branch relationships.
BEGIN;

CREATE TABLE IF NOT EXISTS public.barq_merchant_login_aliases_v43 (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text NOT NULL UNIQUE,
  phone_e164 text UNIQUE,
  updated_by uuid REFERENCES auth.users(id),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT barq_v43_merchant_username_format CHECK (username ~ '^[a-z][a-z0-9_]{3,23}$'),
  CONSTRAINT barq_v43_merchant_phone_format CHECK (phone_e164 IS NULL OR phone_e164 ~ '^[+]9647[0-9]{9}$')
);
ALTER TABLE public.barq_merchant_login_aliases_v43 ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.barq_merchant_login_aliases_v43 FROM PUBLIC, anon, authenticated;
GRANT SELECT ON TABLE public.barq_merchant_login_aliases_v43 TO service_role;

CREATE OR REPLACE FUNCTION public.barq_admin_driver_emails_v43()
RETURNS TABLE (driver_id uuid, email text)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $fn$
BEGIN
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role='admin'
  ) THEN
    RAISE EXCEPTION 'البريد الإلكتروني للمندوبين متاح للمدير العام فقط' USING ERRCODE='42501';
  END IF;
  RETURN QUERY
  SELECT d.id, u.email::text
  FROM public.drivers d
  LEFT JOIN auth.users u ON u.id = d.user_id;
END;
$fn$;
REVOKE ALL ON FUNCTION public.barq_admin_driver_emails_v43() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_driver_emails_v43() TO authenticated;

CREATE OR REPLACE FUNCTION public.barq_admin_merchant_aliases_v43()
RETURNS TABLE (user_id uuid, username text, phone_e164 text)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $fn$
BEGIN
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role='admin'
  ) THEN
    RAISE EXCEPTION 'غير مصرح' USING ERRCODE='42501';
  END IF;
  RETURN QUERY
  SELECT a.user_id,a.username,a.phone_e164
  FROM public.barq_merchant_login_aliases_v43 a;
END;
$fn$;
REVOKE ALL ON FUNCTION public.barq_admin_merchant_aliases_v43() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_merchant_aliases_v43() TO authenticated;

CREATE OR REPLACE FUNCTION public.barq_admin_merchant_username_available_v43(p_username text)
RETURNS boolean
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $fn$
DECLARE v_username text;
BEGIN
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role='admin'
  ) THEN
    RAISE EXCEPTION 'غير مصرح' USING ERRCODE='42501';
  END IF;
  v_username := lower(btrim(coalesce(p_username,'')));
  IF v_username !~ '^[a-z][a-z0-9_]{3,23}$' THEN RETURN false; END IF;
  RETURN NOT EXISTS (
    SELECT 1 FROM public.barq_merchant_login_aliases_v43 a WHERE a.username = v_username
  );
END;
$fn$;
REVOKE ALL ON FUNCTION public.barq_admin_merchant_username_available_v43(text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_merchant_username_available_v43(text) TO authenticated;


CREATE OR REPLACE FUNCTION public.barq_admin_merchant_phone_available_v43(p_phone text)
RETURNS boolean
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $fn$
DECLARE v_digits text; v_phone text;
BEGIN
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.profiles p WHERE p.id=auth.uid() AND p.role='admin'
  ) THEN RAISE EXCEPTION 'غير مصرح' USING ERRCODE='42501'; END IF;
  v_digits:=regexp_replace(coalesce(p_phone,''),'[^0-9]','','g');
  IF v_digits='' THEN RETURN true; END IF;
  IF v_digits ~ '^07[0-9]{9}$' THEN v_phone:='+964'||substring(v_digits from 2);
  ELSIF v_digits ~ '^9647[0-9]{9}$' THEN v_phone:='+'||v_digits;
  ELSIF v_digits ~ '^009647[0-9]{9}$' THEN v_phone:='+'||substring(v_digits from 3);
  ELSE RETURN false; END IF;
  RETURN NOT EXISTS(SELECT 1 FROM public.barq_merchant_login_aliases_v43 a WHERE a.phone_e164=v_phone);
END;
$fn$;
REVOKE ALL ON FUNCTION public.barq_admin_merchant_phone_available_v43(text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_merchant_phone_available_v43(text) TO authenticated;

CREATE OR REPLACE FUNCTION public.barq_admin_set_merchant_alias_v43(
    p_merchant_id uuid, p_username text, p_phone text DEFAULT NULL
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $fn$
DECLARE
  v_owner_id uuid;
  v_username text;
  v_digits text;
  v_phone text;
BEGIN
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role='admin'
  ) THEN
    RAISE EXCEPTION 'هذا الإجراء للمدير العام فقط' USING ERRCODE='42501';
  END IF;

  SELECT m.owner_id INTO v_owner_id FROM public.merchants m WHERE m.id = p_merchant_id;
  IF v_owner_id IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.profiles p WHERE p.id=v_owner_id AND p.role='merchant'
  ) THEN
    RAISE EXCEPTION 'لا يوجد حساب صاحب محل مرتبط بهذا السجل';
  END IF;

  v_username := lower(btrim(coalesce(p_username,'')));
  IF v_username !~ '^[a-z][a-z0-9_]{3,23}$' THEN
    RAISE EXCEPTION 'اليوزرنيم 4 إلى 24 رمزاً إنجليزياً، يبدأ بحرف، ويقبل الأرقام و _';
  END IF;

  v_digits := regexp_replace(coalesce(p_phone,''),'[^0-9]','','g');
  IF v_digits = '' THEN
    SELECT a.phone_e164 INTO v_phone FROM public.barq_merchant_login_aliases_v43 a WHERE a.user_id=v_owner_id;
  ELSIF v_digits ~ '^07[0-9]{9}$' THEN
    v_phone := '+964' || substring(v_digits from 2);
  ELSIF v_digits ~ '^9647[0-9]{9}$' THEN
    v_phone := '+' || v_digits;
  ELSIF v_digits ~ '^009647[0-9]{9}$' THEN
    v_phone := '+' || substring(v_digits from 3);
  ELSE
    RAISE EXCEPTION 'رقم هاتف الدخول يجب أن يكون عراقياً: 07XXXXXXXXX';
  END IF;

  INSERT INTO public.barq_merchant_login_aliases_v43 AS a (user_id, username, phone_e164, updated_by, updated_at)
  VALUES (v_owner_id, v_username, v_phone, auth.uid(), now())
  ON CONFLICT (user_id) DO UPDATE SET
    username = EXCLUDED.username,
    phone_e164 = EXCLUDED.phone_e164,
    updated_by = EXCLUDED.updated_by,
    updated_at = now();
EXCEPTION WHEN unique_violation THEN
  RAISE EXCEPTION 'اليوزرنيم أو رقم الهاتف مستخدم بحساب محل آخر';
END;
$fn$;
REVOKE ALL ON FUNCTION public.barq_admin_set_merchant_alias_v43(uuid,text,text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_set_merchant_alias_v43(uuid,text,text) TO authenticated;

COMMIT;

SELECT
  to_regclass('public.barq_merchant_login_aliases_v43') IS NOT NULL AS merchant_aliases_ready,
  to_regprocedure('public.barq_admin_driver_emails_v43()') IS NOT NULL AS driver_emails_ready,
  to_regprocedure('public.barq_admin_merchant_aliases_v43()') IS NOT NULL AS aliases_list_ready,
  to_regprocedure('public.barq_admin_set_merchant_alias_v43(uuid,text,text)') IS NOT NULL AS aliases_save_ready,
  to_regprocedure('public.barq_admin_merchant_username_available_v43(text)') IS NOT NULL AS username_check_ready,
  to_regprocedure('public.barq_admin_merchant_phone_available_v43(text)') IS NOT NULL AS phone_check_ready,
  to_regprocedure('public.barq_v36_login_rate_limit(text,integer)') IS NOT NULL AS login_rate_limit_ready;
-- Expected seven true. A successful existence check does NOT substitute for testing the RPCs in a live admin session.
