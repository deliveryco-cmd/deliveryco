/* Supabase public configuration. No secrets. */
window.BARQ_CONFIG = {"url":"https://xyhareshmnnxrldslfoo.supabase.co","key":"sb_publishable_G_AbtEuhVVqJFg0v9wpnJA_5fK5Paqu"};
