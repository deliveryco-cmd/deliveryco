-- BARQ V23 | Branch management for the verified general admin only.
-- Run ONCE in Supabase SQL Editor before deploying the V23 admin panel.
-- Does not modify existing orders, merchants, drivers, settlements or branch assignments.
-- Existing branches BAS and BGD are retained. No policies are replaced here.

-- Prevent duplicate branch codes. Current BAS/BGD codes are distinct.
CREATE UNIQUE INDEX IF NOT EXISTS barq_branches_code_v23_unique
  ON public.barq_branches (upper(code));

CREATE OR REPLACE FUNCTION public.barq_admin_branch_dashboard_v23()
RETURNS TABLE (
  branch_id uuid,
  branch_code text,
  branch_name text,
  governorate text,
  address text,
  is_active boolean,
  merchants_count bigint,
  drivers_count bigint,
  orders_count bigint,
  staff_count bigint,
  managers jsonb
)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid() AND p.role = 'admin'
  ) THEN
    RAISE EXCEPTION 'غير مصرح: العملية للمدير العام فقط' USING ERRCODE = '42501';
  END IF;

  RETURN QUERY
  SELECT
    b.id, b.code, b.name, b.governorate, b.address, b.is_active,
    (SELECT count(*) FROM public.merchants m WHERE m.branch_id = b.id),
    (SELECT count(*) FROM public.drivers d WHERE d.branch_id = b.id),
    (SELECT count(*) FROM public.orders o WHERE o.origin_branch_id = b.id),
    (SELECT count(*) FROM public.barq_branch_staff s
      WHERE s.branch_id = b.id AND s.is_active IS TRUE),
    COALESCE((
      SELECT jsonb_agg(jsonb_build_object(
        'user_id', s.user_id,
        'name', NULLIF(p.full_name, ''),
        'role', s.branch_role,
        'active', s.is_active
      ) ORDER BY s.assigned_at)
      FROM public.barq_branch_staff s
      LEFT JOIN public.profiles p ON p.id = s.user_id
      WHERE s.branch_id = b.id
        AND s.branch_role IN ('branch_manage', 'branch_manager')
    ), '[]'::jsonb)
  FROM public.barq_branches b
  ORDER BY b.created_at NULLS LAST, b.code;
END;
$$;

CREATE OR REPLACE FUNCTION public.barq_admin_save_branch_v23(
  p_branch_id uuid,
  p_code text,
  p_name text,
  p_governorate text,
  p_address text,
  p_is_active boolean
)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
DECLARE
  v_id uuid;
  v_code text := upper(btrim(coalesce(p_code,'')));
  v_name text := btrim(coalesce(p_name,''));
  v_gov text := btrim(coalesce(p_governorate,''));
  v_addr text := nullif(btrim(coalesce(p_address,'')), '');
  v_old_code text;
  v_old_gov text;
BEGIN
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid() AND p.role = 'admin'
  ) THEN
    RAISE EXCEPTION 'غير مصرح: العملية للمدير العام فقط' USING ERRCODE = '42501';
  END IF;
  IF v_code !~ '^[A-Z0-9_-]{2,12}$' THEN
    RAISE EXCEPTION 'رمز الفرع يجب أن يكون 2-12 حرفاً إنكليزياً أو رقماً' USING ERRCODE = '22023';
  END IF;
  IF char_length(v_name) NOT BETWEEN 3 AND 120 THEN
    RAISE EXCEPTION 'اسم الفرع يجب أن يكون من 3 إلى 120 حرفاً' USING ERRCODE = '22023';
  END IF;
  IF v_gov NOT IN (
    'البصرة','بغداد','نينوى','الأنبار','أربيل','السليمانية',
    'دهوك','حلبجة','كركوك','صلاح الدين','ديالى','بابل','كربلاء',
    'النجف','القادسية','واسط','ميسان','ذي قار','المثنى'
  ) THEN
    RAISE EXCEPTION 'اختر محافظة عراقية صحيحة' USING ERRCODE = '22023';
  END IF;
  IF length(coalesce(v_addr,'')) > 300 OR p_is_active IS NULL THEN
    RAISE EXCEPTION 'بيانات الفرع غير صحيحة' USING ERRCODE = '22023';
  END IF;

  IF p_branch_id IS NULL THEN
    INSERT INTO public.barq_branches
      (id,code,name,governorate,address,is_active,created_at)
    VALUES
      (pg_catalog.gen_random_uuid(),v_code,v_name,v_gov,v_addr,p_is_active,now())
    RETURNING id INTO v_id;
  ELSE
    SELECT b.code, b.governorate INTO v_old_code, v_old_gov FROM public.barq_branches b
    WHERE b.id = p_branch_id FOR UPDATE;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'الفرع غير موجود' USING ERRCODE = 'P0002';
    END IF;
    -- Keep existing branch codes immutable: legacy routing references BAS and BGD.
    IF v_old_code IS DISTINCT FROM v_code THEN
      RAISE EXCEPTION 'لا يمكن تغيير رمز فرع موجود لحماية الطلبات والمسارات السابقة' USING ERRCODE = '22023';
    END IF;
    IF v_old_gov IS DISTINCT FROM v_gov THEN
      RAISE EXCEPTION 'محافظة الفرع ثابتة بعد الإنشاء لحماية ربط المحلات والمندوبين' USING ERRCODE = '22023';
    END IF;
    UPDATE public.barq_branches b
    SET name=v_name,address=v_addr,is_active=p_is_active
    WHERE b.id = p_branch_id;
    v_id := p_branch_id;
  END IF;
  RETURN v_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.barq_admin_set_branch_manager_v23(
  p_branch_id uuid,
  p_user_id uuid,
  p_active boolean
)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
DECLARE
  v_role text;
  v_matched int;
BEGIN
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid() AND p.role = 'admin'
  ) THEN
    RAISE EXCEPTION 'غير مصرح: العملية للمدير العام فقط' USING ERRCODE = '42501';
  END IF;
  IF p_branch_id IS NULL OR p_user_id IS NULL OR p_active IS NULL THEN
    RAISE EXCEPTION 'اختر الفرع والحساب والحالة' USING ERRCODE = '22023';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.barq_branches b WHERE b.id=p_branch_id) THEN
    RAISE EXCEPTION 'الفرع غير موجود' USING ERRCODE = 'P0002';
  END IF;
  SELECT p.role INTO v_role FROM public.profiles p WHERE p.id=p_user_id;
  IF v_role IS NULL OR v_role NOT IN ('branch_manage','branch_manager') THEN
    RAISE EXCEPTION 'الحساب المحدد ليس حساب مدير فرع' USING ERRCODE = '22023';
  END IF;

  -- Do not let a manager run two active branches simultaneously.
  IF p_active AND EXISTS (
    SELECT 1 FROM public.barq_branch_staff s
    WHERE s.user_id=p_user_id AND s.branch_id<>p_branch_id
      AND s.is_active IS TRUE
      AND s.branch_role IN ('branch_manage','branch_manager')
  ) THEN
    RAISE EXCEPTION 'هذا المدير مرتبط بفرع آخر؛ عطّل تعيينه القديم أولاً' USING ERRCODE = '23514';
  END IF;

  UPDATE public.barq_branch_staff s
  SET is_active=p_active,
      assigned_by=CASE WHEN p_active THEN auth.uid() ELSE s.assigned_by END,
      assigned_at=CASE WHEN p_active THEN now() ELSE s.assigned_at END
  WHERE s.branch_id=p_branch_id AND s.user_id=p_user_id
    AND s.branch_role IN ('branch_manage','branch_manager');
  GET DIAGNOSTICS v_matched = ROW_COUNT;

  IF v_matched=0 THEN
    IF NOT p_active THEN
      RAISE EXCEPTION 'لم يتم العثور على تعيين لهذا المدير' USING ERRCODE = 'P0002';
    END IF;
    INSERT INTO public.barq_branch_staff
      (id,branch_id,user_id,branch_role,is_active,assigned_by,assigned_at)
    VALUES
      (pg_catalog.gen_random_uuid(),p_branch_id,p_user_id,v_role,true,auth.uid(),now());
  END IF;
END;
$$;

-- EXECUTE is allowed for authenticated users but each RPC additionally enforces admin.
REVOKE ALL ON FUNCTION public.barq_admin_branch_dashboard_v23() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.barq_admin_save_branch_v23(uuid,text,text,text,text,boolean) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.barq_admin_set_branch_manager_v23(uuid,uuid,boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.barq_admin_branch_dashboard_v23() TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_save_branch_v23(uuid,text,text,text,text,boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_set_branch_manager_v23(uuid,uuid,boolean) TO authenticated;

SELECT
  to_regprocedure('public.barq_admin_branch_dashboard_v23()') IS NOT NULL AS dashboard_ready,
  to_regprocedure('public.barq_admin_save_branch_v23(uuid,text,text,text,text,boolean)') IS NOT NULL AS save_ready,
  to_regprocedure('public.barq_admin_set_branch_manager_v23(uuid,uuid,boolean)') IS NOT NULL AS managers_ready;
