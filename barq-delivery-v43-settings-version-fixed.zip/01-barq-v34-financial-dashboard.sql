-- BARQ V34 | Branch financial reports + auditable operating expenses.
-- Install after V33. Back up Supabase before applying.
-- No existing order, payroll, barcode, or settlement records are modified.
-- IMPORTANT: Operating result is a MANAGEMENT ESTIMATE, not a cash balance:
--  delivery revenue is recognized on delivery date; older orders without a
--  dedicated delivered_at timestamp use orders.updated_at (approximation).
--  A posted salary month is an accrued expense even if not yet paid.
--  driver_remittance and merchant_payout are cash movements, NOT extra revenue/expense.
BEGIN;

CREATE TABLE IF NOT EXISTS public.barq_finance_expenses_v34 (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 request_id uuid NOT NULL UNIQUE,
 branch_id uuid REFERENCES public.barq_branches(id) ON DELETE RESTRICT,
 expense_date date NOT NULL,
 category text NOT NULL CHECK (category IN ('transport','fuel','rent','utilities','maintenance','other')),
 amount_iqd bigint NOT NULL CHECK (amount_iqd BETWEEN 1 AND 1000000000),
 description text NOT NULL DEFAULT '' CHECK (char_length(description) <= 500),
 created_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE RESTRICT,
 created_at timestamptz NOT NULL DEFAULT now(),
 voided_at timestamptz,
 voided_by uuid REFERENCES auth.users(id),
 void_reason text NOT NULL DEFAULT '' CHECK (char_length(void_reason) <= 500),
 CONSTRAINT barq_v34_void_consistent CHECK ((voided_at IS NULL AND voided_by IS NULL) OR (voided_at IS NOT NULL AND voided_by IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS barq_v34_expenses_month_branch_idx ON public.barq_finance_expenses_v34 (expense_date,branch_id);
ALTER TABLE public.barq_finance_expenses_v34 ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.barq_finance_expenses_v34 FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.barq_admin_add_expense_v34(
 p_branch_id uuid, p_expense_date date, p_category text,
 p_amount_iqd bigint, p_description text, p_request_id uuid
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $fn$
DECLARE v_id uuid; v_existing public.barq_finance_expenses_v34%ROWTYPE;
BEGIN
 IF auth.uid() IS NULL OR NOT EXISTS (
  SELECT 1 FROM public.profiles p WHERE p.id=auth.uid() AND p.role='admin'
 ) THEN RAISE EXCEPTION 'هذا الإجراء خاص بالمدير العام' USING ERRCODE='42501'; END IF;
 IF p_request_id IS NULL OR p_expense_date IS NULL OR
    p_expense_date > (now() AT TIME ZONE 'Asia/Baghdad')::date OR
    p_expense_date < DATE '2020-01-01' OR
    p_amount_iqd IS NULL OR p_amount_iqd NOT BETWEEN 1 AND 1000000000 OR
    p_category IS NULL OR p_category NOT IN ('transport','fuel','rent','utilities','maintenance','other') OR
    length(coalesce(p_description,''))>500 THEN
   RAISE EXCEPTION 'راجع التاريخ والنوع والمبلغ والوصف' USING ERRCODE='22023';
 END IF;
 IF p_branch_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM public.barq_branches b WHERE b.id=p_branch_id
 ) THEN RAISE EXCEPTION 'الفرع غير موجود' USING ERRCODE='22023'; END IF;
 SELECT * INTO v_existing FROM public.barq_finance_expenses_v34 WHERE request_id=p_request_id;
 IF FOUND THEN
   IF v_existing.branch_id IS NOT DISTINCT FROM p_branch_id AND
      v_existing.expense_date=p_expense_date AND
      v_existing.category=p_category AND
      v_existing.amount_iqd=p_amount_iqd AND
      v_existing.description=coalesce(p_description,'') THEN
     RETURN v_existing.id;
   END IF;
   RAISE EXCEPTION 'رقم العملية مستخدم لتسجيل مصروف آخر' USING ERRCODE='23505';
 END IF;
 INSERT INTO public.barq_finance_expenses_v34
   (request_id,branch_id,expense_date,category,amount_iqd,description,created_by)
 VALUES (p_request_id,p_branch_id,p_expense_date,p_category,p_amount_iqd,
   coalesce(p_description,''),auth.uid()) RETURNING id INTO v_id;
 RETURN v_id;
END;
$fn$;

CREATE OR REPLACE FUNCTION public.barq_admin_void_expense_v34(p_expense_id uuid,p_reason text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $fn$
BEGIN
 IF auth.uid() IS NULL OR NOT EXISTS (
  SELECT 1 FROM public.profiles p WHERE p.id=auth.uid() AND p.role='admin'
 ) THEN RAISE EXCEPTION 'هذا الإجراء خاص بالمدير العام' USING ERRCODE='42501'; END IF;
 IF p_expense_id IS NULL OR length(btrim(coalesce(p_reason,''))) NOT BETWEEN 5 AND 500 THEN
   RAISE EXCEPTION 'اكتب سبب الإلغاء (5 أحرف على الأقل)' USING ERRCODE='22023'; END IF;
 UPDATE public.barq_finance_expenses_v34
 SET voided_at=now(),voided_by=auth.uid(),void_reason=btrim(p_reason)
 WHERE id=p_expense_id AND voided_at IS NULL;
 IF NOT FOUND THEN RAISE EXCEPTION 'المصروف غير موجود أو ملغى مسبقاً' USING ERRCODE='P0002'; END IF;
END;
$fn$;

CREATE OR REPLACE FUNCTION public.barq_admin_financial_report_v34(p_month date)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $fn$
DECLARE v_branches jsonb; v_expenses jsonb;
BEGIN
 IF auth.uid() IS NULL OR NOT EXISTS (
  SELECT 1 FROM public.profiles p WHERE p.id=auth.uid() AND p.role='admin'
 ) THEN RAISE EXCEPTION 'هذا التقرير خاص بالمدير العام' USING ERRCODE='42501'; END IF;
 IF p_month IS NULL OR EXTRACT(DAY FROM p_month)<>1 OR
    p_month < DATE '2020-01-01' OR
    p_month > date_trunc('month',(now() AT TIME ZONE 'Asia/Baghdad'))::date THEN
   RAISE EXCEPTION 'شهر التقرير غير صحيح' USING ERRCODE='22023'; END IF;

 WITH branch_catalog AS (
  SELECT b.id,b.code,b.name,b.governorate FROM public.barq_branches b
  UNION ALL SELECT NULL::uuid,'HQ'::text,'المركز / بدون فرع'::text,'غير محددة'::text
 ), delivered AS (
  SELECT
    COALESCE(o.destination_branch_id,
      (SELECT MIN(b.id) FROM public.barq_branches b
       WHERE b.governorate=o.delivery_governorate
       HAVING count(*)=1)) AS branch_id,
    o.delivery_fee_iqd, o.driver_earning_iqd, o.collection_method,
    (lm.delivered_at IS NOT NULL) AS has_exact_delivery_time
  FROM public.orders o
  LEFT JOIN public.barq_last_mile_v28 lm ON lm.order_id=o.id
  WHERE o.status='delivered'
    AND date_trunc('month',(coalesce(lm.delivered_at,o.updated_at) AT TIME ZONE 'Asia/Baghdad'))::date=p_month
 ), delivery_sums AS (
  SELECT branch_id,
    count(*)::bigint AS delivered_count,
    count(*) FILTER(WHERE (
      collection_method IN ('full_cod','delivery_fee_only')
      AND delivery_fee_iqd IS NOT NULL AND driver_earning_iqd IS NOT NULL
      AND delivery_fee_iqd >= driver_earning_iqd AND driver_earning_iqd>=0
    ) IS NOT TRUE)::bigint AS incomplete_count,
    count(*) FILTER(WHERE NOT has_exact_delivery_time)::bigint AS approximate_date_count,
    COALESCE(sum(delivery_fee_iqd) FILTER (WHERE
      collection_method IN ('full_cod','delivery_fee_only')
      AND delivery_fee_iqd IS NOT NULL AND driver_earning_iqd IS NOT NULL
      AND delivery_fee_iqd >= driver_earning_iqd AND driver_earning_iqd>=0),0)::bigint AS fee_revenue,
    COALESCE(sum(driver_earning_iqd) FILTER (WHERE
      collection_method IN ('full_cod','delivery_fee_only')
      AND delivery_fee_iqd IS NOT NULL AND driver_earning_iqd IS NOT NULL
      AND delivery_fee_iqd >= driver_earning_iqd AND driver_earning_iqd>=0),0)::bigint AS delivery_commissions
  FROM delivered GROUP BY branch_id
 ), payroll_sums AS (
  SELECT branch_id, sum(salary_amount_iqd)::bigint AS salary_accrued
  FROM public.barq_driver_payroll_months_v33 WHERE salary_month=p_month GROUP BY branch_id
 ), payroll_paid_total AS (
  SELECT pm.branch_id,sum(pay.amount_iqd)::bigint AS paid_against_this_month
  FROM public.barq_driver_payroll_months_v33 pm
  JOIN public.barq_driver_salary_payments_v33 pay ON pay.payroll_id=pm.id
  WHERE pm.salary_month=p_month GROUP BY pm.branch_id
 ), salary_cash AS (
  SELECT pm.branch_id, sum(pay.amount_iqd)::bigint AS salary_paid_cash
  FROM public.barq_driver_salary_payments_v33 pay
  JOIN public.barq_driver_payroll_months_v33 pm ON pm.id=pay.payroll_id
  WHERE date_trunc('month',(pay.paid_at AT TIME ZONE 'Asia/Baghdad'))::date=p_month
  GROUP BY pm.branch_id
 ), expenses_sums AS (
  SELECT branch_id,sum(amount_iqd)::bigint AS operating_cost
  FROM public.barq_finance_expenses_v34
  WHERE expense_date>=p_month AND expense_date<(p_month+interval '1 month')::date
    AND voided_at IS NULL
  GROUP BY branch_id
 ), cash_movements AS (
  SELECT COALESCE(o.destination_branch_id,
     (SELECT MIN(b.id) FROM public.barq_branches b
      WHERE b.governorate=o.delivery_governorate HAVING count(*)=1)) AS branch_id,
     COALESCE(sum(s.amount_iqd) FILTER(WHERE s.movement_type='driver_remittance'),0)::bigint AS driver_collections,
     COALESCE(sum(s.amount_iqd) FILTER(WHERE s.movement_type='merchant_payout'),0)::bigint AS merchant_payments
  FROM public.delivery_settlements s JOIN public.orders o ON o.id=s.order_id
  WHERE date_trunc('month',(s.created_at AT TIME ZONE 'Asia/Baghdad'))::date=p_month
  GROUP BY 1
 )
 SELECT coalesce(jsonb_agg(jsonb_build_object(
     'branch_id',bc.id,'code',bc.code,'name',bc.name,'governorate',bc.governorate,
     'delivered_count',coalesce(ds.delivered_count,0),
     'incomplete_count',coalesce(ds.incomplete_count,0),
     'approximate_date_count',coalesce(ds.approximate_date_count,0),
     'fee_revenue',coalesce(ds.fee_revenue,0),
     'delivery_commissions',coalesce(ds.delivery_commissions,0),
     'salary_accrued',coalesce(ps.salary_accrued,0),
     'salary_paid_against_month',coalesce(ppt.paid_against_this_month,0),
     'operating_cost',coalesce(es.operating_cost,0),
     'estimated_operating_result',coalesce(ds.fee_revenue,0)-coalesce(ds.delivery_commissions,0)-coalesce(ps.salary_accrued,0)-coalesce(es.operating_cost,0),
     'cash_driver_collections',coalesce(cm.driver_collections,0),
     'cash_merchant_payments',coalesce(cm.merchant_payments,0),
     'cash_salary_payments',coalesce(sc.salary_paid_cash,0)
   ) ORDER BY bc.code),'[]'::jsonb) INTO v_branches
 FROM branch_catalog bc
 LEFT JOIN delivery_sums ds ON ds.branch_id IS NOT DISTINCT FROM bc.id
 LEFT JOIN payroll_sums ps ON ps.branch_id IS NOT DISTINCT FROM bc.id
 LEFT JOIN payroll_paid_total ppt ON ppt.branch_id IS NOT DISTINCT FROM bc.id
 LEFT JOIN salary_cash sc ON sc.branch_id IS NOT DISTINCT FROM bc.id
 LEFT JOIN expenses_sums es ON es.branch_id IS NOT DISTINCT FROM bc.id
 LEFT JOIN cash_movements cm ON cm.branch_id IS NOT DISTINCT FROM bc.id;

 SELECT coalesce(jsonb_agg(jsonb_build_object(
   'id',t.id,'branch_id',t.branch_id,'branch_name',coalesce(b.name,'المركز / بدون فرع'),
   'expense_date',t.expense_date,'category',t.category,'amount_iqd',t.amount_iqd,
   'description',t.description,'voided_at',t.voided_at,'void_reason',t.void_reason,
   'created_at',t.created_at
 ) ORDER BY t.expense_date DESC,t.created_at DESC),'[]'::jsonb)
 INTO v_expenses
 FROM (SELECT * FROM public.barq_finance_expenses_v34
       WHERE expense_date>=p_month AND expense_date<(p_month+interval '1 month')::date
       ORDER BY expense_date DESC,created_at DESC LIMIT 150) t
 LEFT JOIN public.barq_branches b ON b.id=t.branch_id;
 RETURN jsonb_build_object('month',to_char(p_month,'YYYY-MM'),
   'branches',coalesce(v_branches,'[]'::jsonb),
   'expenses',coalesce(v_expenses,'[]'::jsonb),
   'expense_list_limit',150,
   'notes','التقرير إداري تقديري: تواريخ التسليم القديمة قد تعتمد على آخر تحديث للطلب، والأرباح لا تشمل كل الالتزامات غير المسجلة');
END;
$fn$;

REVOKE ALL ON FUNCTION public.barq_admin_add_expense_v34(uuid,date,text,bigint,text,uuid) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.barq_admin_void_expense_v34(uuid,text) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.barq_admin_financial_report_v34(date) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.barq_admin_add_expense_v34(uuid,date,text,bigint,text,uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_void_expense_v34(uuid,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_financial_report_v34(date) TO authenticated;
COMMIT;

-- Read-only checks: should return four true values.
SELECT
 to_regclass('public.barq_finance_expenses_v34') IS NOT NULL AS expenses_ready,
 to_regprocedure('public.barq_admin_add_expense_v34(uuid,date,text,bigint,text,uuid)') IS NOT NULL AS add_ready,
 to_regprocedure('public.barq_admin_void_expense_v34(uuid,text)') IS NOT NULL AS void_ready,
 to_regprocedure('public.barq_admin_financial_report_v34(date)') IS NOT NULL AS report_ready;
