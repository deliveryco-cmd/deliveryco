-- BARQ V27 | Baghdad origin warehouse -> Basra destination warehouse
-- Apply AFTER V26 (and the existing V22 branch-transfer tables) in Supabase SQL Editor.
-- Non-destructive. Does not alter old transfer functions, orders, drivers or financial settlements.
-- V27 transactions deliberately record three *different* physical events:
--  prepared: parcel remains in Baghdad warehouse
--  in_transit: Baghdad manager has physically handed parcel to transport
--  received: Basra authorized staff/admin confirms physical receipt + shelf
-- IMPORTANT: this does not complete the final-mile delivery or collect funds.

CREATE OR REPLACE FUNCTION public.barq_v27_is_bgd_manager()
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = ''
AS $$
 SELECT auth.uid() IS NOT NULL
 AND EXISTS (
  SELECT 1 FROM public.profiles p
  JOIN public.barq_branch_staff s ON s.user_id=p.id
  JOIN public.barq_branches b ON b.id=s.branch_id
  WHERE p.id=auth.uid() AND p.role IN ('branch_manage','branch_manager')
    AND s.branch_role IN ('branch_manage','branch_manager')
    AND s.is_active IS TRUE AND b.is_active IS TRUE AND b.code='BGD'
 )
 AND (
  SELECT count(*) FROM public.barq_branch_staff s
  JOIN public.barq_branches b ON b.id=s.branch_id
  WHERE s.user_id=auth.uid() AND s.is_active IS TRUE AND b.is_active IS TRUE
    AND s.branch_role IN ('branch_manage','branch_manager')
 )=1;
$$;

CREATE OR REPLACE FUNCTION public.barq_v27_can_receive_bas()
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = ''
AS $$
 SELECT auth.uid() IS NOT NULL AND (
  EXISTS (SELECT 1 FROM public.profiles p WHERE p.id=auth.uid() AND p.role='admin')
  OR (
   EXISTS (
    SELECT 1 FROM public.profiles p
    JOIN public.barq_branch_staff s ON s.user_id=p.id
    JOIN public.barq_branches b ON b.id=s.branch_id
    WHERE p.id=auth.uid() AND p.role IN ('branch_manage','branch_manager')
      AND s.branch_role IN ('branch_manage','branch_manager')
      AND s.is_active IS TRUE AND b.is_active IS TRUE AND b.code='BAS'
   ) AND (
    SELECT count(*) FROM public.barq_branch_staff s
    JOIN public.barq_branches b ON b.id=s.branch_id
    WHERE s.user_id=auth.uid() AND s.is_active IS TRUE AND b.is_active IS TRUE
      AND s.branch_role IN ('branch_manage','branch_manager')
   )=1
  )
 );
$$;

-- Authenticated Baghdad manager: parcel list and current transfer status.
CREATE OR REPLACE FUNCTION public.barq_branch_outbound_v27()
RETURNS TABLE (
 order_id uuid, receipt_code text, customer_name text,
 destination_governorate text, warehouse_shelf text,
 transfer_id uuid, transfer_status text,
 transport_name text, transport_reference text
)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
BEGIN
 IF NOT public.barq_v27_is_bgd_manager() THEN
  RAISE EXCEPTION 'ممنوع: هذا الإجراء خاص بمدير فرع بغداد الفعال' USING ERRCODE='42501';
 END IF;
 RETURN QUERY
 SELECT r.order_id, o.receipt_code, o.customer_name,
        o.delivery_governorate, wi.shelf,
        t.id, t.transfer_status, t.transport_name, t.transport_reference
 FROM public.barq_order_routes r
 JOIN public.orders o ON o.id=r.order_id
 JOIN public.merchants m ON m.id=o.merchant_id
 JOIN public.barq_branches b ON b.id=coalesce(o.origin_branch_id,m.branch_id)
 JOIN public.barq_branches dest ON dest.code='BAS' AND dest.is_active IS TRUE
 LEFT JOIN LATERAL (
   SELECT w.shelf,w.branch_id,w.status
   FROM public.barq_warehouse_items w
   WHERE w.order_id=o.id AND w.branch_id=b.id
   ORDER BY w.received_at DESC LIMIT 1
 ) wi ON TRUE
 LEFT JOIN LATERAL (
   SELECT tr.id, tr.transfer_status, tr.transport_name,tr.transport_reference
   FROM public.barq_branch_transfers tr
   WHERE tr.order_id=o.id AND tr.from_branch_id=b.id
     AND tr.to_branch_id=dest.id AND tr.transfer_status<>'cancelled'
   ORDER BY tr.created_at DESC LIMIT 1
 ) t ON TRUE
 WHERE b.code='BGD' AND b.is_active IS TRUE
   AND o.delivery_governorate=dest.governorate
   AND (o.destination_branch_id IS NULL OR o.destination_branch_id=dest.id)
   AND o.status='picked_up'
   AND r.route_type='warehouse' AND r.stage='in_warehouse'
   AND ( (wi.branch_id=b.id AND wi.status='stored') OR t.id IS NOT NULL )
 ORDER BY r.updated_at DESC LIMIT 200;
END;
$$;

-- Step 1: Prepare, but do NOT mark parcel dispatched yet.
CREATE OR REPLACE FUNCTION public.barq_branch_prepare_to_bas_v27(p_order_id uuid)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
DECLARE
 v_bgd uuid; v_bas uuid; v_bas_gov text; v_from uuid; v_dest_branch uuid;
 v_item uuid; v_stage text; v_route text; v_order_status text; v_governorate text;
 v_item_status text; v_item_branch uuid; v_item_order uuid; v_transfer uuid;
BEGIN
 IF NOT public.barq_v27_is_bgd_manager() THEN
  RAISE EXCEPTION 'فقط مدير بغداد الفعّال يجهز هذا التحويل' USING ERRCODE='42501';
 END IF;
 IF p_order_id IS NULL THEN RAISE EXCEPTION 'الطلب مطلوب' USING ERRCODE='22023'; END IF;
 SELECT b.id INTO STRICT v_bgd FROM public.barq_branches b WHERE b.code='BGD' AND b.is_active IS TRUE;
 SELECT b.id,b.governorate INTO STRICT v_bas,v_bas_gov FROM public.barq_branches b WHERE b.code='BAS' AND b.is_active IS TRUE;
 SELECT r.warehouse_item_id,r.stage,r.route_type,o.status,
        coalesce(o.origin_branch_id,m.branch_id),o.destination_branch_id,o.delivery_governorate
 INTO v_item,v_stage,v_route,v_order_status,v_from,v_dest_branch,v_governorate
 FROM public.barq_order_routes r
 JOIN public.orders o ON o.id=r.order_id
 JOIN public.merchants m ON m.id=o.merchant_id
 WHERE r.order_id=p_order_id FOR UPDATE OF r,o;
 IF NOT FOUND OR v_from IS DISTINCT FROM v_bgd OR v_governorate IS DISTINCT FROM v_bas_gov
   OR (v_dest_branch IS NOT NULL AND v_dest_branch IS DISTINCT FROM v_bas)
   OR v_order_status IS DISTINCT FROM 'picked_up'
   OR v_route IS DISTINCT FROM 'warehouse' OR v_stage IS DISTINCT FROM 'in_warehouse'
   OR v_item IS NULL THEN
  RAISE EXCEPTION 'الطرد غير مؤهل: يجب أن يكون من بغداد للبصرة ومستلم فعلياً في مخزن بغداد' USING ERRCODE='23514';
 END IF;
 SELECT wi.status,wi.branch_id,wi.order_id INTO v_item_status,v_item_branch,v_item_order
 FROM public.barq_warehouse_items wi WHERE wi.id=v_item FOR UPDATE;
 IF NOT FOUND OR v_item_status IS DISTINCT FROM 'stored' OR v_item_branch IS DISTINCT FROM v_bgd OR v_item_order IS DISTINCT FROM p_order_id THEN
  RAISE EXCEPTION 'الطرد ليس محفوظاً حالياً بمخزن بغداد' USING ERRCODE='23514';
 END IF;
 IF EXISTS (
  SELECT 1 FROM public.barq_branch_transfers t
  WHERE t.order_id=p_order_id AND t.transfer_status<>'cancelled'
 ) THEN
  RAISE EXCEPTION 'هذا الطلب عنده تحويل فرعي غير ملغى؛ لا يمكن تكراره' USING ERRCODE='23505';
 END IF;
 INSERT INTO public.barq_branch_transfers
   (id,order_id,from_branch_id,to_branch_id,transfer_status,created_by,created_at,notes)
 VALUES (pg_catalog.gen_random_uuid(),p_order_id,v_bgd,v_bas,'prepared',auth.uid(),now(),'BARQ V27: تجهيز بغداد إلى البصرة')
 RETURNING id INTO v_transfer;
 RETURN v_transfer;
EXCEPTION WHEN no_data_found THEN
 RAISE EXCEPTION 'تأكد من وجود فرعي بغداد والبصرة وتفعيلهما' USING ERRCODE='23514';
 WHEN too_many_rows THEN
 RAISE EXCEPTION 'يوجد فرع مكرر بنفس الرمز؛ راجع الإدارة' USING ERRCODE='23514';
END;
$$;

-- Step 2: Transport must have physically received the parcel; mark BGD stock released.
CREATE OR REPLACE FUNCTION public.barq_branch_handover_to_bas_v27(
 p_transfer_id uuid, p_transport_name text, p_transport_reference text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
DECLARE
 v_order uuid; v_from uuid; v_to uuid; v_status text;
 v_bgd uuid; v_bas uuid; v_item uuid; v_stage text;
 v_item_branch uuid; v_item_status text; v_item_order uuid;
 v_name text := btrim(coalesce(p_transport_name,''));
 v_ref text := nullif(btrim(coalesce(p_transport_reference,'')),'');
BEGIN
 IF NOT public.barq_v27_is_bgd_manager() THEN
  RAISE EXCEPTION 'فقط مدير بغداد الفعال يستطيع تسليم الطرد للناقل' USING ERRCODE='42501';
 END IF;
 IF p_transfer_id IS NULL OR length(v_name) NOT BETWEEN 2 AND 120 OR length(coalesce(v_ref,''))>120 THEN
  RAISE EXCEPTION 'اسم الناقل أو رقم المرجع غير صالح' USING ERRCODE='22023';
 END IF;
 SELECT b.id INTO STRICT v_bgd FROM public.barq_branches b WHERE b.code='BGD' AND b.is_active IS TRUE;
 SELECT b.id INTO STRICT v_bas FROM public.barq_branches b WHERE b.code='BAS' AND b.is_active IS TRUE;
 SELECT t.order_id,t.from_branch_id,t.to_branch_id,t.transfer_status
 INTO v_order,v_from,v_to,v_status
 FROM public.barq_branch_transfers t WHERE t.id=p_transfer_id FOR UPDATE;
 IF NOT FOUND OR v_from IS DISTINCT FROM v_bgd OR v_to IS DISTINCT FROM v_bas OR v_status IS DISTINCT FROM 'prepared' THEN
  RAISE EXCEPTION 'هذا التحويل غير جاهز أو تم تسليمه مسبقاً' USING ERRCODE='23514';
 END IF;
 IF NOT EXISTS (
   SELECT 1 FROM public.orders o JOIN public.merchants m ON m.id=o.merchant_id
   JOIN public.barq_branches b ON b.id=coalesce(o.origin_branch_id,m.branch_id)
   JOIN public.barq_branches dest ON dest.id=v_bas
   WHERE o.id=v_order AND o.status='picked_up' AND o.delivery_governorate=dest.governorate
     AND b.id=v_bgd AND (o.destination_branch_id IS NULL OR o.destination_branch_id=v_bas)
 ) THEN
  RAISE EXCEPTION 'حالة الطلب أو محافظته تغيرت بعد تجهيز النقل؛ راجع الإدارة' USING ERRCODE='23514';
 END IF;
 SELECT r.warehouse_item_id,r.stage INTO v_item,v_stage
 FROM public.barq_order_routes r WHERE r.order_id=v_order AND r.route_type='warehouse' FOR UPDATE;
 IF NOT FOUND OR v_stage IS DISTINCT FROM 'in_warehouse' OR v_item IS NULL THEN
  RAISE EXCEPTION 'حالة مخزن الطلب غير صحيحة' USING ERRCODE='23514';
 END IF;
 SELECT wi.branch_id,wi.status,wi.order_id INTO v_item_branch,v_item_status,v_item_order
 FROM public.barq_warehouse_items wi WHERE wi.id=v_item FOR UPDATE;
 IF NOT FOUND OR v_item_branch IS DISTINCT FROM v_bgd OR v_item_status IS DISTINCT FROM 'stored' OR v_item_order IS DISTINCT FROM v_order THEN
  RAISE EXCEPTION 'الطرد خرج من مخزن بغداد مسبقاً أو لم يسجّل فيه' USING ERRCODE='23514';
 END IF;
 UPDATE public.barq_warehouse_items SET status='released',released_at=now(),
   released_by=auth.uid(),receiver_name=v_name WHERE id=v_item;
 UPDATE public.barq_branch_transfers SET transfer_status='in_transit',
   transport_name=v_name,transport_reference=v_ref,
   handed_over_by=auth.uid(),handed_over_at=now()
 WHERE id=p_transfer_id;
 -- Route retains its original warehouse item until destination receipt.
 -- barq_branch_transfers is the authoritative in-transit record.
EXCEPTION WHEN no_data_found THEN
 RAISE EXCEPTION 'تأكد من تفعيل فرعي بغداد والبصرة' USING ERRCODE='23514';
 WHEN too_many_rows THEN
 RAISE EXCEPTION 'يوجد تكرار برمز الفرع؛ راجع الإدارة' USING ERRCODE='23514';
END;
$$;

-- Admin (or later an authorized Basra manager): incoming shipments. Restricted via RPC.
CREATE OR REPLACE FUNCTION public.barq_admin_incoming_bas_v27()
RETURNS TABLE (
 transfer_id uuid, order_id uuid, receipt_code text, customer_name text,
 goods_type text, transfer_status text, transport_name text,
 transport_reference text, handed_over_at timestamptz, received_at timestamptz
)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
BEGIN
 IF NOT public.barq_v27_can_receive_bas() THEN
  RAISE EXCEPTION 'غير مصرح بعرض شحنات مخزن البصرة' USING ERRCODE='42501';
 END IF;
 RETURN QUERY
 SELECT t.id,t.order_id,o.receipt_code,o.customer_name,o.goods_type,
        t.transfer_status,t.transport_name,t.transport_reference,
        t.handed_over_at,t.received_at
 FROM public.barq_branch_transfers t
 JOIN public.orders o ON o.id=t.order_id
 JOIN public.barq_branches b1 ON b1.id=t.from_branch_id
 JOIN public.barq_branches b2 ON b2.id=t.to_branch_id
 WHERE b1.code='BGD' AND b2.code='BAS'
   AND t.transfer_status IN ('in_transit','received')
 ORDER BY t.created_at DESC LIMIT 200;
END;
$$;

-- Step 3: Basra physically receives; receipt barcode must match before creating stock.
CREATE OR REPLACE FUNCTION public.barq_bas_receive_from_bgd_v27(
 p_transfer_id uuid, p_receipt_code text, p_shelf text, p_condition text DEFAULT 'good'
)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $$
DECLARE
 v_order uuid; v_from uuid; v_to uuid; v_state text;
 v_bgd uuid; v_bas uuid; v_bas_gov text;
 v_code text; v_customer_governorate text; v_order_status text;
 v_goods text; v_merchant uuid; v_item uuid; v_stage text; v_route text;
 v_old_item_order uuid; v_old_item_branch uuid; v_old_item_status text;
 v_new_item uuid;
 v_shelf text:=btrim(coalesce(p_shelf,''));
BEGIN
 IF NOT public.barq_v27_can_receive_bas() THEN
  RAISE EXCEPTION 'غير مصرح بتسجيل استلام مخزن البصرة' USING ERRCODE='42501';
 END IF;
 IF p_transfer_id IS NULL OR length(v_shelf) NOT BETWEEN 1 AND 100
   OR p_condition NOT IN ('good','damaged','unknown') OR p_condition IS NULL THEN
  RAISE EXCEPTION 'اختر التحويل والرف وحالة البضاعة' USING ERRCODE='22023';
 END IF;
 SELECT b.id INTO STRICT v_bgd FROM public.barq_branches b WHERE b.code='BGD';
 SELECT b.id,b.governorate INTO STRICT v_bas,v_bas_gov FROM public.barq_branches b
 WHERE b.code='BAS' AND b.is_active IS TRUE;
 SELECT t.order_id,t.from_branch_id,t.to_branch_id,t.transfer_status
 INTO v_order,v_from,v_to,v_state
 FROM public.barq_branch_transfers t WHERE t.id=p_transfer_id FOR UPDATE;
 IF NOT FOUND OR v_from IS DISTINCT FROM v_bgd OR v_to IS DISTINCT FROM v_bas OR v_state IS DISTINCT FROM 'in_transit' THEN
  RAISE EXCEPTION 'هذا التحويل ليس في الطريق إلى البصرة أو تم استلامه مسبقاً' USING ERRCODE='23514';
 END IF;
 SELECT o.receipt_code,o.delivery_governorate,o.status,o.goods_type,o.merchant_id
 INTO v_code,v_customer_governorate,v_order_status,v_goods,v_merchant
 FROM public.orders o WHERE o.id=v_order FOR UPDATE;
 IF NOT FOUND OR v_customer_governorate IS DISTINCT FROM v_bas_gov OR v_order_status IS DISTINCT FROM 'picked_up' THEN
  RAISE EXCEPTION 'حالة الطلب أو وجهته غير صحيحة، راجع الإدارة' USING ERRCODE='23514';
 END IF;
 -- Original QR values are receipt_code text. If missing, order UUID can be used manually.
 IF btrim(coalesce(p_receipt_code,'')) IS DISTINCT FROM coalesce(nullif(btrim(v_code),''),v_order::text) THEN
  RAISE EXCEPTION 'رمز وصل الطرد غير مطابق لهذا التحويل؛ لا تستلم طرداً آخر بالخطأ' USING ERRCODE='23514';
 END IF;
 SELECT r.warehouse_item_id,r.stage,r.route_type INTO v_item,v_stage,v_route
 FROM public.barq_order_routes r WHERE r.order_id=v_order FOR UPDATE;
 IF NOT FOUND OR v_item IS NULL OR v_route IS DISTINCT FROM 'warehouse' OR v_stage IS DISTINCT FROM 'in_warehouse' THEN
  RAISE EXCEPTION 'مسار الطلب غير صحيح أو غير مرتبط بمخزن بغداد' USING ERRCODE='23514';
 END IF;
 SELECT wi.order_id,wi.branch_id,wi.status
 INTO v_old_item_order,v_old_item_branch,v_old_item_status
 FROM public.barq_warehouse_items wi WHERE wi.id=v_item FOR UPDATE;
 IF NOT FOUND OR v_old_item_order IS DISTINCT FROM v_order OR v_old_item_branch IS DISTINCT FROM v_bgd OR v_old_item_status IS DISTINCT FROM 'released' THEN
  RAISE EXCEPTION 'الطرد لم يخرج رسمياً من مخزن بغداد' USING ERRCODE='23514';
 END IF;
 IF EXISTS (SELECT 1 FROM public.barq_warehouse_items wi WHERE wi.order_id=v_order AND wi.branch_id=v_bas) THEN
  RAISE EXCEPTION 'هذا الطلب سبق تسجيله في مخزن البصرة' USING ERRCODE='23505';
 END IF;
 INSERT INTO public.barq_warehouse_items
  (id,order_id,branch_id,merchant_id,description,quantity,shelf,condition,status,notes,received_at,received_by)
 VALUES
  (pg_catalog.gen_random_uuid(),v_order,v_bas,v_merchant,coalesce(nullif(v_goods,''),'طرد'),1,
   v_shelf,p_condition,'stored','استلام تحويل من بغداد إلى البصرة | BARQ V27',now(),auth.uid())
 RETURNING id INTO v_new_item;
 -- Route now points to *current* warehouse item at destination.
 UPDATE public.barq_order_routes SET warehouse_item_id=v_new_item,updated_at=now()
 WHERE order_id=v_order;
 UPDATE public.barq_branch_transfers
 SET transfer_status='received',received_by=auth.uid(),received_at=now(),
     received_warehouse_item_id=v_new_item
 WHERE id=p_transfer_id;
 RETURN v_new_item;
EXCEPTION WHEN no_data_found THEN
 RAISE EXCEPTION 'فرع بغداد أو البصرة غير موجود أو البصرة غير فعالة' USING ERRCODE='23514';
 WHEN too_many_rows THEN
 RAISE EXCEPTION 'تكرار فرع بنفس الرمز؛ راجع الإدارة' USING ERRCODE='23514';
END;
$$;

-- All functions are guarded by database role + live branch authorization, not by hidden UI buttons.
REVOKE ALL ON FUNCTION public.barq_v27_is_bgd_manager() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.barq_v27_can_receive_bas() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.barq_branch_outbound_v27() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.barq_branch_prepare_to_bas_v27(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.barq_branch_handover_to_bas_v27(uuid,text,text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.barq_admin_incoming_bas_v27() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.barq_bas_receive_from_bgd_v27(uuid,text,text,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.barq_branch_outbound_v27() TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_branch_prepare_to_bas_v27(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_branch_handover_to_bas_v27(uuid,text,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_incoming_bas_v27() TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_bas_receive_from_bgd_v27(uuid,text,text,text) TO authenticated;
-- Helper functions are called internally by privileged RPCs.

-- Verification only. Run after migration, should return all TRUE.
SELECT
  to_regprocedure('public.barq_branch_outbound_v27()') IS NOT NULL AS outbound_ready,
  to_regprocedure('public.barq_branch_prepare_to_bas_v27(uuid)') IS NOT NULL AS prepare_ready,
  to_regprocedure('public.barq_branch_handover_to_bas_v27(uuid,text,text)') IS NOT NULL AS handover_ready,
  to_regprocedure('public.barq_admin_incoming_bas_v27()') IS NOT NULL AS basra_list_ready,
  to_regprocedure('public.barq_bas_receive_from_bgd_v27(uuid,text,text,text)') IS NOT NULL AS basra_receive_ready;
