-- BARQ V36: username / Iraqi phone aliases for driver password sign-in.
-- Apply AFTER V35. Does not edit Auth passwords, orders, rates, barcodes, or historical data.
BEGIN;

CREATE TABLE IF NOT EXISTS public.barq_driver_login_aliases_v36 (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE,
  phone_e164 text UNIQUE,
  updated_by uuid REFERENCES auth.users(id),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT barq_v36_username_format CHECK (username IS NULL OR username ~ '^[a-z][a-z0-9_]{3,23}$'),
  CONSTRAINT barq_v36_phone_format CHECK (phone_e164 IS NULL OR phone_e164 ~ '^[+]9647[0-9]{9}$')
);
ALTER TABLE public.barq_driver_login_aliases_v36 ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.barq_driver_login_aliases_v36 FROM PUBLIC, anon, authenticated;
GRANT SELECT ON public.barq_driver_login_aliases_v36 TO service_role;

-- Fill unique valid Iraqi mobile numbers already recorded in driver profiles;
-- do not invent usernames for existing drivers.
WITH phones AS (
 SELECT d.user_id,
   CASE
     WHEN regexp_replace(coalesce(p.phone,''),'[^0-9]','','g') ~ '^07[0-9]{9}$'
       THEN '+964'||substring(regexp_replace(p.phone,'[^0-9]','','g') from 2)
     WHEN regexp_replace(coalesce(p.phone,''),'[^0-9]','','g') ~ '^9647[0-9]{9}$'
       THEN '+'||regexp_replace(p.phone,'[^0-9]','','g')
     WHEN regexp_replace(coalesce(p.phone,''),'[^0-9]','','g') ~ '^009647[0-9]{9}$'
       THEN '+'||substring(regexp_replace(p.phone,'[^0-9]','','g') from 3)
     ELSE NULL END AS normalized
 FROM public.drivers d JOIN public.profiles p ON p.id=d.user_id
), unique_phones AS (
 SELECT user_id,normalized FROM phones WHERE normalized IS NOT NULL
 AND normalized IN (SELECT normalized FROM phones WHERE normalized IS NOT NULL GROUP BY normalized HAVING count(*)=1)
)
INSERT INTO public.barq_driver_login_aliases_v36(user_id,phone_e164)
SELECT user_id,normalized FROM unique_phones
ON CONFLICT (user_id) DO NOTHING;

CREATE OR REPLACE FUNCTION public.barq_admin_set_driver_alias_v36(
  p_user_id uuid, p_username text, p_phone text DEFAULT NULL
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $fn$
DECLARE v_username text; v_digits text; v_phone text;
BEGIN
  IF NOT EXISTS(SELECT 1 FROM public.profiles WHERE id=auth.uid() AND role='admin') THEN
    RAISE EXCEPTION 'هذا الإجراء للمدير العام فقط' USING ERRCODE='42501';
  END IF;
  IF NOT EXISTS(SELECT 1 FROM public.drivers d JOIN public.profiles p ON p.id=d.user_id
                WHERE d.user_id=p_user_id AND p.role='driver') THEN
    RAISE EXCEPTION 'حساب المندوب غير موجود';
  END IF;
  v_username:=lower(btrim(coalesce(p_username,'')));
  IF v_username !~ '^[a-z][a-z0-9_]{3,23}$' THEN
    RAISE EXCEPTION 'اليوزرنيم 4-24 حرفاً: أحرف إنجليزية صغيرة وأرقام و _؛ يبدأ بحرف';
  END IF;
  v_digits:=regexp_replace(coalesce(p_phone,''),'[^0-9]','','g');
  IF v_digits='' THEN
    -- Keep an existing phone when the admin leaves the field empty.
    SELECT phone_e164 INTO v_phone FROM public.barq_driver_login_aliases_v36 WHERE user_id=p_user_id;
  ELSIF v_digits ~ '^07[0-9]{9}$' THEN
    v_phone:='+964'||substring(v_digits from 2);
  ELSIF v_digits ~ '^9647[0-9]{9}$' THEN
    v_phone:='+'||v_digits;
  ELSIF v_digits ~ '^009647[0-9]{9}$' THEN
    v_phone:='+'||substring(v_digits from 3);
  ELSE
    RAISE EXCEPTION 'رقم الهاتف يجب أن يكون عراقياً وبالصيغة 07XXXXXXXXX';
  END IF;
  INSERT INTO public.barq_driver_login_aliases_v36(user_id,username,phone_e164,updated_by,updated_at)
  VALUES (p_user_id,v_username,v_phone,auth.uid(),now())
  ON CONFLICT (user_id) DO UPDATE SET
     username=EXCLUDED.username, phone_e164=EXCLUDED.phone_e164,
     updated_by=EXCLUDED.updated_by, updated_at=now();
EXCEPTION WHEN unique_violation THEN
  RAISE EXCEPTION 'اسم المستخدم أو رقم الهاتف مستخدم عند مندوب آخر';
END;
$fn$;
REVOKE ALL ON FUNCTION public.barq_admin_set_driver_alias_v36(uuid,text,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_set_driver_alias_v36(uuid,text,text) TO authenticated;

CREATE OR REPLACE FUNCTION public.barq_admin_driver_aliases_v36()
RETURNS TABLE(user_id uuid, username text, phone_e164 text)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path='' AS $fn$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM public.profiles WHERE id=auth.uid() AND role='admin') THEN
   RAISE EXCEPTION 'غير مصرح' USING ERRCODE='42501';
 END IF;
 RETURN QUERY SELECT a.user_id,a.username,a.phone_e164
              FROM public.barq_driver_login_aliases_v36 a
              JOIN public.drivers d ON d.user_id=a.user_id;
END;$fn$;
REVOKE ALL ON FUNCTION public.barq_admin_driver_aliases_v36() FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_driver_aliases_v36() TO authenticated;

CREATE TABLE IF NOT EXISTS public.barq_v36_login_attempts (
 fingerprint text PRIMARY KEY CHECK (fingerprint ~ '^[a-f0-9]{64}$'),
 window_started timestamptz NOT NULL DEFAULT now(),
 attempts integer NOT NULL DEFAULT 0
);
ALTER TABLE public.barq_v36_login_attempts ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.barq_v36_login_attempts FROM PUBLIC,anon,authenticated;

CREATE OR REPLACE FUNCTION public.barq_v36_login_rate_limit(p_fingerprint text,p_limit integer)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $fn$
DECLARE v_attempts integer;
BEGIN
 -- Access is restricted by REVOKE/GRANT to service_role.
 IF p_fingerprint !~ '^[a-f0-9]{64}$' OR p_limit NOT BETWEEN 1 AND 100 THEN RETURN false; END IF;
 INSERT INTO public.barq_v36_login_attempts AS a(fingerprint,window_started,attempts)
 VALUES(p_fingerprint,now(),1)
 ON CONFLICT (fingerprint) DO UPDATE SET
   window_started=CASE WHEN a.window_started < now()-interval '15 minutes' THEN now() ELSE a.window_started END,
   attempts=CASE WHEN a.window_started < now()-interval '15 minutes' THEN 1 ELSE a.attempts+1 END
 RETURNING attempts INTO v_attempts;
 RETURN v_attempts<=p_limit;
END;$fn$;
REVOKE ALL ON FUNCTION public.barq_v36_login_rate_limit(text,integer) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.barq_v36_login_rate_limit(text,integer) TO service_role;

COMMIT;

SELECT
 to_regclass('public.barq_driver_login_aliases_v36') IS NOT NULL AS aliases_ready,
 to_regprocedure('public.barq_admin_set_driver_alias_v36(uuid,text,text)') IS NOT NULL AS save_ready,
 to_regprocedure('public.barq_admin_driver_aliases_v36()') IS NOT NULL AS list_ready,
 to_regprocedure('public.barq_v36_login_rate_limit(text,integer)') IS NOT NULL AS limiter_ready;
