BARQ V43: Merchant login by username / Iraqi phone / email + driver email per account.
1. Backup Supabase. Run 01-barq-v43-merchant-login-driver-emails.sql.
2. Create and deploy Edge Function barq-merchant-login-v43 from supabase/functions/barq-merchant-login-v43/index.ts; TURN OFF Verify JWT for this login endpoint only.
3. Publish entire V43 ZIP to Cloudflare Pages.
4. In admin > Shops > Login details, set unique usernames and verified login phones for pre-existing shop owner accounts.
5. Test new shop creation; then merchant login with email, username and phone using same password.
6. In admin > Drivers, confirm the email column shows each driver's own Auth email.
IMPORTANT: Do not put secret/service_role keys in browser files. Don't create a second Auth user if creating a new shop partially succeeds. Phone numbers used for LOGIN must uniquely identify each owner account; shared shop numbers cannot serve as login phone for multiple owners.
Notes: deploy SQL and Edge Function before new website; V42 operations/barcodes/rates/branches stay untouched.
