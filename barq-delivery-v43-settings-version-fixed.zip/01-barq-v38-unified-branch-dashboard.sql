-- BARQ V38: Unified read-only branch dashboard for all governorates.
-- Run after the V37 branch manager account has been created and assigned.
-- Does not delete or change existing orders, staff, profiles or permissions.
-- SECURITY: Functions deliberately scope every query to the signed-in manager's branch.

BEGIN;

CREATE OR REPLACE FUNCTION public.barq_v38_branch_context()
RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path = ''
AS $body$
DECLARE
  v_role text;
  v_active_branches integer;
  v_branch record;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'تسجيل الدخول مطلوب' USING ERRCODE = '42501';
  END IF;

  SELECT p.role INTO v_role FROM public.profiles p WHERE p.id = auth.uid();
  IF v_role IS NULL OR v_role NOT IN ('branch_manage','branch_manager') THEN
    RAISE EXCEPTION 'هذا التطبيق مخصص لمدير الفرع فقط' USING ERRCODE = '42501';
  END IF;

  SELECT count(DISTINCT s.branch_id) INTO v_active_branches
  FROM public.barq_branch_staff s
  WHERE s.user_id = auth.uid()
    AND s.branch_role IN ('branch_manage','branch_manager')
    AND s.is_active IS TRUE;
  IF v_active_branches > 1 THEN
    RAISE EXCEPTION 'الحساب مربوط بأكثر من فرع فعال. راجع المدير العام' USING ERRCODE = '42501';
  END IF;

  SELECT b.id, b.code, b.name, b.governorate, b.is_active,
         s.is_active AS staff_active
  INTO v_branch
  FROM public.barq_branch_staff s
  JOIN public.barq_branches b ON b.id = s.branch_id
  WHERE s.user_id = auth.uid()
    AND s.branch_role IN ('branch_manage','branch_manager')
  ORDER BY s.is_active DESC, s.assigned_at DESC NULLS LAST
  LIMIT 1;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'حسابك غير مربوط بأي فرع. راجع المدير العام' USING ERRCODE = '42501';
  END IF;

  RETURN pg_catalog.jsonb_build_object(
    'id',v_branch.id,'code',v_branch.code,'name',v_branch.name,
    'governorate',v_branch.governorate,'is_active',v_branch.is_active,
    'staff_active',v_branch.staff_active
  );
END;
$body$;

CREATE OR REPLACE FUNCTION public.barq_v38_branch_dashboard()
RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path = ''
AS $body$
DECLARE
  v_context jsonb;
  v_branch_id uuid;
BEGIN
  v_context := public.barq_v38_branch_context();
  IF coalesce((v_context->>'is_active')::boolean,false) IS NOT TRUE
     OR coalesce((v_context->>'staff_active')::boolean,false) IS NOT TRUE THEN
    RAISE EXCEPTION 'الفرع أو عضوية المدير غير فعالة' USING ERRCODE = '42501';
  END IF;
  v_branch_id := (v_context->>'id')::uuid;

  RETURN pg_catalog.jsonb_build_object(
    'branch',v_context,
    'stats',pg_catalog.jsonb_build_object(
      'drivers',(SELECT count(*) FROM public.drivers d WHERE d.branch_id=v_branch_id),
      'merchants',(SELECT count(*) FROM public.merchants m WHERE m.branch_id=v_branch_id),
      'orders',(SELECT count(*) FROM public.orders o WHERE o.origin_branch_id=v_branch_id OR o.destination_branch_id=v_branch_id),
      'warehouse',(SELECT coalesce(sum(greatest(w.quantity,0)),0) FROM public.barq_warehouse_items w WHERE w.branch_id=v_branch_id AND w.status='stored'),
      'in_transit',(SELECT count(*) FROM public.barq_branch_transfers t WHERE t.to_branch_id=v_branch_id AND t.transfer_status='in_transit')
    ),
    'drivers',(
      SELECT coalesce(pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
        'name',x.full_name,'phone',x.phone,'vehicle_type',x.vehicle_type,
        'is_active',x.is_active,'is_available',x.is_available
      )), '[]'::jsonb)
      FROM (SELECT p.full_name,p.phone,d.vehicle_type,d.is_active,d.is_available
            FROM public.drivers d LEFT JOIN public.profiles p ON p.id=d.user_id
            WHERE d.branch_id=v_branch_id ORDER BY d.created_at DESC NULLS LAST LIMIT 100) x
    ),
    'merchants',(
      SELECT coalesce(pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
        'name',x.name,'phone',x.phone,'address',x.address,'is_active',x.is_active
      )), '[]'::jsonb)
      FROM (SELECT m.name,m.phone,m.address,m.is_active
            FROM public.merchants m WHERE m.branch_id=v_branch_id
            ORDER BY m.created_at DESC NULLS LAST LIMIT 100) x
    ),
    'orders',(
      SELECT coalesce(pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
        'receipt_code',x.receipt_code,'order_id',x.id,'customer_name',x.customer_name,
        'status',x.status,'goods_type',x.goods_type,'delivery_governorate',x.delivery_governorate,
        'direction',CASE WHEN x.origin_branch_id=v_branch_id THEN 'outgoing' ELSE 'incoming' END,
        'created_at',x.created_at
      )), '[]'::jsonb)
      FROM (SELECT o.id,o.receipt_code,o.customer_name,o.status,o.goods_type,
                   o.delivery_governorate,o.origin_branch_id,o.created_at
            FROM public.orders o
            WHERE o.origin_branch_id=v_branch_id OR o.destination_branch_id=v_branch_id
            ORDER BY o.created_at DESC NULLS LAST LIMIT 100) x
    ),
    'transfers',(
      SELECT coalesce(pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
        'order_id',x.order_id,'receipt_code',x.receipt_code,
        'transfer_status',x.transfer_status,'transport_name',x.transport_name,
        'transport_reference',x.transport_reference,'created_at',x.created_at,
        'direction',CASE WHEN x.to_branch_id=v_branch_id THEN 'incoming' ELSE 'outgoing' END
      )), '[]'::jsonb)
      FROM (SELECT t.order_id,t.to_branch_id,t.transfer_status,t.transport_name,
                   t.transport_reference,t.created_at,o.receipt_code
            FROM public.barq_branch_transfers t
            LEFT JOIN public.orders o ON o.id=t.order_id
            WHERE t.from_branch_id=v_branch_id OR t.to_branch_id=v_branch_id
            ORDER BY t.created_at DESC NULLS LAST LIMIT 100) x
    ),
    'warehouse',(
      SELECT coalesce(pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
        'description',x.description,'quantity',x.quantity,'shelf',x.shelf,
        'status',x.status,'received_at',x.received_at
      )), '[]'::jsonb)
      FROM (SELECT w.description,w.quantity,w.shelf,w.status,w.received_at
            FROM public.barq_warehouse_items w WHERE w.branch_id=v_branch_id
            ORDER BY w.received_at DESC NULLS LAST LIMIT 100) x
    )
  );
END;
$body$;

REVOKE ALL ON FUNCTION public.barq_v38_branch_context() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.barq_v38_branch_dashboard() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.barq_v38_branch_context() TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_v38_branch_dashboard() TO authenticated;

COMMIT;

SELECT
  to_regprocedure('public.barq_v38_branch_context()') IS NOT NULL AS context_ready,
  to_regprocedure('public.barq_v38_branch_dashboard()') IS NOT NULL AS dashboard_ready;

-- Public directory: names/codes of active branches only; never exposes customer/employee data.
BEGIN;
CREATE OR REPLACE FUNCTION public.barq_v38_public_branches()
RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = ''
AS $function$
 SELECT coalesce(pg_catalog.jsonb_agg(pg_catalog.jsonb_build_object(
   'code', q.code, 'name', q.name, 'governorate', q.governorate
 ) ORDER BY q.code), '[]'::jsonb)
 FROM (
   SELECT b.code,b.name,b.governorate
   FROM public.barq_branches b
   WHERE b.is_active IS TRUE
   ORDER BY b.created_at NULLS LAST, b.code
 ) q;
$function$;
REVOKE ALL ON FUNCTION public.barq_v38_public_branches() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.barq_v38_public_branches() TO anon, authenticated;
COMMIT;

SELECT
 to_regprocedure('public.barq_v38_branch_context()') IS NOT NULL AS branch_context_ready,
 to_regprocedure('public.barq_v38_branch_dashboard()') IS NOT NULL AS branch_dashboard_ready,
 to_regprocedure('public.barq_v38_public_branches()') IS NOT NULL AS branch_list_ready;
