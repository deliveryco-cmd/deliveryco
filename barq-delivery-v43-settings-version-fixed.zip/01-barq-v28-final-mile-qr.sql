-- BARQ V28 | Basra final-mile courier + receipt QR delivery confirmation
-- Install after V26 and V27. Run ONCE in Supabase SQL Editor after a database backup.
-- All mutations run through role-checked SECURITY DEFINER RPCs; parcel history stays available.
-- Order.driver_id points to final courier only when Basra warehouse physically hands over;
-- original Baghdad courier remains in barq_order_routes.driver_id and original_driver_id below.
-- Do NOT treat scanning parcel label as independent proof of recipient identity.

CREATE TABLE IF NOT EXISTS public.barq_last_mile_v28 (
 order_id uuid PRIMARY KEY REFERENCES public.orders(id) ON DELETE RESTRICT,
 branch_id uuid NOT NULL REFERENCES public.barq_branches(id),
 warehouse_item_id uuid NOT NULL REFERENCES public.barq_warehouse_items(id),
 driver_id uuid NOT NULL REFERENCES public.drivers(id),
 original_driver_id uuid REFERENCES public.drivers(id),
 state text NOT NULL DEFAULT 'assigned' CHECK (state IN ('assigned','out_for_delivery','delivered')),
 assigned_by uuid NOT NULL,
 assigned_at timestamptz NOT NULL DEFAULT now(),
 handed_over_by uuid,
 handed_over_at timestamptz,
 delivered_at timestamptz,
 delivered_by uuid,
 matched_receipt_code text,
 recipient_handover_confirmed boolean NOT NULL DEFAULT false,
 CONSTRAINT barq_last_mile_v28_state_dates CHECK (
   (state='assigned' AND handed_over_at IS NULL AND delivered_at IS NULL)
   OR (state='out_for_delivery' AND handed_over_at IS NOT NULL AND delivered_at IS NULL)
   OR (state='delivered' AND handed_over_at IS NOT NULL AND delivered_at IS NOT NULL)
 )
);
CREATE INDEX IF NOT EXISTS barq_v28_driver_status_idx ON public.barq_last_mile_v28(driver_id,state);
ALTER TABLE public.barq_last_mile_v28 ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.barq_last_mile_v28 FROM PUBLIC, anon, authenticated;

-- Only a signed-in general admin or a single active manager of BAS may manage warehouse final-mile.
CREATE OR REPLACE FUNCTION public.barq_v28_can_manage_bas()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $$
 SELECT public.barq_v27_can_receive_bas() AND EXISTS (
   SELECT 1 FROM public.barq_branches b WHERE b.code='BAS' AND b.is_active IS TRUE
 );
$$;

-- Only the active driver assigned to BAS is allowed to read their delivery work.
CREATE OR REPLACE FUNCTION public.barq_v28_my_driver()
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $$
 SELECT d.id FROM public.drivers d
 JOIN public.profiles p ON p.id=d.user_id
 JOIN public.barq_branches b ON b.id=d.branch_id
 WHERE d.user_id=auth.uid() AND p.role='driver' AND d.is_active IS TRUE
   AND b.code='BAS' AND b.is_active IS TRUE
 LIMIT 1;
$$;

-- Eligible parcels physically inside BAS, including assigned and out-for-delivery history.
CREATE OR REPLACE FUNCTION public.barq_bas_final_mile_list_v28()
RETURNS TABLE (
 order_id uuid, receipt_code text, customer_name text, customer_phone text,
 delivery_address text, goods_type text, warehouse_shelf text,
 assigned_driver_id uuid, courier_name text, final_mile_state text,
 warehouse_item_id uuid, order_status text
)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
BEGIN
 IF NOT public.barq_v28_can_manage_bas() THEN
   RAISE EXCEPTION 'فقط إدارة مخزن البصرة تستطيع مشاهدة هذه الطرود' USING ERRCODE='42501';
 END IF;
 RETURN QUERY
 SELECT o.id,o.receipt_code,o.customer_name,o.customer_phone,o.delivery_address,o.goods_type,
        wi.shelf,lm.driver_id,p.full_name,lm.state,r.warehouse_item_id,o.status
 FROM public.barq_branch_transfers t
 JOIN public.barq_branches bas ON bas.id=t.to_branch_id AND bas.code='BAS'
 JOIN public.barq_branches bgd ON bgd.id=t.from_branch_id AND bgd.code='BGD'
 JOIN public.orders o ON o.id=t.order_id
 JOIN public.barq_order_routes r ON r.order_id=o.id AND r.route_type='warehouse'
 JOIN public.barq_warehouse_items wi ON wi.id=t.received_warehouse_item_id
        AND wi.id=r.warehouse_item_id AND wi.branch_id=bas.id AND wi.order_id=o.id
 LEFT JOIN public.barq_last_mile_v28 lm ON lm.order_id=o.id
 LEFT JOIN public.drivers d ON d.id=lm.driver_id
 LEFT JOIN public.profiles p ON p.id=d.user_id
 WHERE t.transfer_status='received'
   AND (o.status IN ('picked_up','on_the_way') OR (o.status='delivered' AND lm.state='delivered'))
   AND (wi.status='stored' OR (wi.status='released' AND lm.state IN ('out_for_delivery','delivered')))
 ORDER BY t.received_at DESC LIMIT 200;
END;
$$;

CREATE OR REPLACE FUNCTION public.barq_bas_final_drivers_v28()
RETURNS TABLE (driver_id uuid, full_name text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
BEGIN
 IF NOT public.barq_v28_can_manage_bas() THEN
  RAISE EXCEPTION 'لا تملك صلاحية تعيين مندوبي البصرة' USING ERRCODE='42501';
 END IF;
 RETURN QUERY SELECT d.id,p.full_name FROM public.drivers d
 JOIN public.profiles p ON p.id=d.user_id AND p.role='driver'
 JOIN public.barq_branches b ON b.id=d.branch_id AND b.code='BAS' AND b.is_active IS TRUE
 WHERE d.is_active IS TRUE AND d.is_available IS TRUE
 ORDER BY p.full_name LIMIT 200;
END;
$$;

CREATE OR REPLACE FUNCTION public.barq_bas_assign_final_driver_v28(p_order_id uuid,p_driver_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE v_bas uuid; v_wi uuid; v_item_status text; v_status text; v_gov text; v_old_state text;
BEGIN
 IF NOT public.barq_v28_can_manage_bas() THEN
  RAISE EXCEPTION 'فقط إدارة مخزن البصرة تعيّن المندوب' USING ERRCODE='42501';
 END IF;
 IF p_order_id IS NULL OR p_driver_id IS NULL THEN RAISE EXCEPTION 'حدد الطرد والمندوب' USING ERRCODE='22023'; END IF;
 SELECT id,governorate INTO STRICT v_bas,v_gov FROM public.barq_branches WHERE code='BAS' AND is_active IS TRUE;
 SELECT o.status,r.warehouse_item_id INTO v_status,v_wi FROM public.orders o
 JOIN public.barq_order_routes r ON r.order_id=o.id AND r.route_type='warehouse'
 WHERE o.id=p_order_id AND o.delivery_governorate=v_gov FOR UPDATE OF o,r;
 IF NOT FOUND OR v_status IS DISTINCT FROM 'picked_up' OR v_wi IS NULL THEN
   RAISE EXCEPTION 'الطلب ليس جاهزاً للتوصيل من مخزن البصرة' USING ERRCODE='23514'; END IF;
 IF NOT EXISTS (
  SELECT 1 FROM public.barq_branch_transfers t JOIN public.barq_branches bgd ON bgd.id=t.from_branch_id
  WHERE t.order_id=p_order_id AND t.to_branch_id=v_bas AND bgd.code='BGD'
    AND t.transfer_status='received' AND t.received_warehouse_item_id=v_wi
 ) THEN RAISE EXCEPTION 'الطرد لم يستلمه مخزن البصرة من بغداد فعلياً' USING ERRCODE='23514'; END IF;
 SELECT wi.status INTO v_item_status FROM public.barq_warehouse_items wi
 WHERE wi.id=v_wi AND wi.order_id=p_order_id AND wi.branch_id=v_bas FOR UPDATE;
 IF NOT FOUND OR v_item_status<>'stored' THEN RAISE EXCEPTION 'الطرد غير متاح على رف مخزن البصرة' USING ERRCODE='23514'; END IF;
 IF NOT EXISTS (SELECT 1 FROM public.drivers d JOIN public.profiles p ON p.id=d.user_id
                WHERE d.id=p_driver_id AND d.branch_id=v_bas AND d.is_active IS TRUE
                  AND d.is_available IS TRUE AND p.role='driver') THEN
  RAISE EXCEPTION 'اختار مندوباً فعالاً ومتاحاً يتبع فرع البصرة فقط' USING ERRCODE='23514'; END IF;
 SELECT lm.state INTO v_old_state FROM public.barq_last_mile_v28 lm WHERE lm.order_id=p_order_id FOR UPDATE;
 IF FOUND AND v_old_state<>'assigned' THEN RAISE EXCEPTION 'الطرد خرج من المخزن ولا يمكن إعادة تعيينه' USING ERRCODE='23514'; END IF;
 INSERT INTO public.barq_last_mile_v28(order_id,branch_id,warehouse_item_id,driver_id,assigned_by)
 VALUES(p_order_id,v_bas,v_wi,p_driver_id,auth.uid())
 ON CONFLICT(order_id) DO UPDATE SET driver_id=excluded.driver_id,assigned_by=auth.uid(),assigned_at=now()
 WHERE public.barq_last_mile_v28.state='assigned';
END;
$$;

-- Actual warehouse handover. Enter / scan physical parcel receipt. Transfer financial responsibility
-- to final courier via orders.driver_id, while pickup courier remains in route and last-mile audit.
CREATE OR REPLACE FUNCTION public.barq_bas_handover_final_v28(p_order_id uuid,p_receipt_code text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE v_lm public.barq_last_mile_v28%ROWTYPE; v_order public.orders%ROWTYPE;
        v_item_status text; v_item_branch uuid; v_driver_name text; v_bas uuid; v_code text;
BEGIN
 IF NOT public.barq_v28_can_manage_bas() THEN
   RAISE EXCEPTION 'ممنوع: تسليم الطرد للمندوب يكون من إدارة مخزن البصرة' USING ERRCODE='42501'; END IF;
 IF p_order_id IS NULL THEN RAISE EXCEPTION 'رقم الطلب مطلوب' USING ERRCODE='22023'; END IF;
 SELECT * INTO v_lm FROM public.barq_last_mile_v28 WHERE order_id=p_order_id FOR UPDATE;
 IF NOT FOUND OR v_lm.state<>'assigned' THEN RAISE EXCEPTION 'الطرد غير معيّن أو تم خروجه مسبقاً' USING ERRCODE='23514'; END IF;
 SELECT * INTO v_order FROM public.orders WHERE id=p_order_id FOR UPDATE;
 IF NOT FOUND OR v_order.status<>'picked_up' THEN RAISE EXCEPTION 'حالة الطلب لا تسمح بخروج الطرد' USING ERRCODE='23514'; END IF;
 v_code:=coalesce(nullif(btrim(v_order.receipt_code),''),v_order.id::text);
 IF btrim(coalesce(p_receipt_code,'')) IS DISTINCT FROM v_code THEN
   RAISE EXCEPTION 'باركود الوصل لا يطابق الطرد المسجّل' USING ERRCODE='23514'; END IF;
 SELECT b.id INTO STRICT v_bas FROM public.barq_branches b WHERE b.code='BAS' AND b.is_active IS TRUE;
 IF v_lm.branch_id<>v_bas THEN RAISE EXCEPTION 'الطرد ليس من فرع البصرة' USING ERRCODE='23514'; END IF;
 IF NOT EXISTS (
  SELECT 1 FROM public.barq_branch_transfers t WHERE t.order_id=p_order_id AND t.to_branch_id=v_bas
    AND t.transfer_status='received' AND t.received_warehouse_item_id=v_lm.warehouse_item_id
 ) THEN RAISE EXCEPTION 'التحويل بين الفروع ليس مستلماً في البصرة' USING ERRCODE='23514'; END IF;
 IF NOT EXISTS (
  SELECT 1 FROM public.barq_order_routes r WHERE r.order_id=p_order_id
    AND r.warehouse_item_id=v_lm.warehouse_item_id AND r.route_type='warehouse'
 ) THEN RAISE EXCEPTION 'الطرد ليس مرتبطاً بمخزن الوجهة' USING ERRCODE='23514'; END IF;
 SELECT wi.status,wi.branch_id INTO v_item_status,v_item_branch
 FROM public.barq_warehouse_items wi WHERE wi.id=v_lm.warehouse_item_id AND wi.order_id=p_order_id FOR UPDATE;
 IF NOT FOUND OR v_item_status<>'stored' OR v_item_branch<>v_bas THEN
  RAISE EXCEPTION 'الطرد غير محفوظ على رف البصرة' USING ERRCODE='23514'; END IF;
 SELECT p.full_name INTO v_driver_name FROM public.drivers d
 JOIN public.profiles p ON p.id=d.user_id WHERE d.id=v_lm.driver_id AND d.branch_id=v_bas
 AND d.is_active IS TRUE AND p.role='driver';
 IF NOT FOUND THEN RAISE EXCEPTION 'المندوب لم يعد فعالاً أو ليس تابعاً للبصرة' USING ERRCODE='23514'; END IF;
 UPDATE public.barq_warehouse_items SET status='released',released_at=now(),released_by=auth.uid(),
   receiver_name=coalesce(nullif(v_driver_name,''),'مندوب البصرة') WHERE id=v_lm.warehouse_item_id;
 UPDATE public.barq_last_mile_v28 SET state='out_for_delivery',handed_over_by=auth.uid(),
  handed_over_at=now(),original_driver_id=v_order.driver_id WHERE order_id=p_order_id;
 UPDATE public.orders SET driver_id=v_lm.driver_id,status='on_the_way',updated_at=now() WHERE id=p_order_id;
END;
$$;

-- Courier sees only their last-mile records and customer delivery address.
CREATE OR REPLACE FUNCTION public.barq_driver_final_mile_v28()
RETURNS TABLE (
 order_id uuid, receipt_code text, customer_name text, customer_phone text,
 delivery_address text, delivery_governorate text, goods_type text,
 order_amount_iqd bigint, delivery_fee_iqd bigint, driver_earning_iqd bigint,
 collection_method text, final_mile_state text, handed_over_at timestamptz,
 delivered_at timestamptz
)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE v_driver uuid;
BEGIN
 v_driver:=public.barq_v28_my_driver();
 IF v_driver IS NULL THEN RETURN; END IF; -- Other-branch drivers have no BAS final-mile records.
 RETURN QUERY
 SELECT o.id,o.receipt_code,o.customer_name,o.customer_phone,
 o.delivery_address,o.delivery_governorate,o.goods_type,
 o.order_amount_iqd,o.delivery_fee_iqd,o.driver_earning_iqd,
 o.collection_method,lm.state,lm.handed_over_at,lm.delivered_at
 FROM public.barq_last_mile_v28 lm JOIN public.orders o ON o.id=lm.order_id
 WHERE lm.driver_id=v_driver AND (o.driver_id=v_driver OR lm.state='assigned')
 ORDER BY lm.assigned_at DESC LIMIT 150;
END;
$$;

-- Scan is verified server-side and final status changes atomically only after handover confirmation.
CREATE OR REPLACE FUNCTION public.barq_driver_deliver_by_qr_v28(
 p_order_id uuid,p_scanned_qr text,p_recipient_handover boolean
)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE v_driver uuid; v_lm public.barq_last_mile_v28%ROWTYPE;
 v_code text; v_scanned text; v_order_status text; v_order_driver uuid; v_wi_status text;
BEGIN
 v_driver:=public.barq_v28_my_driver();
 IF v_driver IS NULL THEN RAISE EXCEPTION 'غير مصرح: المندوب غير فعال في البصرة' USING ERRCODE='42501'; END IF;
 IF p_order_id IS NULL OR NOT coalesce(p_recipient_handover,false) THEN
  RAISE EXCEPTION 'يجب تأكيد تسليم الطرد فعلياً إلى الزبون قبل مسح الوصل' USING ERRCODE='22023'; END IF;
 IF length(coalesce(p_scanned_qr,'')) NOT BETWEEN 7 AND 500 THEN
  RAISE EXCEPTION 'رمز QR غير صحيح' USING ERRCODE='22023'; END IF;
 SELECT * INTO v_lm FROM public.barq_last_mile_v28 WHERE order_id=p_order_id FOR UPDATE;
 IF NOT FOUND OR v_lm.driver_id<>v_driver OR v_lm.state<>'out_for_delivery' THEN
  RAISE EXCEPTION 'هذا الطرد ليس في عهدتك أو تم تسليمه مسبقاً' USING ERRCODE='42501'; END IF;
 SELECT o.status,o.driver_id,coalesce(nullif(btrim(o.receipt_code),''),o.id::text)
 INTO v_order_status,v_order_driver,v_code FROM public.orders o WHERE o.id=p_order_id FOR UPDATE;
 IF NOT FOUND OR v_order_status<>'on_the_way' OR v_order_driver<>v_driver THEN
  RAISE EXCEPTION 'حالة الطلب تغيرت أو ليس مسنداً لك' USING ERRCODE='23514'; END IF;
 -- The printed QR contains an HTTPS link containing BRQ-[32 hex chars]. Plain code works too.
 v_scanned:=upper(substring(coalesce(p_scanned_qr,'') from 'BRQ-[0-9A-Fa-f]{32}'));
 IF v_scanned IS NULL THEN v_scanned:=btrim(coalesce(p_scanned_qr,'')); END IF;
 IF v_scanned IS DISTINCT FROM v_code THEN
   RAISE EXCEPTION 'باركود هذا الطرد لا يطابق الوصل المطلوب' USING ERRCODE='23514'; END IF;
 SELECT wi.status INTO v_wi_status FROM public.barq_warehouse_items wi
 WHERE wi.id=v_lm.warehouse_item_id AND wi.order_id=p_order_id AND wi.branch_id=v_lm.branch_id;
 IF NOT FOUND OR v_wi_status<>'released' THEN
  RAISE EXCEPTION 'الطرد لم يخرج رسمياً من المخزن إلى المندوب' USING ERRCODE='23514'; END IF;
 UPDATE public.barq_last_mile_v28 SET state='delivered',delivered_at=now(),
  delivered_by=auth.uid(),matched_receipt_code=v_scanned,recipient_handover_confirmed=true
 WHERE order_id=p_order_id AND state='out_for_delivery';
 IF NOT FOUND THEN RAISE EXCEPTION 'سبق تأكيد التسليم' USING ERRCODE='23505'; END IF;
 UPDATE public.orders SET status='delivered',updated_at=now() WHERE id=p_order_id;
 IF NOT FOUND THEN RAISE EXCEPTION 'تعذر تحديث الطلب' USING ERRCODE='23514'; END IF;
END;
$$;

-- Prevent bypass via old driver_advance_order or admin status button for final-mile orders.
CREATE OR REPLACE FUNCTION public.barq_v28_guard_order_delivery()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE v_state text; v_final_driver uuid;
BEGIN
 SELECT lm.state,lm.driver_id INTO v_state,v_final_driver FROM public.barq_last_mile_v28 lm WHERE lm.order_id=NEW.id;
 IF FOUND THEN
  IF OLD.status IS DISTINCT FROM 'delivered' AND NEW.status='delivered' AND v_state<>'delivered' THEN
   RAISE EXCEPTION 'هذا الطلب يتطلب مسح باركود الوصل من مندوب البصرة قبل تأكيد التسليم' USING ERRCODE='23514';
  END IF;
  IF v_state IN ('out_for_delivery','delivered') AND NEW.driver_id IS DISTINCT FROM v_final_driver THEN
   RAISE EXCEPTION 'لا يمكن تغيير مندوب التوصيل النهائي بعد خروج الطرد من المخزن' USING ERRCODE='23514';
  END IF;
 END IF;
 RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS barq_v28_guard_order_delivery_trigger ON public.orders;
CREATE TRIGGER barq_v28_guard_order_delivery_trigger
BEFORE UPDATE OF status,driver_id ON public.orders FOR EACH ROW
EXECUTE FUNCTION public.barq_v28_guard_order_delivery();

REVOKE ALL ON FUNCTION public.barq_v28_can_manage_bas() FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.barq_v28_my_driver() FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.barq_bas_final_mile_list_v28() FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.barq_bas_final_drivers_v28() FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.barq_bas_assign_final_driver_v28(uuid,uuid) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.barq_bas_handover_final_v28(uuid,text) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.barq_driver_final_mile_v28() FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.barq_driver_deliver_by_qr_v28(uuid,text,boolean) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.barq_bas_final_mile_list_v28() TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_bas_final_drivers_v28() TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_bas_assign_final_driver_v28(uuid,uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_bas_handover_final_v28(uuid,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_driver_final_mile_v28() TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_driver_deliver_by_qr_v28(uuid,text,boolean) TO authenticated;

-- Presence checks only, run after installation; all columns should be TRUE.
SELECT
 to_regclass('public.barq_last_mile_v28') IS NOT NULL AS final_mile_table,
 to_regprocedure('public.barq_bas_final_mile_list_v28()') IS NOT NULL AS basra_list,
 to_regprocedure('public.barq_bas_final_drivers_v28()') IS NOT NULL AS basra_drivers,
 to_regprocedure('public.barq_bas_assign_final_driver_v28(uuid,uuid)') IS NOT NULL AS assign_ready,
 to_regprocedure('public.barq_bas_handover_final_v28(uuid,text)') IS NOT NULL AS handover_ready,
 to_regprocedure('public.barq_driver_final_mile_v28()') IS NOT NULL AS courier_list,
 to_regprocedure('public.barq_driver_deliver_by_qr_v28(uuid,text,boolean)') IS NOT NULL AS qr_delivery,
 EXISTS(SELECT 1 FROM pg_catalog.pg_trigger WHERE tgname='barq_v28_guard_order_delivery_trigger' AND NOT tgisinternal) AS delivery_guard;
