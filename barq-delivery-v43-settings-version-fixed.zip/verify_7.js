
    'use strict';
    const $ = id => document.getElementById(id);
    const storeKey = 'delivery_company_public_config_v1';
    let sb = null, currentView = 'overview', financeRows = [], currentData = {merchants:[],drivers:[],orders:[],profiles:[],branches:[]};
    // V24: emails are returned by an admin-only RPC; never expose auth.users to public tables.
    let merchantEmailById = new Map();
    $('orderGoodsType').addEventListener('change',()=>{const other=$('orderGoodsType').value==='أخرى';$('orderGoodsOtherWrap').classList.toggle('hide',!other);$('orderGoodsOtherWrap').classList.toggle('hidden',!other);$('orderGoodsOther').required=other;if(!other)$('orderGoodsOther').value='';});
    $('orderGoodsOtherWrap').classList.add('hide');
    let brq36AliasByUser = new Map();
    async function brq36LoadAliases(){
      const {data,error}=await sb.rpc('barq_admin_driver_aliases_v36');
      if(error)throw Error('تعذر تحميل أسماء مستخدمي المندوبين. شغّل SQL الخاص بـ V36: '+error.message);
      brq36AliasByUser=new Map((data||[]).map(x=>[x.user_id,x]));
    }
    const viewTitles = {overview:['لوحة التحكم','نظرة عامة','متابعة أعمال برق للتوصيل السريع'],merchants:['إدارة المحلات','المحلات والمطاعم','قائمة المحلات المسجلة في الشركة'],drivers:['إدارة المندوبين','المندوبين','المندوبون وحالة توفرهم'],branches:['إدارة الفروع','فروع برق','إضافة وإدارة الفروع ومديريها حسب المحافظات'],returns:['الرواجع','الرواجع','الطلبات الراجعة وأسباب الإرجاع'],warehouse:['مخزن الشركة','مخزن شركة برق','تسجيل الطرود وحركات الاستلام والتسليم'],orders:['إدارة الطلبات','الطلبات','جميع طلبات التوصيل'],finance:['الحسابات','الحسابات والتسويات','التدفقات المالية والرصيد غير المسدد'],payroll:['سجل رواتب قديم','أرشيف V33','متوقف في نظام V35'],commissions35:['النسب والعمولات','نسب جميع المندوبين','النسبة العامة، نسب الفروع والمندوبين، وكشف الطرود'],finance34:['الإدارة المالية','الإدارة المالية V35','الإيرادات والمصاريف والعمولات والتدفقات النقدية'],reports:['التقارير','التقارير المختصرة','مؤشرات الطلبات'],alerts:['التنبيهات','تنبيهات الطلبات','طلبات تحتاج متابعة'],settings:['الإعدادات','إعدادات حساب المدير','معلومات النظام']};
    const statusNames={pending:'بانتظار التوزيع',assigned:'تم تعيين المندوب',picked_up:'تم الاستلام',on_the_way:'قيد التوصيل',delivered:'تم التسليم',cancelled:'ملغي',returned:'مرتجع'};
    const esc = value => String(value ?? '').replace(/[&<>"']/g, char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
    const money = n => Number(n||0).toLocaleString('en-US');
    const nice = s => s==null||s===''?'—':esc(s);
    const shortId = v => v ? '#'+esc(String(v).slice(0,8).toUpperCase()) : '—';
    // Provinces are shop location, NOT branch assignment. Includes Halabja (19th).
    const BARQ_IRAQ_GOVERNORATES = Object.freeze([
      'البصرة','بغداد','نينوى','الأنبار','أربيل','السليمانية','دهوك','حلبجة',
      'كركوك','صلاح الدين','ديالى','بابل','كربلاء','النجف','القادسية',
      'واسط','ميسان','ذي قار','المثنى'
    ]);
    function fillMerchantGovernorateSelect(id){
      const el=$(id);if(!el)return;
      el.innerHTML='<option value="">اختر المحافظة</option>'+BARQ_IRAQ_GOVERNORATES.map(g=>`<option value="${esc(g)}">${esc(g)}</option>`).join('');
    }
    fillMerchantGovernorateSelect('merchantGovernorate');
    fillMerchantGovernorateSelect('merchantGovernorateEdit');
    const nameOf = (id,list) => list.find(x=>x.id===id)?.name || '—';
    const pill = (v) => {let cls=v==='delivered'?'green':v==='on_the_way'||v==='picked_up'?'blue':v==='cancelled'||v==='returned'?'red':'orange';return `<span class="pill ${cls}">${esc(statusNames[v]||v||'—')}</span>`};
    function showPage(id){['setupPage','loginPage','appPage'].forEach(x=>$(x).classList.toggle('hide',x!==id));}
    function setError(id,msg){$(id).textContent=msg||'';$(id).classList.toggle('hide',!msg)}
    function loadConfig(){const c=window.BARQ_CONFIG;return c&&validUrl(c.url)&&typeof c.key==='string'&&c.key.startsWith('sb_publishable_')?c:null}
    function validUrl(s){try{let u=new URL(s);return u.protocol==='https:' && /^[a-z0-9-]+\.supabase\.co$/i.test(u.hostname) && (u.pathname==='/'||u.pathname==='')}catch{return false}}
    function initialize(config){if(!window.supabase?.createClient)throw Error('مكتبة الاتصال لم تتحمّل. تأكد من اتصال الإنترنت ثم أعد فتح الصفحة.');sb=window.supabase.createClient(config.url,config.key,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:false}})}
    async function requireAdmin(user){if(!user?.id)return false;const {data,error}=await sb.from('profiles').select('role').eq('id',user.id).single();if(error)throw Error('تعذر قراءة صلاحية الحساب: '+error.message);return data?.role==='admin'}
    async function boot(){const cfg=loadConfig();if(!cfg){showPage('loginPage');setError('loginError','إعدادات الاتصال لم يجهزها مدير النظام بعد. تواصل مع الإدارة.');return}try{initialize(cfg);const {data:{session},error}=await sb.auth.getSession();if(error)throw error;if(!session?.user){showPage('loginPage');return}if(!await requireAdmin(session.user)){await sb.auth.signOut();showPage('loginPage');setError('loginError','هذا الحساب لا يملك صلاحية المدير (admin).');return}await enterApp(session.user)}catch(e){showPage('loginPage');setError('loginError',e.message||'حصل خطأ في الاتصال.')}}
    async function enterApp(user){showPage('appPage');$('accountEmail').textContent=user.email||'';selectView(currentView);await refreshData()}
    function selectView(name){if(!viewTitles[name])name='overview';currentView=name;const v=viewTitles[name];$('pageTitle').textContent=v[0];$('sectionTitle').textContent=v[1];$('sectionCaption').textContent=v[2];document.querySelectorAll('[data-view]').forEach(x=>x.classList.toggle('active',x.dataset.view===name));['overview','merchants','drivers','branches','returns','warehouse','orders','finance','payroll','commissions35','finance34','reports','alerts','settings'].forEach(x=>$(x+'Section').classList.toggle('hide',x!==name));$('statsPanel').classList.toggle('hide',name!=='overview');$('dashboardPanels').classList.toggle('hide',name!=='overview');$('overviewAlerts').classList.toggle('hide',name!=='overview');if((name==='returns'||name==='warehouse')&&sb&&!brqLogisticsLoaded){void refreshLogistics(true)}if(name==='branches'&&sb&&currentData.profiles.length){void brq23RefreshBranches()}if(name==='payroll'&&sb){void brq33RefreshPayroll()}if(name==='commissions35'&&sb){void brq35Refresh()}if(name==='finance34'&&sb){void brq34Refresh()}}
    function rowEmpty(cols,message='لا توجد بيانات مسجلة حالياً'){return `<tr><td colspan="${cols}" class="empty">${esc(message)}</td></tr>`}
    // BARQ V41: Populate both driver enrollment lists from ACTIVE branches, never hard-code BAS/BGD.
    let brq41ActiveBranches=[];
    function brq41BranchName(b){
      return String(b.governorate||b.name||'فرع')+' — '+String(b.name||b.code||'');
    }
    function brq41RenderDriverBranchChoices(){
      const branches=brq41ActiveBranches;
      for(const selectId of ['driverBranch','bgdDriverTarget']){
        const el=$(selectId);if(!el)continue;
        const previously=el.value;
        el.innerHTML='<option value="">'+(branches.length?'اختر الفرع / المحافظة':'لا توجد فروع نشطة متاحة')+'</option>'+branches.map(b=>`<option value="${esc(b.code)}">${esc(brq41BranchName(b))}</option>`).join('');
        if(branches.some(b=>b.code===previously))el.value=previously;
        else el.value='';
        el.disabled=!branches.length;
      }
      $('bgdDriverAssign').disabled=!$('bgdDriverSelect').value||!$('bgdDriverTarget').value;
    }
    function brq41SetActiveBranches(branches){
      brq41ActiveBranches=(branches||[])
        .filter(b=>b && b.is_active===true && String(b.code||'').trim() && String(b.id||'').trim())
        .map(b=>({...b,code:String(b.code).trim().toUpperCase()}))
        .sort((a,b)=>String(a.governorate||a.name||'').localeCompare(String(b.governorate||b.name||''),'ar'));
      brq41RenderDriverBranchChoices();
    }
    async function brq41LoadActiveBranches(){
      const save=$('saveDriver');save.disabled=true;
      try{
        const {data,error}=await sb.from('barq_branches').select('id,code,name,governorate,is_active').eq('is_active',true).order('code').limit(500);
        if(error)throw error;
        brq41SetActiveBranches(data||[]);
        if(!brq41ActiveBranches.length)throw Error('لا توجد فروع مفعّلة. فعّل الفرع من إدارة الفروع.');
      }catch(e){brq41SetActiveBranches([]);throw e;}
      finally{save.disabled=false;}
    }
    // V25: grouping and filtering is by the assigned branch, never by the profile address.
    // A dropdown option is available for every registered governorate, even when empty.
    const BRQ25_UNASSIGNED = '__barq25_unassigned__';
    function brq25DriverProvince(d){
      const branch=(currentData.branches||[]).find(b=>b.id===d.branch_id);
      return String(branch?.governorate||'').trim();
    }
    function brq25DriverBranchLabel(d){
      const branch=(currentData.branches||[]).find(b=>b.id===d.branch_id);
      return branch ? (branch.governorate+' — '+branch.name) : 'غير محددة';
    }
    function brq25RenderDriverTable(){
      const dropdown=$('driverGovernorateFilter');if(!dropdown)return;
      const drivers=currentData.drivers||[];
      const profileById=new Map((currentData.profiles||[]).map(p=>[p.id,p]));
      const governorates=[...new Set((currentData.branches||[]).map(b=>String(b.governorate||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ar'));
      const counts=new Map();
      for(const d of drivers){const gov=brq25DriverProvince(d)||BRQ25_UNASSIGNED;counts.set(gov,(counts.get(gov)||0)+1);}
      const previous=dropdown.value;
      dropdown.innerHTML='<option value="">جميع المحافظات ('+money(drivers.length)+')</option>'
        +governorates.map(g=>'<option value="'+esc(g)+'">'+esc(g)+' ('+money(counts.get(g)||0)+')</option>').join('')
        +'<option value="'+BRQ25_UNASSIGNED+'">بدون محافظة ('+money(counts.get(BRQ25_UNASSIGNED)||0)+')</option>';
      if(previous===BRQ25_UNASSIGNED||governorates.includes(previous))dropdown.value=previous;
      else dropdown.value='';
      const selected=dropdown.value;
      const filtered=drivers.filter(d=>!selected||(selected===BRQ25_UNASSIGNED?!brq25DriverProvince(d):brq25DriverProvince(d)===selected));
      filtered.sort((a,b)=>{
        const ga=brq25DriverProvince(a),gb=brq25DriverProvince(b);
        if(!ga&&gb)return 1;if(ga&&!gb)return -1;
        const govOrder=ga.localeCompare(gb,'ar');if(govOrder)return govOrder;
        return String(profileById.get(a.user_id)?.full_name||'').localeCompare(String(profileById.get(b.user_id)?.full_name||''),'ar');
      });
      $('driversFilterCount').textContent='المعروض: '+money(filtered.length)+' من '+money(drivers.length)+' مندوب';
      $('driversRows').innerHTML=filtered.length?filtered.map(d=>{const p=profileById.get(d.user_id)||{};return `<tr><td><strong>${nice(p.full_name)}</strong></td><td dir="ltr">${nice(brq36AliasByUser.get(d.user_id)?.username)}</td><td><span class="pill ${d.branch_id?'blue':'orange'}">${esc(brq25DriverBranchLabel(d))}</span></td><td dir="ltr">${nice(p.phone)}</td><td>${d.vehicle_type==='motorcycle'?'دراجة نارية':d.vehicle_type==='car'?'سيارة':d.vehicle_type==='bicycle'?'دراجة هوائية':nice(d.vehicle_type)}</td><td><span class="pill ${d.is_available?'green':'orange'}">${d.is_available?'متاح':'غير متاح'}</span></td><td><span class="pill ${d.is_active?'green':'red'}">${d.is_active?'نشط':'موقوف'}</span></td><td><button type="button" class="tiny-action" data-toggle-driver="${esc(d.id)}" ${d.is_active?'':'disabled'}>${d.is_available?'جعله غير متاح':'جعله متاح'}</button><div class="member-actions" style="margin-top:6px"><button type="button" class="tiny-action" data-driver-alias="${esc(d.user_id)}">بيانات الدخول</button><button type="button" class="tiny-action" data-brq42-transfer="${esc(d.id)}" ${!d.is_active||!d.branch_id?'disabled':''}>نقل إلى فرع</button><button type="button" class="tiny-action" data-member-action="${d.is_active?'suspend':'activate'}" data-member-kind="driver" data-member-id="${esc(d.id)}">${d.is_active?'تعطيل':'إعادة تفعيل'}</button><button type="button" class="tiny-action member-danger" data-member-action="delete" data-member-kind="driver" data-member-id="${esc(d.id)}">حذف نهائي</button></div></td></tr>`}).join(''):rowEmpty(8, selected ? 'لا يوجد مندوبون في المحافظة المحددة.' : 'لا يوجد مندوبون مسجلون حالياً.');
    }
    $('driverGovernorateFilter').addEventListener('change', brq25RenderDriverTable);
    function render(){const {merchants,drivers,orders,profiles}=currentData;const provinceOf=d=>{const b=(currentData.branches||[]).find(b=>b.id===d.branch_id);return b?(b.governorate+' — '+b.name):'غير محددة'};const prof=id=>profiles.find(x=>x.id===id)||{};const driver=id=>{const d=drivers.find(x=>x.id===id);return d ? prof(d.user_id).full_name||'مندوب بدون اسم' : 'غير معيّن'};const merchant=id=>nameOf(id,merchants);
      const orderRow=(o,large)=>`<tr><td>${shortId(o.id)}<small class="barq-code" style="display:block;max-width:135px;overflow-wrap:anywhere">${esc(o.receipt_code||'')}</small></td><td>${nice(o.customer_name)}<small style="display:block;color:#687c92;font-size:11px;margin-top:4px">${esc(o.delivery_governorate||'—')} · ${esc(o.goods_type||'—')}</small></td>${large?`<td dir="ltr">${nice(o.customer_phone)}</td>`:''}<td>${esc(merchant(o.merchant_id))}</td><td>${esc(driver(o.driver_id))}</td>${large?`<td>${money(o.order_amount_iqd)}</td>`:''}<td>${money(o.delivery_fee_iqd)}</td>${large?`<td>${o.collection_method==='full_cod'?'المبلغ الكامل':o.collection_method==='delivery_fee_only'?'التوصيل فقط':'غير محدد'}</td>`:''}<td>${pill(o.status)}</td>${large?`<td><button type="button" class="tiny-action" data-manage-order="${esc(o.id)}">توزيع / حالة</button><button type="button" class="tiny-action" data-barq-order-qr="${esc(o.id)}">▦ QR</button></td>`:''}</tr>`;
      $('latestOrders').innerHTML=orders.length?orders.slice(0,8).map(o=>orderRow(o,false)).join(''):rowEmpty(6);
      $('ordersRows').innerHTML=orders.length?orders.map(o=>orderRow(o,true)).join(''):rowEmpty(10);
      $('merchantsRows').innerHTML=merchants.length?merchants.map(m=>`<tr><td><strong>${nice(m.name)}</strong></td><td>${m.merchant_type==='restaurant'?'مطعم':'محل'}</td><td dir="ltr">${nice(m.phone)}</td><td dir="ltr" style="text-align:left;direction:ltr;font-size:12px;word-break:break-word;min-width:160px">${nice(merchantEmailById.get(m.id))}</td><td><span class="pill ${m.governorate?'blue':'orange'}">${nice(m.governorate||'غير محددة')}</span></td><td>${nice(m.address)}</td><td><span class="pill ${m.is_active?'green':'red'}">${m.is_active?'نشط':'متوقف'}</span></td><td><div class="member-actions"><button type="button" class="tiny-action" data-merchant-governorate="${esc(m.id)}">${m.governorate?'تعديل المحافظة':'تحديد المحافظة'}</button><button type="button" class="tiny-action" data-member-action="${m.is_active?'suspend':'activate'}" data-member-kind="merchant" data-member-id="${esc(m.id)}">${m.is_active?'تعطيل':'إعادة تفعيل'}</button><button type="button" class="tiny-action member-danger" data-member-action="delete" data-member-kind="merchant" data-member-id="${esc(m.id)}">حذف نهائي</button></div></td></tr>`).join(''):rowEmpty(8);
      brq25RenderDriverTable();
      updateOrderOptions();renderFinance();
    }

    function dashboardGraph(records, mountId){
      const box=$(mountId);if(!box)return;
      const dates=Array.from({length:7},(_,i)=>{let d=new Date();d.setHours(0,0,0,0);d.setDate(d.getDate()-6+i);return d;});
      const values=dates.map(d=>records.filter(o=>{const t=new Date(o.created_at);return t.getFullYear()===d.getFullYear()&&t.getMonth()===d.getMonth()&&t.getDate()===d.getDate()}).length);
      const max=Math.max(4,...values),w=700,h=215,l=40,r=18,t=14,b=38,uw=w-l-r,uh=h-t-b;
      const points=values.map((v,i)=>[l+i*uw/6,t+(max-v)*uh/max]);
      const poly=points.map(p=>p.join(',')).join(' ');
      const path='M'+points.map(p=>p.join(' ')).join(' L');
      const area=path+' L'+points[6][0]+' '+(h-b)+' L'+points[0][0]+' '+(h-b)+' Z';
      const rows=[0,.25,.5,.75,1].map(q=>{let y=t+q*uh;let n=Math.round(max*(1-q));return `<line x1="${l}" y1="${y}" x2="${w-r}" y2="${y}" class="gridline"/><text class="axis" x="${l-9}" y="${y+4}" text-anchor="end">${n}</text>`}).join('');
      const labels=dates.map((d,i)=>`<text class="axis" x="${points[i][0]}" y="${h-10}" text-anchor="middle">${esc(new Intl.DateTimeFormat('ar-IQ',{weekday:'short'}).format(d))}</text>`).join('');
      box.innerHTML=`<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" role="img" aria-label="منحنى أعداد الطلبات خلال 7 أيام"><defs><linearGradient id="area_${mountId}" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#ff8323" stop-opacity="0.28"/><stop offset="100%" stop-color="#ff8323" stop-opacity="0"/></linearGradient></defs>${rows}<path d="${area}" fill="url(#area_${mountId})"/><path d="${path}" fill="none" stroke="#ff7b16" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>${points.map(p=>`<circle cx="${p[0]}" cy="${p[1]}" r="5" fill="#fff" stroke="#ff7b16" stroke-width="3"/>`).join('')}${labels}</svg>`;
    }
    function updateDashboard(allCount, deliveredCount){
      const {drivers,orders}=currentData;
      const active=orders.filter(o=>['pending','assigned','picked_up','on_the_way'].includes(o.status));
      const feeSum=orders.filter(o=>o.status==='delivered').reduce((s,o)=>s+Number(o.delivery_fee_iqd||0),0);
      $('activeOrderCount').textContent=money(active.length);
      $('deliveredFees').textContent=money(feeSum);
      $('availDrivers').textContent=money(drivers.filter(d=>d.is_active&&d.is_available).length);
      $('busyDrivers').textContent=money(drivers.filter(d=>d.is_active&&!d.is_available).length);
      $('inactiveDrivers').textContent=money(drivers.filter(d=>!d.is_active).length);
      const pct=allCount?Math.round(100*deliveredCount/allCount):0;
      $('completionPercent').textContent=pct+'%';$('completionRing').style.setProperty('--pct',pct);
      $('deliveredLabel').textContent='مسلّمة: '+money(deliveredCount);
      $('cancelledLabel').textContent='ملغاة (من آخر 100): '+money(orders.filter(o=>o.status==='cancelled').length);
      $('reportAll').textContent=money(allCount);$('reportDelivered').textContent=money(deliveredCount);
      const pending=orders.filter(o=>o.status==='pending');$('reportPending').textContent=money(pending.length);
      $('navPendingBadge').textContent=money(pending.length);$('navAlertBadge').textContent=money(pending.length);
      const cards=pending.length?pending.slice(0,7).map(o=>{
        const m=currentData.merchants.find(m=>m.id===o.merchant_id);
        return `<div class="notice-card"><span class="note-ico">▣</span><div><b>طلب ${shortId(o.id)} بانتظار التوزيع</b><small>${esc(m?.name||'محل غير معروف')} · ${esc(o.customer_name||'زبون')}</small><button type="button" data-manage-order="${esc(o.id)}">تعيين مندوب ←</button></div></div>`;
      }).join(''):'<div class="notice-card"><span class="note-ico">✓</span><div><b>لا توجد طلبات بانتظار التوزيع</b><small>تظهر هنا الطلبات الجديدة التي لم يتم تعيينها.</small></div></div>';
      $('overviewAlertCards').innerHTML=cards;$('allAlertCards').innerHTML=cards;
      dashboardGraph(orders,'weeklyChart');dashboardGraph(orders,'reportsChart');
      $('settingsEmail').textContent=$('accountEmail').textContent;
      $('headerDay').textContent=new Date().toLocaleDateString('ar-IQ',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
    }
    function updateOverviewMargin(){
      const ready=financeRows.filter(r=>r.finance_ready);
      const value=ready.reduce((sum,r)=>sum+Number(r.company_margin_iqd||0),0);
      $('overviewMargin').textContent=money(value);
    }
    $('dashboardAddOrder').addEventListener('click',()=>showModal('orderModal'));
    document.querySelectorAll('[data-open-view]').forEach(el=>el.addEventListener('click',()=>selectView(el.dataset.openView)));

    async function refreshData(){setError('globalError','');$('refreshBtn').disabled=true;$('refreshBtn').innerHTML='<span class="loading"></span> تحديث';try{
      const queries=await Promise.all([
        sb.from('merchants').select('id,name,merchant_type,phone,address,governorate,is_active,owner_id').order('created_at',{ascending:false}).limit(1000),
        sb.from('drivers').select('id,user_id,branch_id,vehicle_type,is_available,is_active').order('created_at',{ascending:false}).limit(1000),
        sb.from('orders').select('id,receipt_code,merchant_id,driver_id,customer_name,customer_phone,delivery_address,delivery_governorate,goods_type,notes,delivery_fee_iqd,order_amount_iqd,collection_method,driver_earning_iqd,status,created_at').order('created_at',{ascending:false}).limit(100),
        sb.from('profiles').select('id,full_name,phone,role').limit(1000),
        sb.from('merchants').select('id',{head:true,count:'exact'}),
        sb.from('drivers').select('id',{head:true,count:'exact'}),
        sb.from('orders').select('id',{head:true,count:'exact'}),
        sb.from('orders').select('id',{head:true,count:'exact'}).eq('status','delivered'),
        sb.from('barq_branches').select('id,code,name,governorate,is_active').order('code'),
        sb.rpc('barq_admin_merchant_emails_v24')
      ]);
      const err=queries.slice(0,9).find(q=>q.error)?.error;if(err)throw err;
      merchantEmailById = new Map((queries[9].data||[]).map(row=>[row.merchant_id,row.email]));
      if(queries[9].error){
        setError('globalError','المحلات والطلبات تظهر بشكل طبيعي، لكن إيميلات المحلات غير متاحة. شغّل ملف SQL الخاص بإصدار V24 ثم اضغط تحديث.');
      }
      currentData={merchants:queries[0].data||[],drivers:queries[1].data||[],orders:queries[2].data||[],profiles:queries[3].data||[],branches:queries[8].data||[]};
      brq41SetActiveBranches(currentData.branches);
      await brq36LoadAliases();
      await refreshFinance(false);
      await refreshLogistics(false);
      $('merchantCount').textContent=money(queries[4].count);$('driverCount').textContent=money(queries[5].count);$('orderCount').textContent=money(queries[6].count);$('deliveredCount').textContent=money(queries[7].count);updateDashboard(queries[6].count||0,queries[7].count||0);updateOverviewMargin();$('lastRefresh').textContent='آخر تحديث: '+new Date().toLocaleTimeString('ar-IQ',{hour:'2-digit',minute:'2-digit'});render();bgdUpdateDriverOptions();if(currentView==='branches')await brq23RefreshBranches();if(currentView==='finance34')await brq34Refresh();if(currentView==='commissions35')await brq35Refresh();
    }catch(e){setError('globalError','فشل تحميل البيانات: '+(e.message||e));}finally{$('refreshBtn').disabled=false;$('refreshBtn').textContent='⟳ تحديث'}}
    function getDriverLabel(d){const p=currentData.profiles.find(p=>p.id===d.user_id);return esc((p?.full_name||'مندوب بدون اسم')+' — '+(p?.phone||'بدون رقم'));}
    function updateOrderOptions(){
      if(!$('orderMerchant'))return;
      const prevM=$('orderMerchant').value,prevD=$('orderDriver').value;
      const shops=currentData.merchants.filter(m=>m.is_active);
      $('orderMerchant').innerHTML='<option value="">اختر المحل</option>'+shops.map(m=>`<option value="${esc(m.id)}">${esc(m.name)}</option>`).join('');
      if(shops.some(x=>x.id===prevM))$('orderMerchant').value=prevM;
      const available=currentData.drivers.filter(d=>d.is_active&&d.is_available);
      $('orderDriver').innerHTML='<option value="">بدون مندوب — بانتظار التوزيع</option>'+available.map(d=>`<option value="${esc(d.id)}">${getDriverLabel(d)}</option>`).join('');
      if(available.some(x=>x.id===prevD))$('orderDriver').value=prevD;
    }
    function showModal(id){
      const msg={merchantModal:['merchantError','merchantSuccess'],driverModal:['driverError','driverSuccess'],orderModal:['orderError','orderSuccess'],manageOrderModal:['manageOrderError','manageOrderSuccess']}[id];
      if(msg){setError(msg[0],'');$(msg[1]).classList.add('hide');}
      if(id==='merchantModal'||id==='driverModal'){$(id==='merchantModal'?'merchantForm':'driverForm').reset();$(id==='merchantModal'?'merchantCopyCredentials':'driverCopyCredentials').classList.add('hide');}
      if(id==='orderModal')updateOrderOptions();
      $(id).classList.remove('hide');$(id).querySelector('select, input')?.focus();
    }
    function closeModal(id){$(id).classList.add('hide');if(id==='merchantModal'||id==='driverModal'){$(id==='merchantModal'?'merchantForm':'driverForm').reset();}}
    $('addMerchant').addEventListener('click',()=>showModal('merchantModal'));
    $('addDriver').addEventListener('click',async()=>{
      showModal('driverModal');
      // Fetch latest active branches before account creation, even if admin dashboard is stale.
      try{await brq41LoadActiveBranches();}
      catch(err){setError('driverError','تعذر تحميل الفروع النشطة: '+(err.message||err)+'. لا تنشئ حساباً قبل إصلاح الاتصال.');}
    });
    $('addOrder').addEventListener('click',()=>showModal('orderModal'));
    document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>closeModal(b.dataset.close)));
    document.querySelectorAll('.modal-backdrop').forEach(modal=>modal.addEventListener('click',e=>{if(e.target===modal)closeModal(modal.id)}));
    document.addEventListener('keydown',e=>{if(e.key==='Escape'){document.querySelectorAll('.modal-backdrop:not(.hide)').forEach(x=>closeModal(x.id))}});
    const allowedTransitions={pending:['pending','assigned','cancelled'],assigned:['assigned','pending','picked_up','cancelled'],picked_up:['picked_up','on_the_way','returned'],on_the_way:['on_the_way','delivered','returned'],delivered:['delivered'],cancelled:['cancelled'],returned:['returned']};
    function openManageOrder(id){
      const o=currentData.orders.find(o=>o.id===id);if(!o)return setError('globalError','الطلب غير موجود في البيانات المحمّلة. اضغط تحديث.');
      $('manageOrderId').value=id;
      const shop=currentData.merchants.find(m=>m.id===o.merchant_id);
      $('manageOrderSummary').textContent=`الطلب ${shortId(o.id)} — الزبون: ${o.customer_name} — المحل: ${shop?.name||'غير معروف'} — المحافظة: ${o.delivery_governorate||'—'} — البضاعة: ${o.goods_type||'—'} — العنوان: ${o.delivery_address||'—'}`;
      const opts=currentData.drivers.filter(d=>d.is_active&&(d.is_available||d.id===o.driver_id));
      $('manageOrderDriver').innerHTML='<option value="">بدون مندوب</option>'+opts.map(d=>`<option value="${esc(d.id)}">${getDriverLabel(d)}${d.is_available?'':' (غير متاح حالياً)'}</option>`).join('');
      $('manageOrderDriver').value=o.driver_id||'';
      const transitions=allowedTransitions[o.status]||[o.status];
      $('manageOrderStatus').innerHTML=transitions.map(s=>`<option value="${esc(s)}">${esc(statusNames[s]||s)}</option>`).join('');
      $('manageOrderStatus').value=o.status;
      showModal('manageOrderModal');
    }
    $('manageOrderDriver').addEventListener('change',()=>{
      const o=currentData.orders.find(o=>o.id===$('manageOrderId').value);
      if(!o)return;
      if(o.status==='pending'&&$('manageOrderDriver').value&&$('manageOrderStatus').value==='pending')$('manageOrderStatus').value='assigned';
      if(o.status==='assigned'&&!$('manageOrderDriver').value&&$('manageOrderStatus').value==='assigned')$('manageOrderStatus').value='pending';
    });
    // V8: secure member management runs exclusively on the server. No browser-side secret key.
    async function manageMember(button){
      const kind=button.dataset.memberKind;
      const id=button.dataset.memberId;
      const action=button.dataset.memberAction;
      const item=kind==='merchant'?currentData.merchants.find(m=>m.id===id):currentData.drivers.find(d=>d.id===id);
      if(!item||!['merchant','driver'].includes(kind)||!['suspend','activate','delete'].includes(action))return;
      const label=kind==='merchant'?item.name:(currentData.profiles.find(p=>p.id===item.user_id)?.full_name||'المندوب');
      if(action==='delete'){
        const text=prompt('تنبيه: الحذف النهائي يمسح حساب الدخول لهذا المستخدم ولا يمكن التراجع عنه.\nإذا كان لديه أي طلب سابق، النظام يرفض الحذف ويتيح التعطيل بدلاً منه.\nللتأكيد على حذف «'+label+'» اكتب كلمة حذف:');
        if(text!=='حذف')return;
      } else {
        if(!confirm((action==='suspend'?'تعطيل حساب ':'إعادة تفعيل حساب ')+label+'؟\n'+(action==='suspend'?'لن يتمكن صاحب الحساب من إدارة طلباته بعد التعطيل، لكن تبقى بيانات الطلبات والحسابات.':'سيستعيد صلاحيات الدخول.')) )return;
      }
      button.disabled=true;setError('globalError','');
      try{
        await verifiedAdmin();
        const {data,error}=await sb.functions.invoke('barq-manage-member',{body:{kind,member_id:id,action}});
        if(error){
          let message=error.message||'فشل تنفيذ العملية';
          if(error.context&&typeof error.context.json==='function'){
            try{const details=await error.context.json();message=details.error||details.message||message;}catch{}
          }
          throw Error(message);
        }
        if(!data?.ok)throw Error(data?.error||'تعذر إكمال العملية');
        await refreshData();
        alert(action==='delete'?'تم حذف الحساب نهائياً.':action==='suspend'?'تم تعطيل الحساب، واحتفظنا بسجل الطلبات.':'تمت إعادة تفعيل الحساب.');
      }catch(e){setError('globalError','تعذر تنفيذ الإجراء: '+(e.message||String(e)));alert('تعذر تنفيذ الإجراء: '+(e.message||String(e)));}
      finally{button.disabled=false;}
    }
    document.addEventListener('click',async e=>{
      const merchantGovButton=e.target.closest('[data-merchant-governorate]');
      if(merchantGovButton){
        const m=currentData.merchants.find(x=>x.id===merchantGovButton.dataset.merchantGovernorate);
        if(!m)return;
        $('merchantGovernorateId').value=m.id;
        $('merchantGovernorateName').textContent='المحل: '+m.name;
        $('merchantGovernorateEdit').value=m.governorate||'';
        setError('merchantGovernorateError','');
        $('merchantGovernorateModal').classList.remove('hide');
        $('merchantGovernorateEdit').focus();
        return;
      }
      const member=e.target.closest('[data-member-action]');if(member){await manageMember(member);return;}
      const manage=e.target.closest('[data-manage-order]');if(manage){openManageOrder(manage.dataset.manageOrder);return;}
      const toggle=e.target.closest('[data-toggle-driver]');if(!toggle)return;
      const d=currentData.drivers.find(x=>x.id===toggle.dataset.toggleDriver);if(!d)return;
      if(!d.is_active)return setError('globalError','المندوب موقوف، لا يمكن تغيير توفره.');
      toggle.disabled=true;setError('globalError','');
      try{await verifiedAdmin();const {data,error}=await sb.from('drivers').update({is_available:!d.is_available}).eq('id',d.id).select('id');if(error)throw error;if(!data?.length)throw Error('لم يتم تغيير توفر المندوب.');await refreshData();}
      catch(err){setError('globalError','تعذر تغيير توفر المندوب: '+(err.message||err));toggle.disabled=false;}
    });
    document.addEventListener('click',event=>{
      const b=event.target.closest('[data-driver-alias]');if(!b)return;
      const d=currentData.drivers.find(x=>x.user_id===b.dataset.driverAlias);if(!d)return;
      const p=currentData.profiles.find(x=>x.id===d.user_id)||{};
      const alias=brq36AliasByUser.get(d.user_id)||{};
      $('brq36EditUserId').value=d.user_id;
      $('brq36EditDriverName').textContent=(p.full_name||'مندوب')+' — حساب موجود مسبقاً؛ نفس كلمة المرور القديمة';
      $('brq36EditUsername').value=alias.username||'';
      $('brq36EditPhone').value=alias.phone_e164||p.phone||'';
      setError('brq36AliasError','');$('driverAliasModal').classList.remove('hide');
      $('brq36EditUsername').focus();
    });
    $('brq36AliasForm').addEventListener('submit',async e=>{
      e.preventDefault();setError('brq36AliasError','');const btn=$('brq36AliasSave');btn.disabled=true;
      try{
        await verifiedAdmin();
        const name=$('brq36EditUsername').value.trim().toLowerCase();
        if(!/^[a-z][a-z0-9_]{3,23}$/.test(name))throw Error('اسم المستخدم غير صحيح');
        const {error}=await sb.rpc('barq_admin_set_driver_alias_v36',{
          p_user_id:$('brq36EditUserId').value,p_username:name,
          p_phone:$('brq36EditPhone').value.trim()||null
        });
        if(error)throw error;
        closeModal('driverAliasModal');await refreshData();
      }catch(ex){setError('brq36AliasError',ex.message||String(ex));}
      finally{btn.disabled=false;}
    });
    function validDinars(value,label){const v=Number(value);if(!Number.isSafeInteger(v)||v<0)throw Error(label+' لازم يكون عدد صحيح صفر أو أكثر.');return v;}
    async function saveNewOrder(e){
      e.preventDefault();setError('orderError','');$('orderSuccess').classList.add('hide');
      const btn=$('saveOrder');btn.disabled=true;btn.textContent='جاري حفظ الطلب...';
      try{
        await verifiedAdmin();
        const merchant_id=$('orderMerchant').value,driver_id=$('orderDriver').value||null;
        const shop=currentData.merchants.find(m=>m.id===merchant_id);
        if(!shop?.is_active)throw Error('اختار محلاً نشطاً.');
        if(driver_id&&!currentData.drivers.some(d=>d.id===driver_id&&d.is_active&&d.is_available))throw Error('المندوب المحدد غير متاح حالياً. اضغط تحديث.');
        const customer_name=$('orderCustomer').value.trim(),customer_phone=$('orderPhone').value.trim(),delivery_address=$('orderAddress').value.trim();
        if(!customer_name||!customer_phone||!delivery_address)throw Error('أكمل بيانات الزبون ورقم الهاتف والعنوان.');
        const fee=validDinars($('orderFee').value,'أجرة التوصيل');const earning=$('orderDriverEarning').value.trim()===''?null:validDinars($('orderDriverEarning').value,'حصة المندوب');if(earning!==null&&earning>fee)throw Error('حصة المندوب لا تتجاوز أجرة التوصيل.');
        const goods=$('orderGoodsType').value==='أخرى'?$('orderGoodsOther').value.trim():$('orderGoodsType').value,gov=$('orderGovernorate').value;if(!gov||goods.length<2||goods.length>80)throw Error('حدد المحافظة ونوع البضاعة.');const payload={merchant_id,driver_id,customer_name,customer_phone,delivery_address,delivery_governorate:gov,goods_type:goods,order_amount_iqd:validDinars($('orderAmount').value,'مبلغ الطلب'),delivery_fee_iqd:fee,collection_method:$('orderCollectionMethod').value,driver_earning_iqd:earning,status:driver_id?'assigned':'pending',notes:$('orderNotes').value.trim()||null};
        const {data,error}=await sb.from('orders').insert(payload).select('id').single();if(error)throw error;
        $('orderForm').reset();$('orderGoodsOtherWrap').classList.add('hide','hidden');$('orderGoodsOther').required=false;$('orderSuccess').textContent='تم حفظ الطلب بنجاح: '+shortId(data.id)+' — تگدر تشوفه في الجدول.';$('orderSuccess').classList.remove('hide');
        await refreshData();selectView('orders');
      }catch(err){setError('orderError',err.message||String(err));}
      finally{btn.disabled=false;btn.textContent='حفظ الطلب';}
    }
    async function saveManageOrder(e){
      e.preventDefault();setError('manageOrderError','');$('manageOrderSuccess').classList.add('hide');
      const btn=$('saveManageOrder');btn.disabled=true;btn.textContent='جاري الحفظ...';
      try{
        await verifiedAdmin();
        const id=$('manageOrderId').value,o=currentData.orders.find(x=>x.id===id);
        if(!o)throw Error('الطلب غير موجود، اضغط تحديث.');
        const driver_id=$('manageOrderDriver').value||null,status=$('manageOrderStatus').value;
        if(!(allowedTransitions[o.status]||[]).includes(status))throw Error('انتقال الحالة غير مسموح.');
        if(['assigned','picked_up','on_the_way','delivered'].includes(status)&&!driver_id)throw Error('اختار مندوباً قبل تغيير الحالة إلى '+statusNames[status]+'.');
        if(status==='pending'&&driver_id)throw Error('إذا اخترت مندوباً لازم تكون الحالة «تم تعيين المندوب».');
        if(['picked_up','on_the_way','delivered','returned'].includes(o.status)&&o.driver_id!==driver_id)throw Error('لا يمكن تبديل المندوب بعد استلام الطلب في هذه النسخة.');
        if(driver_id&&o.driver_id!==driver_id&&!currentData.drivers.some(d=>d.id===driver_id&&d.is_active&&d.is_available))throw Error('المندوب غير متاح حالياً.');
        const {data,error}=await sb.from('orders').update({driver_id,status,updated_at:new Date().toISOString()}).eq('id',id).eq('status',o.status).select('id');
        if(error)throw error;if(!data?.length)throw Error('تم تغيير الطلب من جهاز آخر؛ اضغط تحديث وحاول مرة ثانية.');
        $('manageOrderSuccess').textContent='تم حفظ المندوب وحالة الطلب بنجاح.';$('manageOrderSuccess').classList.remove('hide');await refreshData();
      }catch(err){setError('manageOrderError',err.message||String(err));}
      finally{btn.disabled=false;btn.textContent='حفظ التعديلات';}
    }
    $('orderForm').addEventListener('submit',saveNewOrder);
    $('manageOrderForm').addEventListener('submit',saveManageOrder);
    async function verifiedAdmin(){const {data:{user},error}=await sb.auth.getUser();if(error||!user||!await requireAdmin(user))throw Error('انتهت صلاحية جلسة المدير. سجّل دخولك من جديد.');}
    // A Supabase Edge Function creates Auth users on the server after verifying the caller's admin role.
    // No privileged API key or password is persisted in browser storage.
    function createSecurePassword(){
      const characters='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$%';
      const array=new Uint32Array(18);crypto.getRandomValues(array);
      return Array.from(array,n=>characters[n%characters.length]).join('');
    }
    function resetAccountInputs(prefix){
      $(prefix+'Password').type='password';$(prefix+'ConfirmPassword').type='password';
      $(prefix+'CopyCredentials').classList.add('hide');
    }
    document.querySelectorAll('[data-password-generate]').forEach(button=>button.addEventListener('click',()=>{
      const prefix=button.dataset.passwordGenerate;
      const password=createSecurePassword();
      $(prefix+'Password').value=password;$(prefix+'ConfirmPassword').value=password;
      $(prefix+'Password').type='text';$(prefix+'ConfirmPassword').type='text';
    }));
    document.querySelectorAll('[data-password-toggle]').forEach(button=>button.addEventListener('click',()=>{
      const prefix=button.dataset.passwordToggle;
      const show=$(prefix+'Password').type==='password';
      $(prefix+'Password').type=show?'text':'password';$(prefix+'ConfirmPassword').type=show?'text':'password';
    }));
    for(const prefix of ['merchant','driver']){
      $(prefix+'CopyCredentials').addEventListener('click',async()=>{
        try{await navigator.clipboard.writeText('برق للتوصيل السريع\n'+(prefix==='driver'?'اسم المستخدم: '+$('driverUsername').value.trim()+'\nرقم الهاتف: '+$('driverPhone').value.trim()+'\n':'')+'البريد: '+$(prefix+'Email').value.trim()+'\nكلمة المرور: '+$(prefix+'Password').value);}
        catch{alert('تعذّر النسخ تلقائياً. انسخ البريد وكلمة المرور من الحقول.');}
      });
    }
    async function callCreateAccount(body){
      const {data,error}=await sb.functions.invoke('barq-create-account',{body});
      if(error){
        let message=error.message||'تعذر إنشاء الحساب.';
        if(error.context && typeof error.context.json==='function'){
          try{const details=await error.context.json();message=details.error||details.message||message;}catch{}
        }
        throw Error(message);
      }
      if(!data?.ok)throw Error(data?.error||'لم يكتمل إنشاء الحساب.');
      return data;
    }
    async function setMerchantGovernorate(merchantId,governorate){
      if(!merchantId||!BARQ_IRAQ_GOVERNORATES.includes(governorate))throw Error('اختر محافظة عراقية صحيحة');
      const {error}=await sb.rpc('barq_admin_set_merchant_governorate_v22',{
        p_merchant_id:merchantId,p_governorate:governorate
      });
      if(error)throw Error(error.message||'تعذر حفظ المحافظة');
    }
    $('merchantGovernorateForm').addEventListener('submit',async e=>{
      e.preventDefault();setError('merchantGovernorateError','');
      const save=$('saveMerchantGovernorate'),id=$('merchantGovernorateId').value;
      const gov=$('merchantGovernorateEdit').value;
      if(!BARQ_IRAQ_GOVERNORATES.includes(gov))return setError('merchantGovernorateError','اختر محافظة من القائمة');
      save.disabled=true;
      try{
        await verifiedAdmin();await setMerchantGovernorate(id,gov);
        $('merchantGovernorateModal').classList.add('hide');await refreshData();
      }catch(err){setError('merchantGovernorateError','تعذر حفظ المحافظة: '+(err.message||String(err)));}
      finally{save.disabled=false;}
    });
    async function saveNewMerchant(e){
      e.preventDefault();setError('merchantError','');$('merchantSuccess').classList.add('hide');
      const button=$('saveMerchant');button.disabled=true;button.textContent='جاري إنشاء الحساب...';
      try{
        await verifiedAdmin();
        const email=$('merchantEmail').value.trim().toLowerCase(),password=$('merchantPassword').value;
        if(password!==$('merchantConfirmPassword').value)throw Error('كلمتا المرور غير متطابقتين.');
        const governorate=$('merchantGovernorate').value;
        if(!BARQ_IRAQ_GOVERNORATES.includes(governorate))throw Error('اختر محافظة المحل من القائمة');
        const payload={kind:'merchant',email,password,merchant_name:$('merchantName').value.trim(),
          owner_name:$('merchantOwnerName').value.trim(),merchant_type:$('merchantType').value,
          phone:$('merchantPhone').value.trim(),address:$('merchantAddress').value.trim()};
        // Keep current barq-create-account Edge Function unchanged.
        const created=await callCreateAccount(payload);
        $('merchantCopyCredentials').classList.remove('hide');
        let govSaved=false,govIssue='';
        try{
          if(!created?.user_id)throw Error('الحساب تم إنشاؤه لكن لم يرجع معرّفه');
          const {data:shop,error:findError}=await sb.from('merchants')
            .select('id').eq('owner_id',created.user_id).maybeSingle();
          if(findError)throw findError;
          if(!shop?.id)throw Error('تعذر العثور على سجل المحل الجديد');
          await setMerchantGovernorate(shop.id,governorate);
          govSaved=true;
        }catch(err){govIssue=err.message||String(err);}
        if(govSaved){
          $('merchantSuccess').textContent='تم إنشاء حساب المحل وتسجيل محافظته ('+governorate+') بنجاح ✅. احفظ بيانات الدخول.';
          button.textContent='تمت الإضافة';
        }else{
          // Never encourage creating a second auth user after partial success.
          $('merchantSuccess').textContent='تم إنشاء الحساب فعلياً. احفظ بيانات الدخول؛ المحافظة تحتاج إعادة حفظ من زر «تحديد المحافظة» بالقائمة.';
          setError('merchantError','لم تنحفظ المحافظة: '+govIssue+'. لا تعِد إنشاء الحساب مرة ثانية. شغّل SQL ثم استخدم «تحديد المحافظة».');
          button.textContent='الحساب أُنشئ';
        }
        $('merchantSuccess').classList.remove('hide');
        await refreshData();
        return;
      }catch(err){setError('merchantError',err.message||String(err));}
      finally{button.disabled=false;if(button.textContent!=='تمت الإضافة')button.textContent='إنشاء الحساب وإضافة المحل';}
    }
    async function saveNewDriver(e){
      e.preventDefault();setError('driverError','');$('driverSuccess').classList.add('hide');
      const button=$('saveDriver');button.disabled=true;button.textContent='جاري إنشاء الحساب...';
      try{
        await verifiedAdmin();
        const email=$('driverEmail').value.trim().toLowerCase(),password=$('driverPassword').value;
        const username=$('driverUsername').value.trim().toLowerCase();
        if(!/^[a-z][a-z0-9_]{3,23}$/.test(username))throw Error('اسم المستخدم غير صحيح: ابدأ بحرف إنجليزي، 4-24 رمزاً.');
        if(password!==$('driverConfirmPassword').value)throw Error('كلمتا المرور غير متطابقتين.');
        const payload={kind:'driver',email,password,full_name:$('driverName').value.trim(),
          phone:$('driverPhone').value.trim(),vehicle_type:$('driverVehicle').value};
        const selectedCode=$('driverBranch').value;
        const targetBranch=brq41ActiveBranches.find(b=>b.code===selectedCode);
        if(!targetBranch)throw Error('اختر فرعاً نشطاً من القائمة قبل إنشاء المندوب.');
        const created=await callCreateAccount(payload);
        $('driverCopyCredentials').classList.remove('hide');
        let aliasSaved=false,aliasIssue='';
        try{
          if(!created?.user_id)throw Error('تعذر الحصول على معرف الحساب');
          const {error:aliasError}=await sb.rpc('barq_admin_set_driver_alias_v36',{
            p_user_id:created.user_id,p_username:username,p_phone:$('driverPhone').value.trim()
          });
          if(aliasError)throw aliasError;
          aliasSaved=true;
        }catch(ex){aliasIssue=ex.message||String(ex);}
        let linked=false,branchIssue='';
        try{
          if(!created?.user_id)throw Error('لم يُرجع إنشاء الحساب معرف المندوب');
          const {error:linkError}=await sb.rpc('barq_admin_assign_new_driver_branch_v41',{
            p_user_id:created.user_id,p_branch_code:selectedCode
          });
          if(linkError)throw linkError;
          linked=true;
        }catch(linkErr){branchIssue=linkErr.message||String(linkErr);}
        if(linked && aliasSaved){
          $('driverSuccess').textContent='تم إنشاء المندوب وربطه بفرع '+brq41BranchName(targetBranch)+' وباسم المستخدم '+username+' بنجاح ✅ احفظ بيانات دخوله.';
          $('driverSuccess').classList.remove('hide');
        }else{
          setError('driverError','تم إنشاء الحساب فعلياً؛ '+(!linked?'ربط الفرع: '+branchIssue+'. ':'')+(!aliasSaved?'اسم المستخدم: '+aliasIssue+'. ':'')+'لا تنشئ الحساب مرة ثانية؛ أصلح من قائمة المندوبين.');
          $('driverSuccess').textContent='حساب المندوب موجود. احفظ بيانات الدخول أولاً ثم أصلح الربط.';
          $('driverSuccess').classList.remove('hide');
        }
        await refreshData();
        button.textContent=(linked&&aliasSaved)?'تمت الإضافة':'الحساب أُنشئ';
        return;
      }catch(err){setError('driverError',err.message||String(err));}
      finally{button.disabled=false;if(button.textContent!=='تمت الإضافة')button.textContent='إنشاء الحساب وإضافة المندوب';}
    }
    $('merchantForm').addEventListener('submit',saveNewMerchant);
    $('driverForm').addEventListener('submit',saveNewDriver);

    const finMethodName = m => m==='full_cod'?'المبلغ الكامل':m==='delivery_fee_only'?'التوصيل فقط':'غير محدد';
    async function refreshFinance(showErrors=true){
      const {data,error}=await sb.rpc('admin_delivery_finance_orders');
      if(error){financeRows=[];setError('financeLoadError','تعذر تحميل الحسابات: '+error.message);if(showErrors)throw error;return;}
      setError('financeLoadError','');financeRows=data||[];renderFinance();
    }
    function renderFinance(){
      if(!$('financeRows'))return;
      updateOverviewMargin();
      const ready=financeRows.filter(r=>r.finance_ready);
      const remainDriver=r=>Math.max(0,Number(r.driver_remittance_due_iqd||0)-Number(r.driver_remitted_iqd||0));
      const remainShop=r=>Math.max(0,Number(r.merchant_payout_due_iqd||0)-Number(r.merchant_paid_iqd||0));
      $('financeMargin').textContent=money(ready.reduce((n,r)=>n+Number(r.company_margin_iqd||0),0))+' د.ع';
      $('financeDriverDue').textContent=money(ready.reduce((n,r)=>n+remainDriver(r),0))+' د.ع';
      $('financeMerchantDue').textContent=money(ready.reduce((n,r)=>n+remainShop(r),0))+' د.ع';
      $('financeNeedsSetup').textContent=money(financeRows.filter(r=>r.order_status==='delivered'&&!r.finance_ready).length);
      $('financeRows').innerHTML=financeRows.length?financeRows.map(r=>{
        const canSet=(r.order_status==='delivered'||r.order_status==='pending'||r.order_status==='assigned'||r.order_status==='picked_up'||r.order_status==='on_the_way');
        const d=remainDriver(r),m=remainShop(r);
        const controls=`${canSet?`<button class="tiny-action" data-finance-terms="${esc(r.order_id)}">تحديد الحساب</button>`:''}
          ${r.finance_ready&&d>0?`<button class="tiny-action" data-finance-settle="${esc(r.order_id)}" data-kind="driver_remittance">استلام من المندوب</button>`:''}
          ${r.finance_ready&&m>0?`<button class="tiny-action" data-finance-settle="${esc(r.order_id)}" data-kind="merchant_payout">دفع للمحل</button>`:''}`;
        return `<tr><td>${shortId(r.order_id)}<div class="hint">${nice(r.merchant_name)}</div></td><td>${pill(r.order_status)}</td><td>${finMethodName(r.collection_method)}</td><td>${r.driver_earning_iqd==null?'—':money(r.driver_earning_iqd)}</td><td>${r.finance_ready?money(r.company_margin_iqd):'—'}</td><td>${r.finance_ready?money(d):'—'}</td><td>${r.finance_ready?money(m):'—'}</td><td><div class="actions">${controls||'—'}</div></td></tr>`;
      }).join(''):rowEmpty(8,'لا توجد طلبات حالياً');
    }
    $('refreshFinance').addEventListener('click',async()=>{try{await verifiedAdmin();await refreshFinance();}catch(e){setError('financeLoadError',e.message||String(e));}});
    document.addEventListener('click',e=>{
      const terms=e.target.closest('[data-finance-terms]');
      if(terms){const r=financeRows.find(x=>x.order_id===terms.dataset.financeTerms);if(!r)return;
        $('financeTermsId').value=r.order_id;$('financeTermsOrder').textContent='طلب '+shortId(r.order_id)+' — أجرة التوصيل: '+money(r.delivery_fee_iqd)+' د.ع';
        $('financeTermsMethod').value=r.collection_method==='delivery_fee_only'?'delivery_fee_only':'full_cod';
        $('financeTermsEarning').value=r.driver_earning_iqd??'';$('financeTermsEarning').max=String(r.delivery_fee_iqd);
        setError('financeTermsError','');$('financeTermsModal').classList.remove('hide');return;}
      const settle=e.target.closest('[data-finance-settle]');if(!settle)return;
      const r=financeRows.find(x=>x.order_id===settle.dataset.financeSettle);if(!r)return;
      const kind=settle.dataset.kind;
      const due=kind==='driver_remittance'?Number(r.driver_remittance_due_iqd)-Number(r.driver_remitted_iqd):Number(r.merchant_payout_due_iqd)-Number(r.merchant_paid_iqd);
      $('settlementOrder').value=r.order_id;$('settlementType').value=kind;
      $('settlementTitle').textContent=kind==='driver_remittance'?'تسجيل مبلغ مستلم من المندوب':'تسجيل مبلغ مدفوع للمحل';
      $('settlementDescription').textContent='متبقي لهذه الحركة: '+money(due)+' د.ع. لا تضغط تأكيد قبل حصول التحويل الفعلي.';
      $('settlementAmount').value=String(due);$('settlementAmount').max=String(due);$('settlementNote').value='';
      setError('settlementError','');$('financeSettlementModal').classList.remove('hide');
    });
    $('financeTermsForm').addEventListener('submit',async e=>{e.preventDefault();setError('financeTermsError','');const b=$('saveFinanceTerms');b.disabled=true;
      try{await verifiedAdmin();const params={p_order_id:$('financeTermsId').value,p_collection_method:$('financeTermsMethod').value,p_driver_earning_iqd:validDinars($('financeTermsEarning').value,'حصة المندوب')};const {error}=await sb.rpc('admin_set_order_finance',params);if(error)throw error;closeModal('financeTermsModal');await refreshData();selectView('finance');}
      catch(err){setError('financeTermsError',err.message||String(err));}finally{b.disabled=false;}
    });
    $('financeSettlementForm').addEventListener('submit',async e=>{e.preventDefault();setError('settlementError','');const b=$('saveSettlement');b.disabled=true;
      try{await verifiedAdmin();const amount=validDinars($('settlementAmount').value,'المبلغ');if(amount<=0)throw Error('المبلغ يجب أن يكون أكبر من صفر.');
        const params={p_order_id:$('settlementOrder').value,p_movement_type:$('settlementType').value,p_amount_iqd:amount,p_note:$('settlementNote').value.trim()||null};
        const {error}=await sb.rpc('admin_record_delivery_settlement',params);if(error)throw error;closeModal('financeSettlementModal');await refreshFinance();}
      catch(err){setError('settlementError',err.message||String(err));}finally{b.disabled=false;}
    });
    $('loginForm').addEventListener('submit',async e=>{e.preventDefault();setError('loginError','');$('loginButton').disabled=true;$('loginButton').textContent='جاري التحقق...';try{if(!sb){const cfg=loadConfig();if(!cfg)throw Error('الاتصال غير مهيأ من الإدارة.');initialize(cfg)}const {data,error}=await sb.auth.signInWithPassword({email:$('email').value.trim(),password:$('password').value});if(error)throw error;if(!await requireAdmin(data.user)){await sb.auth.signOut();throw Error('الحساب غير مفعّل كمدير. تأكد من role = admin في جدول profiles.')} $('password').value='';await enterApp(data.user)}catch(err){setError('loginError',err.message||'فشل تسجيل الدخول.')}finally{$('loginButton').disabled=false;$('loginButton').textContent='تسجيل الدخول'}});
    async function logOut(){try{if(sb)await sb.auth.signOut()}catch{}currentData={merchants:[],drivers:[],orders:[],profiles:[]};$('password').value='';showPage('loginPage')}
    $('logoutBtn').addEventListener('click',logOut);$('sidebarLogout').addEventListener('click',logOut);$('refreshBtn').addEventListener('click',refreshData);
    document.querySelectorAll('[data-view]').forEach(btn=>btn.addEventListener('click',()=>selectView(btn.dataset.view)));

    // BARQ V13: company-issued paper receipt books with QR opening /merchant/.
    let barqAdminReceipts=[],barqAdminSingle=null;
    const barqQrLink=code=>window.location.origin+'/merchant/#receipt='+encodeURIComponent(code);
    function barqQrRender(mount,code,size=145){
      mount.innerHTML='';
      if(!window.QRCode){mount.textContent='تعذر تحميل مكتبة QR. تأكد من الإنترنت.';return;}
      new window.QRCode(mount,{text:barqQrLink(code),width:size,height:size,correctLevel:QRCode.CorrectLevel.M});
    }
    function barqBatchShow(list,store){
      barqAdminReceipts=list;
      $('barqReceiptBatchTiles').innerHTML=list.map((r,i)=>'<div class="barq-qr-tile"><strong>⚡ برق · وصل رقم '+esc(String(r.receipt_number||'—'))+'</strong><small>'+esc(store)+'</small><div id="barqBatchQR'+i+'" style="display:flex;justify-content:center"></div><small class="barq-code">'+esc(r.receipt_code)+'</small></div>').join('');
      list.forEach((r,i)=>barqQrRender($('barqBatchQR'+i),r.receipt_code,135));
      $('barqPrintBatch').style.display=list.length?'inline-flex':'none';
    }
    // BARQ V15 — print preview runs INSIDE the admin page, never in about:blank.
    // Android tablets and PWA browsers often show an empty page for window.open('') + document.write().
    function barqQrPrintReceipts(receipts,store){
      if(!receipts.length){alert('لا توجد وصولات للطباعة.');return;}
      const fmt=$('barqPrintFormat')?.value||'thermal';
      const escPrint=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
      const logo=new URL('./branding/barq-logo.png',window.location.href).href;
      const cards=receipts.map(r=>{
        const image=r.mount?.querySelector('img')||r.mount?.querySelector('canvas');
        let src='';
        try{src=image?.tagName==='CANVAS'?image.toDataURL('image/png'):(image?.src||'');}catch(e){src='';}
        if(!src)return '';
        const number=r.receipt_number||'—';
        return `<section class="bp-ticket">
          <div class="bp-heading"><img src="${escPrint(logo)}" alt="شعار برق"><div><b>برق للتوصيل السريع</b><small>وصل استلام طلب — رقم <span dir="ltr">${escPrint(number)}</span></small></div></div>
          <div class="bp-line"><strong>اسم المتجر</strong><span>${escPrint(store)}</span></div>
          <div class="bp-line"><strong>محافظة المستلم</strong><span></span></div>
          <div class="bp-line"><strong>أقرب نقطة دالة</strong><span></span></div>
          <div class="bp-line"><strong>هاتف المستلم</strong><span></span></div>
          <div class="bp-code"><img src="${escPrint(src)}" alt="باركود الوصل"><div>امسح الرمز بكاميرا موبايل المحل<br>لإدخال معلومات الزبون والطلب</div></div>
          <div class="bp-code128"><svg data-v29-code128="${escPrint(r.receipt_code)}"></svg></div><small class="bp-receipt-code" dir="ltr">${escPrint(r.receipt_code)}</small>
          <footer>وصل مخصص لمحل واحد · لا يُستخدم لأكثر من طلب</footer>
        </section>`;
      }).filter(Boolean).join('');
      if(!cards){alert('رموز QR لم تكتمل بعد، انتظر ظهورها ثم اضغط طباعة.');return;}
      document.getElementById('barqInlinePrint')?.remove();
      document.getElementById('barqInlinePrintStyle')?.remove();
      const style=document.createElement('style');style.id='barqInlinePrintStyle';
      style.textContent=`
#barqInlinePrint{position:fixed;inset:0;z-index:999999;overflow:auto;overscroll-behavior:contain;background:#e9edf2;color:#172333;direction:rtl;font-family:Tahoma,Arial,sans-serif;-webkit-overflow-scrolling:touch}
#barqInlinePrint,#barqInlinePrint *{box-sizing:border-box}
#barqInlinePrint .bp-tools{position:sticky;top:0;z-index:2;display:flex;align-items:center;justify-content:center;gap:9px;flex-wrap:wrap;background:#071b38;color:white;padding:13px 10px;box-shadow:0 4px 20px #001a3f22}
#barqInlinePrint .bp-tools button{border:0;border-radius:10px;font-weight:800;font-size:14px;padding:11px 16px;cursor:pointer;background:#ff831e;color:#fff;width:auto}
#barqInlinePrint .bp-tools .bp-close{background:#fff;color:#122b47}
#barqInlinePrint .bp-tools p{margin:0;font-size:12px;line-height:1.7;max-width:390px;color:#e2eafa}
#barqInlinePrint .bp-sheet{padding:16px;display:grid;justify-content:center;gap:14px;grid-template-columns:repeat(2,80mm);align-items:start}
#barqInlinePrint.bp-thermal .bp-sheet{grid-template-columns:80mm;gap:3px}
#barqInlinePrint .bp-ticket{width:80mm;min-height:130mm;padding:4mm 5mm 2mm;border:1px dashed #8f969d;background:white;display:flex;flex-direction:column;gap:2mm;color:#111;break-inside:avoid;page-break-inside:avoid;overflow:hidden}
#barqInlinePrint .bp-heading{display:flex;flex-direction:row-reverse;align-items:center;justify-content:space-between;border-bottom:1px solid #999;gap:2mm;padding-bottom:2mm;min-height:18mm}
#barqInlinePrint .bp-heading img{display:block;width:18mm;height:18mm;object-fit:contain;flex:0 0 18mm}
#barqInlinePrint .bp-heading b{display:block;font-size:12px;line-height:1.4}
#barqInlinePrint .bp-heading small{display:block;font-size:9px;line-height:1.6}
#barqInlinePrint .bp-line{min-height:9mm;border:1px solid #999;display:flex;align-items:stretch;font-size:10px}
#barqInlinePrint .bp-line strong{flex:0 0 27mm;display:flex;align-items:center;justify-content:center;text-align:center;padding:1mm;border-left:1px solid #999;background:#eee}
#barqInlinePrint .bp-line span{flex:1;display:flex;align-items:center;justify-content:center;padding:1mm;font-weight:bold;overflow-wrap:anywhere}
#barqInlinePrint .bp-code{margin:auto 0 0;text-align:center}
#barqInlinePrint .bp-code img{display:block;width:39mm;height:39mm;padding:2mm;object-fit:contain;image-rendering:pixelated;margin:0 auto;background:#fff}
#barqInlinePrint .bp-code div{font-size:9px;line-height:1.5}
#barqInlinePrint .bp-code128{display:flex;justify-content:center;align-items:center;max-width:68mm;overflow:hidden}#barqInlinePrint .bp-code128 svg{display:block;max-width:68mm;height:15mm;width:auto}#barqInlinePrint .bp-receipt-code{font:8px monospace;text-align:center;overflow-wrap:anywhere;display:block}
#barqInlinePrint .bp-ticket footer{text-align:center;font-size:8px;border-top:1px dotted #777;padding-top:1mm}
@media(max-width:670px){#barqInlinePrint .bp-sheet{grid-template-columns:80mm;padding:10px 4px}#barqInlinePrint .bp-tools{gap:6px}#barqInlinePrint .bp-tools p{flex-basis:100%;text-align:center;font-size:11px}}
@page{size:${fmt==='thermal'?'80mm 130mm':'A4'};margin:${fmt==='thermal'?'0':'6mm'}}
@media print{
  html,body{height:auto!important;overflow:visible!important;background:#fff!important}
  body.barq-is-printing>*:not(#barqInlinePrint):not(#barqInlinePrintStyle){display:none!important}
  body.barq-is-printing #barqInlinePrint{display:block!important;position:static!important;inset:auto!important;overflow:visible!important;background:white!important;box-shadow:none!important;width:100%!important;height:auto!important}
  body.barq-is-printing #barqInlinePrint .bp-tools{display:none!important}
  body.barq-is-printing #barqInlinePrint .bp-sheet{display:grid!important;justify-content:center!important;padding:0!important;gap:${fmt==='thermal'?'0':'4mm'}!important;grid-template-columns:${fmt==='thermal'?'80mm':'repeat(2,80mm)'}!important}
  body.barq-is-printing #barqInlinePrint .bp-ticket{width:80mm!important;height:130mm!important;min-height:130mm!important;max-height:130mm!important;border:${fmt==='thermal'?'0':'1px dashed #888'}!important;break-inside:avoid!important;page-break-inside:avoid!important}
  body.barq-is-printing #barqInlinePrint.bp-thermal .bp-ticket{break-after:page!important;page-break-after:always!important}
}
`;
      const overlay=document.createElement('div');overlay.id='barqInlinePrint';overlay.className=fmt==='thermal'?'bp-thermal':'bp-a4';
      overlay.setAttribute('role','dialog');overlay.setAttribute('aria-label','معاينة دفتر وصولات برق');
      overlay.innerHTML=`<div class="bp-tools"><button type="button" class="bp-close" id="barqInlinePrintClose">✕ إغلاق المعاينة</button><button type="button" id="barqInlinePrintGo">🖨️ طباعة / حفظ PDF</button><p>الوصولات ظاهرة هنا مباشرة حتى على التابلت، بدون فتح نافذة فارغة. للحفظ اختار «حفظ PDF» من خيارات الطباعة.</p></div><div class="bp-sheet">${cards}</div>`;
      document.head.appendChild(style);document.body.appendChild(overlay);
      overlay.querySelectorAll('[data-v29-code128]').forEach(svg=>{
        try{if(window.JsBarcode)window.JsBarcode(svg,svg.dataset.v29Code128,{format:'CODE128',displayValue:false,width:1,height:42,margin:1});
            else svg.parentElement.textContent='قارئ 1D يحتاج إعادة فتح الصفحة مع الإنترنت.';
        }catch(_){svg.parentElement.textContent='تعذر رسم Code128، استخدم QR أعلاه.';}
      });
      document.body.classList.add('barq-is-printing');
      const close=()=>{overlay.remove();style.remove();document.body.classList.remove('barq-is-printing');};
      overlay.querySelector('#barqInlinePrintClose').addEventListener('click',close);
      overlay.querySelector('#barqInlinePrintGo').addEventListener('click',()=>{
        requestAnimationFrame(()=>requestAnimationFrame(()=>{window.print();}));
      });
    }
    $('barqGenerateReceipts').addEventListener('click',()=>{
      $('barqReceiptMerchant').innerHTML=currentData.merchants.filter(m=>m.is_active).map(m=>'<option value="'+esc(m.id)+'">'+esc(m.name)+'</option>').join('');
      $('barqReceiptBatchTiles').innerHTML='';$('barqPrintBatch').style.display='none';barqAdminReceipts=[];
      $('barqAdminReceiptsModal').classList.remove('hide');
    });
    $('barqAdminReceiptsClose').addEventListener('click',()=>$('barqAdminReceiptsModal').classList.add('hide'));
    $('barqIssueBatch').addEventListener('click',async()=>{
      const btn=$('barqIssueBatch'),count=Number($('barqReceiptQuantity').value),mid=$('barqReceiptMerchant').value;
      if(!mid||!Number.isInteger(count)||count<1||count>100){$('barqReceiptAdminNotice').textContent='حدد محلاً نشطاً وعدد وصولات من 1 إلى 100.';return;}
      btn.disabled=true;
      const store=currentData.merchants.find(m=>m.id===mid)?.name||'';
      let list=[];
      try{
        for(let remaining=count;remaining>0;){
          const n=Math.min(remaining,40);
          $('barqReceiptAdminNotice').textContent='جاري إصدار الوصولات... '+list.length+' من '+count;
          const {data,error}=await sb.rpc('barq_admin_issue_receipt_book',{p_merchant_id:mid,p_quantity:n});
          if(error)throw error;
          list.push(...(data||[]).map(x=>({receipt_code:x.receipt_code,receipt_number:x.receipt_number})));
          remaining-=n;
        }
        barqBatchShow(list,store);
        $('barqReceiptAdminNotice').textContent='✅ تم إصدار '+list.length+' وصلاً. افتح «طباعة دفتر الوصولات» واطبعه أو احفظه PDF للطباعة لاحقاً.';
      }catch(e){
        if(list.length)barqBatchShow(list,store);
        $('barqReceiptAdminNotice').textContent='❌ '+(e.message||e)+' — تم إصدار '+list.length+' وصلاً؛ تگدر تعيد عرضها من زر الوصولات غير المستعملة.';
      }finally{btn.disabled=false;}
    });
    $('barqLoadUnused').addEventListener('click',async()=>{
      const btn=$('barqLoadUnused'),mid=$('barqReceiptMerchant').value;if(!mid)return;btn.disabled=true;
      try{
        const {data,error}=await sb.rpc('barq_admin_list_unused_receipt_book',{p_merchant_id:mid});if(error)throw error;
        const list=(data||[]).map(x=>({receipt_code:x.receipt_code,receipt_number:x.receipt_number}));
        barqBatchShow(list,currentData.merchants.find(m=>m.id===mid)?.name||'');
        $('barqReceiptAdminNotice').textContent='الوصولات غير المستخدمة: '+list.length+' (يعرض حتى 300 وصلاً).';
      }catch(e){$('barqReceiptAdminNotice').textContent='❌ '+(e.message||e)}finally{btn.disabled=false}
    });
    $('barqReceiptMerchant').addEventListener('change',()=>{barqAdminReceipts=[];$('barqReceiptBatchTiles').innerHTML='';$('barqPrintBatch').style.display='none';});
    $('barqPrintBatch').addEventListener('click',()=>{
      const store=$('barqReceiptMerchant').selectedOptions?.[0]?.textContent||'';
      barqQrPrintReceipts(barqAdminReceipts.map((r,i)=>({...r,mount:$('barqBatchQR'+i)})),store);
    });
    document.addEventListener('click',e=>{
      const b=e.target.closest('[data-barq-order-qr]');if(!b)return;
      const o=currentData.orders.find(o=>o.id===b.dataset.barqOrderQr);if(!o||!o.receipt_code)return;
      barqAdminSingle=o;
      $('barqAdminSingleInfo').textContent='طلب '+shortId(o.id)+' — '+o.customer_name;
      $('barqAdminSingleCode').textContent=o.receipt_code;
      barqQrRender($('barqAdminSingleCanvas'),o.receipt_code,180);
      $('barqAdminSingleQRModal').classList.remove('hide');
    });
    $('barqAdminSingleClose').addEventListener('click',()=>$('barqAdminSingleQRModal').classList.add('hide'));
    $('barqAdminPrintSingle').addEventListener('click',()=>{
      if(barqAdminSingle){
        const s=currentData.merchants.find(m=>m.id===barqAdminSingle.merchant_id)?.name||'';
        barqQrPrintReceipts([{receipt_code:barqAdminSingle.receipt_code,receipt_number:'—',mount:$('barqAdminSingleCanvas')}],s);
      }
    });


    // BARQ V16 — Returns and company warehouse (server-authorized, audit-friendly).
    let brqReturns=[],brqWarehouse=[],brqReturnedOrders=[],brqLogisticsLoaded=false;
    const brqStageLabels={awaiting_storage:'بانتظار المخزن',stored:'داخل المخزن',returned_to_merchant:'سُلِّم للمحل'};
    const brqConditions={good:'سليم',damaged:'تالف',unknown:'غير محدد'};
    const brqMovements={received:'استلام للمخزن',moved:'نقل الرف',released:'تسليم وخروج'};
    const brqDate=v=>v?new Date(v).toLocaleString('ar-IQ',{dateStyle:'short',timeStyle:'short'}):'—';
    const brqMerchantName=id=>esc(currentData.merchants.find(m=>m.id===id)?.name||'غير محدد');
    function brqSetNotice(message='',target='brqLogisticsNotice'){
      const el=$(target); if(!el)return;el.textContent=message;el.classList.toggle('hide',!message);
      if(message)setTimeout(()=>{if(el.textContent===message)el.classList.add('hide')},8500);
    }
    function brqOpen(id){$(id).classList.remove('hide');}
    function brqReturnStage(s){const cls=s==='returned_to_merchant'?'done':s==='stored'?'ok':'warn';return `<span class="barq-logistics-badge ${cls}">${esc(brqStageLabels[s]||s)}</span>`;}
    function brqWarehouseStage(s){return s==='stored'?'<span class="barq-logistics-badge ok">موجود بالمخزن</span>':'<span class="barq-logistics-badge done">تم التسليم</span>';}
    async function refreshLogistics(showErrors=true){
      if(!sb)return;
      const jobs=await Promise.all([
        sb.from('barq_returns').select('id,order_id,merchant_id,driver_id,reason,notes,status,created_at,received_at,released_at').order('created_at',{ascending:false}).limit(300),
        sb.from('barq_warehouse_items').select('id,order_id,return_id,merchant_id,description,quantity,shelf,condition,status,notes,received_at,released_at,receiver_name').order('received_at',{ascending:false}).limit(500),
        sb.from('orders').select('id,merchant_id,driver_id,customer_name,goods_type,receipt_code,status,created_at').eq('status','returned').order('created_at',{ascending:false}).limit(300)
      ]);
      const issue=jobs.find(x=>x.error)?.error;
      if(issue){
        if(showErrors||currentView==='returns'||currentView==='warehouse'){
          setError('brqLogisticsError','تعذر تحميل الرواجع: '+issue.message+' — تأكد من تشغيل SQL الخاص بـ V16.');
          setError('brqWarehouseError','تعذر تحميل المخزن: '+issue.message+' — تأكد من تشغيل SQL الخاص بـ V16.');
        }
        return;
      }
      brqReturns=jobs[0].data||[];
      brqWarehouse=jobs[1].data||[];
      brqReturnedOrders=jobs[2].data||[];
      brqLogisticsLoaded=true;
      setError('brqLogisticsError','');setError('brqWarehouseError','');
      renderLogistics();
      await brqRefreshIntercity();
      await brqV27RefreshIncoming();
      await brqV28RefreshFinal();
    }
    function renderLogistics(){
      if(!brqLogisticsLoaded)return;
      $('brqReturnsAwait').textContent=money(brqReturns.filter(r=>r.status==='awaiting_storage').length);
      $('brqReturnsStored').textContent=money(brqReturns.filter(r=>r.status==='stored').length);
      $('brqReturnsDone').textContent=money(brqReturns.filter(r=>r.status==='returned_to_merchant').length);
      const registered=new Set(brqReturns.map(r=>r.order_id));
      const unregistered=brqReturnedOrders.filter(o=>!registered.has(o.id));
      $('brqUnregisteredReturns').innerHTML=unregistered.length?unregistered.map(o=>`<tr><td>${shortId(o.id)}<small class="barq-code" style="display:block">${esc(o.receipt_code||'')}</small></td><td>${brqMerchantName(o.merchant_id)}</td><td>${esc(o.customer_name||'—')}</td><td>${esc(o.goods_type||'—')}</td><td><button type="button" class="tiny-action" data-brq-register="${esc(o.id)}">↩ تسجيل راجع</button></td></tr>`).join(''):rowEmpty(5,'ماكو طلبات حالتها مرتجع بدون سجل.');
      const filtered=brqReturns.filter(r=>$('brqReturnsFilter').value==='all'||r.status===$('brqReturnsFilter').value);
      $('brqReturnsRows').innerHTML=filtered.length?filtered.map(r=>{
        const item=brqWarehouse.find(i=>i.return_id===r.id);
        const actions=r.status==='awaiting_storage'?`<button type="button" class="tiny-action" data-brq-receive="${esc(r.id)}">📦 استلام بالمخزن</button>`:r.status==='stored'&&item?`<button type="button" class="tiny-action" data-brq-focus-item="${esc(item.id)}">↗ عرض بالمخزن</button>`:'—';
        return `<tr><td>${shortId(r.order_id)}</td><td>${brqMerchantName(r.merchant_id)}</td><td>${esc(r.reason)}${r.notes?`<small style="display:block">${esc(r.notes)}</small>`:''}</td><td>${brqDate(r.created_at)}</td><td>${brqReturnStage(r.status)}</td><td>${actions}</td></tr>`;
      }).join(''):rowEmpty(6,'لا توجد رواجع بهذا التصنيف.');
      const stored=brqWarehouse.filter(i=>i.status==='stored');
      $('brqWarehouseStored').textContent=money(stored.length);
      $('brqWarehouseQuantity').textContent=money(stored.reduce((n,i)=>n+Number(i.quantity||0),0));
      $('brqWarehouseReleased').textContent=money(brqWarehouse.filter(i=>i.status==='released').length);
      const warehouseFiltered=brqWarehouse.filter(i=>$('brqWarehouseFilter').value==='all'||i.status===$('brqWarehouseFilter').value);
      $('brqWarehouseRows').innerHTML=warehouseFiltered.length?warehouseFiltered.map(i=>{
        const ctrls=i.status==='stored'?`<button type="button" class="tiny-action" data-brq-move="${esc(i.id)}">نقل الرف</button>${i.order_id?'':`<button type="button" class="tiny-action" data-brq-release="${esc(i.id)}">تسليم</button>`}`:'';
        return `<tr id="brq-item-${esc(i.id)}"><td>${shortId(i.id)}${i.return_id?'<small class="pill orange" style="display:block;margin-top:5px">راجع</small>':''}${i.order_id?'<small class="pill blue" style="display:block;margin-top:5px">شحن محافظة</small>':''}</td><td>${brqMerchantName(i.merchant_id)}</td><td>${esc(i.description)}</td><td>${money(i.quantity)}</td><td>${esc(i.shelf)}</td><td>${brqWarehouseStage(i.status)}</td><td>${brqDate(i.received_at)}</td><td><div class="barq-logistics-action">${ctrls}<button type="button" class="tiny-action" data-brq-history="${esc(i.id)}">سجل الحركة</button></div></td></tr>`;
      }).join(''):rowEmpty(8,'المخزن فارغ بهذا التصنيف.');
    }
    $('brqReturnsFilter').addEventListener('change',renderLogistics);
    $('brqWarehouseFilter').addEventListener('change',renderLogistics);
    $('brqRefreshReturns').addEventListener('click',()=>refreshLogistics(true));
    $('brqRefreshWarehouse').addEventListener('click',()=>refreshLogistics(true));
    $('brqAddWarehouseItem').addEventListener('click',()=>{
      $('brqWarehouseAddForm').reset();setError('brqWarehouseAddError','');
      $('brqWarehouseMerchant').innerHTML='<option value="">بدون محل</option>'+currentData.merchants.map(m=>`<option value="${esc(m.id)}">${esc(m.name)}</option>`).join('');
      brqOpen('brqWarehouseAddModal');
    });
    function brqFindOrder(id){return brqReturnedOrders.find(o=>o.id===id)||currentData.orders.find(o=>o.id===id)}
    document.addEventListener('click',async e=>{
      const b=e.target.closest('[data-brq-register],[data-brq-receive],[data-brq-focus-item],[data-brq-move],[data-brq-release],[data-brq-history]');
      if(!b)return;
      if(b.dataset.brqRegister){
        const o=brqFindOrder(b.dataset.brqRegister);if(!o)return;
        $('brqReturnForm').reset();$('brqReturnOrderId').value=o.id;
        $('brqReturnOrderLabel').textContent='طلب '+shortId(o.id)+' — '+(currentData.merchants.find(m=>m.id===o.merchant_id)?.name||'—');
        setError('brqReturnModalError','');brqOpen('brqReturnModal');return;
      }
      if(b.dataset.brqReceive){
        const r=brqReturns.find(x=>x.id===b.dataset.brqReceive);if(!r)return;
        $('brqReceiveForm').reset();$('brqReceiveReturnId').value=r.id;
        $('brqReceiveLabel').textContent='راجع طلب '+shortId(r.order_id)+' — '+r.reason;
        setError('brqReceiveModalError','');brqOpen('brqReceiveModal');return;
      }
      if(b.dataset.brqFocusItem){selectView('warehouse');$('brqWarehouseFilter').value='stored';renderLogistics();setTimeout(()=>document.getElementById('brq-item-'+b.dataset.brqFocusItem)?.scrollIntoView({behavior:'smooth',block:'center'}),50);return;}
      if(b.dataset.brqMove){const i=brqWarehouse.find(x=>x.id===b.dataset.brqMove);if(!i)return;
        $('brqMoveForm').reset();$('brqMoveItemId').value=i.id;$('brqMoveItemLabel').textContent=i.description+' — الرف الحالي: '+i.shelf;
        $('brqMoveNewShelf').value=i.shelf;setError('brqMoveError','');brqOpen('brqMoveModal');return;}
      if(b.dataset.brqRelease){const i=brqWarehouse.find(x=>x.id===b.dataset.brqRelease);if(!i)return;
        $('brqReleaseForm').reset();$('brqReleaseItemId').value=i.id;
        $('brqReleaseLabel').textContent=i.description+' — '+(i.return_id?'طرد راجع يُسلَّم للمحل':'طرد مخزن');
        setError('brqReleaseError','');brqOpen('brqReleaseModal');return;}
      if(b.dataset.brqHistory){const i=brqWarehouse.find(x=>x.id===b.dataset.brqHistory);if(!i)return;
        $('brqHistoryLabel').textContent=i.description+' — '+i.shelf;
        $('brqHistoryList').textContent='جارٍ تحميل سجل الحركة...';brqOpen('brqHistoryModal');
        const {data,error}=await sb.from('barq_warehouse_movements').select('action,from_shelf,to_shelf,details,created_at').eq('item_id',i.id).order('created_at',{ascending:false}).limit(100);
        if(error){$('brqHistoryList').textContent='تعذر تحميل سجل الحركة: '+error.message;return;}
        $('brqHistoryList').innerHTML=(data||[]).length?data.map(m=>`<div><strong>${esc(brqMovements[m.action]||m.action)}</strong><small>${brqDate(m.created_at)}</small>${m.from_shelf?'<div>من: '+esc(m.from_shelf)+'</div>':''}${m.to_shelf?'<div>إلى: '+esc(m.to_shelf)+'</div>':''}${m.details?'<div>'+esc(m.details)+'</div>':''}</div>`).join(''):'<div>لا توجد حركات.</div>';
      }
    });
    async function brqSubmitRpc(e,formId,errorId,modalId,func,params,noticeMsg,noticeTarget='brqLogisticsNotice'){
      e.preventDefault();setError(errorId,'');const form=$(formId),btn=form.querySelector('[type="submit"]');btn.disabled=true;
      try{
        await verifiedAdmin();const {error}=await sb.rpc(func,params());if(error)throw error;
        closeModal(modalId);await refreshData();brqSetNotice(noticeMsg,noticeTarget);
      }catch(ex){setError(errorId,ex.message||String(ex));}finally{btn.disabled=false;}
    }
    $('brqReturnForm').addEventListener('submit',e=>brqSubmitRpc(e,'brqReturnForm','brqReturnModalError','brqReturnModal','barq_admin_register_return',()=>({p_order_id:$('brqReturnOrderId').value,p_reason:$('brqReturnReason').value,p_notes:$('brqReturnNotes').value.trim()||null}),'تم تسجيل الطلب ضمن الرواجع بنجاح.'));
    $('brqReceiveForm').addEventListener('submit',e=>brqSubmitRpc(e,'brqReceiveForm','brqReceiveModalError','brqReceiveModal','barq_admin_receive_return',()=>({p_return_id:$('brqReceiveReturnId').value,p_shelf:$('brqReceiveShelf').value.trim(),p_condition:$('brqReceiveCondition').value,p_notes:$('brqReceiveNotes').value.trim()||null}),'تم استلام الطرد وحفظ مكانه في مخزن الشركة.'));
    $('brqWarehouseAddForm').addEventListener('submit',e=>brqSubmitRpc(e,'brqWarehouseAddForm','brqWarehouseAddError','brqWarehouseAddModal','barq_admin_store_warehouse_item',()=>({p_merchant_id:$('brqWarehouseMerchant').value||null,p_description:$('brqWarehouseDescription').value.trim(),p_quantity:parseInt($('brqWarehouseAmount').value,10),p_shelf:$('brqWarehouseShelf').value.trim(),p_condition:$('brqWarehouseCondition').value,p_notes:$('brqWarehouseNotes').value.trim()||null}),'تم تسجيل الطرد في المخزن.','brqWarehouseNotice'));
    $('brqMoveForm').addEventListener('submit',e=>brqSubmitRpc(e,'brqMoveForm','brqMoveError','brqMoveModal','barq_admin_move_warehouse_item',()=>({p_item_id:$('brqMoveItemId').value,p_shelf:$('brqMoveNewShelf').value.trim(),p_notes:$('brqMoveNotes').value.trim()||null}),'تم تغيير مكان الطرد وتوثيق الحركة.','brqWarehouseNotice'));
    $('brqReleaseForm').addEventListener('submit',e=>brqSubmitRpc(e,'brqReleaseForm','brqReleaseError','brqReleaseModal','barq_admin_release_warehouse_item',()=>({p_item_id:$('brqReleaseItemId').value,p_receiver_name:$('brqReleaseReceiver').value.trim(),p_notes:$('brqReleaseNotes').value.trim()||null}),'تم تسجيل تسليم الطرد وخروجه من المخزن.','brqWarehouseNotice'));

    // BARQ V19 — Province orders: driver arrives -> manager receives -> postal dispatch.
    let brqIntercityRoutes=[];
    // BARQ V29 — audit log of successful, role-checked barcode transitions.
    const brq29ActionNames={merchant_pickup:'استلام من المحل',direct_on_the_way:'بالطريق للزبون',direct_customer_delivery:'تسليم الزبون المحلي',
      arrive_origin_warehouse:'وصول مندوب لمخزن الانطلاق',origin_warehouse_receive:'دخول مخزن الانطلاق',
      baghdad_prepare_dispatch:'تجهيز تحويل بغداد',baghdad_handover_to_carrier:'خروج بغداد للناقل',
      basra_warehouse_receive:'استلام مخزن البصرة',basra_assign_final_driver:'تعيين مندوب البصرة',
      basra_handover_to_courier:'خروج المخزن لمندوب البصرة',basra_customer_delivery:'التسليم النهائي للزبون',
      prepare_branch_transfer:'تجهيز تحويل بين الفروع',handover_branch_transfer:'تسليم للناقل',receive_branch_transfer:'استلام تحويل الفرع'};
    async function brq29LoadScanHistory(){
      const btn=$('brq29HistoryRefresh');btn.disabled=true;$('brq29HistoryStatus').textContent='جاري جلب الحركات...';
      try{
        await verifiedAdmin();
        const {data,error}=await sb.rpc('barq_admin_scan_history_v29',{p_scan:$('brq29HistoryQuery').value.trim()||null});
        if(error)throw error;
        $('brq29HistoryRows').innerHTML=(data||[]).map(r=>`<tr><td class="barq-code">${esc(r.receipt_code||r.order_id)}</td><td>${esc(brq29ActionNames[r.action]||r.action)}</td><td>${esc(r.actor_name||'—')}</td><td>${esc(r.branch_name||'—')}</td><td>${esc(r.scanned_at?new Date(r.scanned_at).toLocaleString('ar-IQ'):'—')}</td></tr>`).join('')||rowEmpty(5,'ماكو عمليات مسح مطابقة بعد.');
        $('brq29HistoryStatus').textContent='تم تحميل '+(data||[]).length+' حركة (حد أقصى 200).';
      }catch(e){$('brq29HistoryStatus').textContent='تعذر قراءة السجل: '+(e.message||e);}
      finally{btn.disabled=false;}
    }
    $('brq29HistoryRefresh').addEventListener('click',brq29LoadScanHistory);
    $('brq29HistoryQuery').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();brq29LoadScanHistory();}});
    // BARQ V27: Basra warehouse - incoming Baghdad shipments, never accept before physical receipt.
    let brq27BasTransfers=[];
    async function brqV27RefreshIncoming(){
      if(!sb)return;
      setError('brq27BasError','');
      try{
        const {data,error}=await sb.rpc('barq_admin_incoming_bas_v27');if(error)throw error;
        brq27BasTransfers=data||[];
        $('brq27BasRows').innerHTML=brq27BasTransfers.length?brq27BasTransfers.map(t=>{
          const arrived=t.transfer_status==='received';
          return `<tr data-v27-bas-row="${esc(t.transfer_id)}"><td><strong class="barq-code">${esc(t.receipt_code||t.order_id)}</strong><small class="barq-code" style="display:block">${esc(t.order_id.slice(0,8))}</small></td><td>${esc(t.customer_name||'—')}<small style="display:block">${esc(t.goods_type||'—')}</small></td><td>${esc(t.transport_name||'—')}<small style="display:block">${esc(t.transport_reference||'—')}</small></td><td><span class="barq-logistics-badge ${arrived?'ok':'warn'}">${arrived?'✅ داخل مخزن البصرة':'🚚 بالطريق إلى البصرة'}</span></td><td>${arrived?'تم الاستلام':`<div style="display:grid;gap:6px;min-width:220px"><small>📷 سيُطلب مسح الباركود بالكاميرا أو القارئ</small><input data-v27-shelf maxlength="100" type="text" placeholder="رف البصرة، مثلاً BAS-A1" aria-label="مكان التخزين"><select data-v27-condition aria-label="حالة الطرد"><option value="good">سليم</option><option value="damaged">متضرر</option><option value="unknown">غير محدد</option></select><button type="button" class="tiny-action" data-v27-bas-receive="${esc(t.transfer_id)}">📦 تأكيد استلام الطرد</button></div>`}</td></tr>`;
        }).join(''):rowEmpty(5,'ماكو شحنات قادمة من بغداد حالياً.');
      }catch(e){setError('brq27BasError','تعذر تحميل وارد بغداد: '+(e.message||e)+' — تأكد من تنفيذ SQL V27.');}
    }
    $('brq27BasRefresh').addEventListener('click',brqV27RefreshIncoming);
    $('brq27BasRows').addEventListener('click',async e=>{
      const btn=e.target.closest('[data-v27-bas-receive]');if(!btn||btn.disabled)return;
      const row=btn.closest('[data-v27-bas-row]');
      const expected=brq27BasTransfers.find(x=>x.transfer_id===btn.dataset.v27BasReceive);
      if(!expected)return;
      const code=await BarqScannerV29.scan({title:'مسح وارد بغداد في مخزن البصرة',expectedCode:expected.receipt_code||expected.order_id});
      if(!code)return;
      const shelf=row.querySelector('[data-v27-shelf]').value.trim();
      const condition=row.querySelector('[data-v27-condition]').value;
      if(!code||!shelf||shelf.length>100)return setError('brq27BasError','لازم تدخل رمز الوصل الحقيقي وموقع رف مخزن البصرة.');
      if(!confirm('هل وصل الطرد فعلياً إلى مخزن البصرة، وتأكدت أن رمز الوصل يطابق الطرد الموجود أمامك؟'))return;
      btn.disabled=true;setError('brq27BasError','');
      try{
        await verifiedAdmin();
        const {error}=await sb.rpc('barq_bas_receive_from_bgd_v29',{
          p_transfer_id:btn.dataset.v27BasReceive,p_scan:code,p_shelf:shelf,p_condition:condition
        });if(error)throw error;
        await Promise.all([brqV27RefreshIncoming(),refreshLogistics(false)]);
        brqSetNotice('تم تأكيد دخول الطرد إلى مخزن البصرة ✅ — لم يسجّل تسليم الزبون أو تحصيل أي مبلغ.','brq27BasNotice');
      }catch(ex){setError('brq27BasError','تعذر استلام الطرد: '+(ex.message||ex));}
      finally{btn.disabled=false;}
    });
    // BARQ V28 — courier final mile for shipments physically received in BAS.
    let brq28FinalRows=[],brq28Drivers=[];
    async function brqV28RefreshFinal(){
      if(!sb)return;
      setError('brq28BasError','');
      try{
        const [ordersRes,driversRes]=await Promise.all([
          sb.rpc('barq_bas_final_mile_list_v28'),sb.rpc('barq_bas_final_drivers_v28')
        ]);
        if(ordersRes.error)throw ordersRes.error;
        if(driversRes.error)throw driversRes.error;
        brq28FinalRows=ordersRes.data||[];brq28Drivers=driversRes.data||[];
        const stateText={assigned:'تم تعيين المندوب — داخل المخزن',out_for_delivery:'خرج للمندوب — بانتظار باركود التسليم',delivered:'✅ تم التسليم للزبون'};
        $('brq28BasRows').innerHTML=brq28FinalRows.length?brq28FinalRows.map(r=>{
          const state=r.final_mile_state||'not_assigned';
          const options='<option value="">اختار مندوب البصرة</option>'+brq28Drivers.map(d=>`<option value="${esc(d.driver_id)}" ${d.driver_id===r.assigned_driver_id?'selected':''}>${esc(d.full_name||d.driver_id.slice(0,8))}</option>`).join('');
          const action=state==='not_assigned'
            ?`<div class="brq28-actions"><select data-v28-driver aria-label="اختيار مندوب البصرة">${options}</select><button type="button" class="tiny-action brq28-advance" data-v28-assign="${esc(r.order_id)}">👤 مسح الباركود وتعيين المندوب</button></div>`
            :state==='assigned'
              ?`<div class="brq28-actions"><div class="brq28-next">✅ المندوب معيّن. الخطوة التالية: سلّم الطرد له فعلياً، ثم امسح الباركود لتأكيد خروجه من المخزن.</div><button type="button" class="tiny-action brq28-advance" data-v28-handover="${esc(r.order_id)}">📦 مسح الباركود وتأكيد تسليم الطرد للمندوب</button><details class="brq28-reassign"><summary>تغيير المندوب المعيّن</summary><div class="brq28-reassign-fields"><select data-v28-driver aria-label="تغيير مندوب البصرة">${options}</select><button type="button" class="tiny-action" data-v28-assign="${esc(r.order_id)}">👤 تأكيد تغيير المندوب بالباركود</button></div></details></div>`
              :state==='out_for_delivery'?'🛵 بيد المندوب؛ يمسح QR عند الزبون':'✅ تم توثيق التسليم بالباركود';
          return `<tr data-v28-row="${esc(r.order_id)}"><td data-label="الوصل والزبون"><strong class="barq-code">${esc(r.receipt_code||r.order_id)}</strong><small style="display:block">${esc(r.customer_name||'—')} · ${esc(r.goods_type||'—')}</small></td><td data-label="الرف">${esc(r.warehouse_shelf||'—')}</td><td data-label="المندوب">${esc(r.courier_name||'غير معيّن')}</td><td data-label="حالة التوصيل"><span class="barq-logistics-badge ${state==='delivered'?'ok':state==='out_for_delivery'?'warn':''}">${esc(stateText[state]||'داخل مخزن البصرة — بانتظار التعيين')}</span></td><td data-label="الإجراء">${action}</td></tr>`;
        }).join(''):rowEmpty(5,'ماكو طرود مستلمة من بغداد تنتظر التوصيل حالياً.');
      }catch(e){setError('brq28BasError','تعذر تحميل التوصيل النهائي: '+(e.message||e)+' — تأكد من تنفيذ SQL V28.');}
    }
    $('brq28BasRefresh').addEventListener('click',brqV28RefreshFinal);
    $('brq28BasRows').addEventListener('click',async e=>{
      const btn=e.target.closest('[data-v28-assign],[data-v28-handover]');if(!btn||btn.disabled)return;
      const id=btn.dataset.v28Assign||btn.dataset.v28Handover;
      const row=btn.closest('[data-v28-row]');const r=brq28FinalRows.find(x=>x.order_id===id);if(!r)return;
      const assigning=!!btn.dataset.v28Assign;
      const driverId=row.querySelector('[data-v28-driver]')?.value;
      if(assigning&&!driverId)return setError('brq28BasError','اختار مندوب البصرة قبل مسح الباركود.');
      const code=await BarqScannerV29.scan({title:assigning?'مسح الطرد قبل تعيين مندوب البصرة':'مسح الطرد عند تسليمه لمندوب البصرة',expectedCode:r.receipt_code||r.order_id});
      if(!code)return;
      if(assigning&&!driverId)return setError('brq28BasError','اختار مندوب البصرة قبل التعيين.');
      if(!code)return setError('brq28BasError','امسح باركود الوصل حتى تكمل العملية.');
      if(!confirm(assigning?'تأكيد تعيين مندوب البصرة لهذا الطرد؟':'هل سلّمت الطرد فعلياً لمندوب البصرة وطابقت الباركود؟'))return;
      btn.disabled=true;setError('brq28BasError','');
      try{
        await verifiedAdmin();
        const {error}=await sb.rpc(assigning?'barq_bas_assign_final_driver_v29':'barq_bas_handover_final_v29',
          assigning?{p_order_id:id,p_driver_id:driverId,p_scan:code}:{p_order_id:id,p_scan:code});
        if(error)throw error;
        brqSetNotice(assigning?'تم تعيين المندوب ✅ — الطرد بعده داخل المخزن.':'تم توثيق خروج الطرد من مخزن البصرة ✅ — لازم المندوب يمسح QR عند تسليمه للزبون.','brq28BasNotice');
        await brqV28RefreshFinal();
        // V32: after scanning, bring the current parcel's NEXT action into view on small screens.
        if(window.matchMedia('(max-width: 760px)').matches){
          const updated=[...document.querySelectorAll('#brq28BasRows [data-v28-row]')].find(n=>n.dataset.v28Row===id);
          const next=updated?.querySelector('[data-v28-handover]');
          if(next){requestAnimationFrame(()=>{next.scrollIntoView({behavior:'smooth',block:'center'});try{next.focus({preventScroll:true})}catch(_){}});}
          else if(updated){requestAnimationFrame(()=>updated.scrollIntoView({behavior:'smooth',block:'center'}));}
        }
        if(!assigning)await refreshData();
      }catch(ex){setError('brq28BasError',ex.message||'تعذر تحديث الطرد');}
      finally{btn.disabled=false;}
    });

    let brq22Transfers=[];
    let brq22OrdersById=new Map();
    const brq22Statuses={prepared:'مجهز — بانتظار الناقل',in_transit:'بالطريق إلى بغداد',received:'استلمه فرع بغداد',cancelled:'ملغى'};
    const brq22ActiveForOrder=id=>brq22Transfers.find(t=>t.order_id===id&&t.transfer_status!=='cancelled');
    function brq22Render(){
      const eligible=$('brq22EligibleRows'),transfers=$('brq22TransfersRows');if(!eligible||!transfers)return;
      const ready=brqIntercityRoutes.filter(r=>{
        const o=r.order||{};
        return r.stage==='in_warehouse' && r.warehouse_item_id &&
          o.status==='picked_up' && String(o.delivery_governorate||'').trim()==='بغداد' &&
          !brq22ActiveForOrder(r.order_id);
      });
      eligible.innerHTML=ready.length?ready.map(r=>{
        const o=r.order||{};
        return `<tr><td>${shortId(r.order_id)}<small class="barq-code" style="display:block">${esc(o.receipt_code||'')}</small></td><td>${brqMerchantName(r.merchant_id)}</td><td>${esc(o.customer_name||'—')}</td><td>داخل مخزن البصرة</td><td><button type="button" class="tiny-action" data-brq22-prepare="${esc(r.order_id)}">📦 تجهيز تحويل بغداد</button></td></tr>`;
      }).join(''):rowEmpty(5,'لا توجد طرود بغداد جاهزة حالياً؛ المطلوب استلام الطلب في مخزن البصرة أولاً.');
      transfers.innerHTML=brq22Transfers.length?brq22Transfers.map(t=>{
        const o=brq22OrdersById.get(t.order_id)||brqIntercityRoutes.find(x=>x.order_id===t.order_id)?.order||{};
        const action=t.transfer_status==='prepared'?`<button type="button" class="tiny-action" data-brq22-handover="${esc(t.id)}">🚚 تسليم للناقل الداخلي</button>`:'—';
        return `<tr><td>${shortId(t.order_id)}</td><td>${esc(o.customer_name||'—')}<small class="barq-code" style="display:block">${esc(o.receipt_code||'')}</small></td><td><span class="barq-logistics-badge ${t.transfer_status==='received'?'ok':t.transfer_status==='in_transit'?'warn':''}">${esc(brq22Statuses[t.transfer_status]||t.transfer_status||'—')}</span></td><td>${esc(t.transport_name||'—')}<small class="barq-code" style="display:block">${esc(t.transport_reference||'')}</small></td><td>${action}</td></tr>`;
      }).join(''):rowEmpty(5,'ماكو تحويلات فروع مسجلة بعد.');
    }
    async function brq22Refresh(){
      if(!sb)return;
      setError('brq22Error','');
      try{
        const r=await sb.from('barq_branch_transfers')
          .select('id,order_id,from_branch_id,to_branch_id,transfer_status,transport_name,transport_reference,created_at')
          .order('created_at',{ascending:false}).limit(300);
        if(r.error)throw r.error;
        brq22Transfers=(r.data||[]).filter(t=>{const f=currentData.branches.find(b=>b.id===t.from_branch_id)?.code;const to=currentData.branches.find(b=>b.id===t.to_branch_id)?.code;return f==='BAS'&&to==='BGD'});brq22OrdersById=new Map();
        const ids=[...new Set(brq22Transfers.map(t=>t.order_id).filter(Boolean))];
        if(ids.length){
          const o=await sb.from('orders').select('id,receipt_code,customer_name,delivery_governorate').in('id',ids);
          if(o.error)throw o.error;
          brq22OrdersById=new Map((o.data||[]).map(row=>[row.id,row]));
        }
        brq22Render();brqRenderIntercity();
      }catch(ex){setError('brq22Error','تعذر تحميل تحويلات الفروع: '+(ex.message||String(ex)));}
    }
    $('brq22Refresh').addEventListener('click',async()=>{await brqRefreshIntercity();});
    document.addEventListener('click',async e=>{
      const prepare=e.target.closest('[data-brq22-prepare]');
      const handover=e.target.closest('[data-brq22-handover]');
      const button=prepare||handover;if(!button)return;
      if(button.disabled)return;
      let rpc,params,notice;
      if(prepare){
        const orderId=prepare.dataset.brq22Prepare;
        const route=brqIntercityRoutes.find(r=>r.order_id===orderId);
        if(!route||brq22ActiveForOrder(orderId))return setError('brq22Error','هذا الطلب لديه تحويل مسجل بالفعل. اضغط تحديث.');
        if(!confirm('تجهيز تحويل الطلب إلى فرع بغداد؟ هذا لا يُخرج الطرد من المخزن بعد.'))return;
        const scan=await BarqScannerV29.scan({title:'مسح الطرد لتجهيز تحويل بغداد',expectedCode:route.order?.receipt_code||orderId});
        if(!scan)return;
        rpc='barq_admin_prepare_branch_transfer_v29';
        params={p_order_id:orderId,p_target_branch_code:'BGD',p_notes:null,p_scan:scan};
        notice='تم تجهيز التحويل إلى بغداد. سلّم الطرد للناقل الداخلي، ثم سجل عملية التسليم من نفس القسم.';
      }else{
        const transfer=brq22Transfers.find(t=>t.id===handover.dataset.brq22Handover);
        if(!transfer||transfer.transfer_status!=='prepared')return setError('brq22Error','التحويل غير جاهز للنقل؛ اضغط تحديث.');
        const carrier=prompt('اسم الناقل الداخلي الذي استلم الطرد فعلياً (مثلاً: سائق نقل برق):');
        if(carrier===null)return;
        if(carrier.trim().length<2||carrier.trim().length>120)return setError('brq22Error','اسم الناقل يجب أن يكون بين حرفين و120 حرفاً.');
        const reference=prompt('رقم مرجع النقل الداخلي (اختياري — اتركه فارغاً إذا ماكو):','');
        if(reference===null)return;
        if(reference.trim().length>120)return setError('brq22Error','رقم المرجع طويل جداً.');
        if(!confirm('تأكيد: هل سلّمت الطرد فعلياً للناقل الداخلي المتجه إلى بغداد؟ هذه العملية تسجل خروج الطرد من مخزن البصرة.'))return;
        const transferOrder=brq22OrdersById.get(transfer.order_id)||brqIntercityRoutes.find(r=>r.order_id===transfer.order_id)?.order||{};
        const scan=await BarqScannerV29.scan({title:'مسح الطرد عند تسليمه للناقل الداخلي',expectedCode:transferOrder.receipt_code||transfer.order_id});
        if(!scan)return;
        rpc='barq_admin_handover_branch_transfer_v29';
        params={p_transfer_id:transfer.id,p_transport_name:carrier.trim(),p_transport_reference:reference.trim()||null,p_scan:scan};
        notice='تم تسجيل تسليم الطرد للناقل. صار بحالة «بالطريق إلى بغداد»، وبانتظار مسح QR من فرع بغداد. لم يتم تسليم الزبون أو احتساب المال.';
      }
      button.disabled=true;setError('brq22Error','');
      try{
        await verifiedAdmin();
        const {error}=await sb.rpc(rpc,params);if(error)throw error;
        await refreshData();
        brqSetNotice(notice,'brq22Notice');
      }catch(ex){setError('brq22Error','تعذر تنفيذ تحويل الفرع: '+(ex.message||String(ex)))}
      finally{button.disabled=false}
    });
    const brqIntercityStages={to_warehouse:'المندوب في الطريق للشركة',awaiting_receipt:'وصل المندوب — تأكيد المخزن مطلوب',in_warehouse:'داخل مخزن الشركة',sent_by_post:'تم التسليم للبريد',returned:'راجع'};
    async function brqRefreshIntercity(){
      if(!sb)return;
      const {data,error}=await sb.from('barq_order_routes').select('order_id,merchant_id,driver_id,route_type,stage,warehouse_item_id,carrier_name,tracking_code,shipped_at,created_at').eq('route_type','warehouse').order('created_at',{ascending:false}).limit(300);
      if(error){setError('brqIntercityError','تعذر تحميل شحن المحافظات: '+error.message+' — شغّل SQL V19 أولاً.');return}
      const list=data||[];
      if(list.length){const ids=list.map(x=>x.order_id);
        const response=await sb.from('orders').select('id,receipt_code,merchant_id,origin_branch_id,customer_name,delivery_governorate,goods_type,status').in('id',ids);
        if(response.error){setError('brqIntercityError','تعذر جلب تفاصيل الشحن: '+response.error.message);return}
        const map=new Map((response.data||[]).map(o=>[o.id,o]));brqIntercityRoutes=list.map(r=>({...r,order:map.get(r.order_id)||null}));
      }else brqIntercityRoutes=[];
      setError('brqIntercityError','');await brq22Refresh();
    }
    // V26: the general admin must not receive a Baghdad pickup into the Basra warehouse or post it directly.
    const brqV26RouteOriginGovernorate=r=>{
      const o=r.order||{};
      const b=currentData.branches.find(x=>x.id===o.origin_branch_id);
      const m=currentData.merchants.find(x=>x.id===r.merchant_id);
      return b?.governorate||m?.governorate||'';
    };
    const brqV26NeedsBranchTransfer=r=>{
      const origin=brqV26RouteOriginGovernorate(r), destination=r.order?.delivery_governorate||'';
      return !!(origin && destination && origin!==destination &&
        currentData.branches.some(b=>b.governorate===destination && b.is_active));
    };
    function brqRenderIntercity(){
      const rows=$('brqIntercityRows');if(!rows)return;
      rows.innerHTML=brqIntercityRoutes.length?brqIntercityRoutes.map(r=>{
        const o=r.order||{};
        const internalTransfer=brq22ActiveForOrder(r.order_id);
        const origin=brqV26RouteOriginGovernorate(r);
        const mustTransfer=brqV26NeedsBranchTransfer(r);
        const controls=!origin||!currentData.branches.length?'<span class="barq-logistics-badge warn">⚠️ بيانات فرع المصدر غير مكتملة</span>':
          internalTransfer?'<span class="barq-logistics-badge warn">تحويل داخلي — راجع قسم فروع برق</span>':
          origin==='بغداد'&&r.stage==='awaiting_receipt'?'<span class="barq-logistics-badge warn">📦 الاستلام من لوحة مخزن بغداد</span>':
          origin==='بغداد'&&r.stage==='in_warehouse'?'<span class="barq-logistics-badge warn">🚚 يحتاج تحويل من بغداد إلى فرع الوجهة</span>':
          mustTransfer&&r.stage==='in_warehouse'?'<span class="barq-logistics-badge warn">🚚 يتطلب تحويل داخلي بين الفروع</span>':
          r.stage==='awaiting_receipt'?`<button type="button" class="tiny-action" data-brq-intercity-receive="${esc(r.order_id)}">📦 تأكيد استلام الطرد</button>`:
          r.stage==='in_warehouse'?`<button type="button" class="tiny-action" data-brq-intercity-dispatch="${esc(r.order_id)}">🚛 تسليم إلى البريد</button>`:'—';
        const carrier=[r.carrier_name,r.tracking_code].filter(Boolean).map(esc).join(' · ')||'—';
        return `<tr><td>${shortId(r.order_id)}<small class="barq-code" style="display:block">${esc(o.receipt_code||'')}</small></td><td>${brqMerchantName(r.merchant_id)}</td><td>${esc(o.delivery_governorate||'—')}</td><td>${esc(o.customer_name||'—')}</td><td><span class="barq-intercity-label ${r.stage==='in_warehouse'?'received':r.stage==='sent_by_post'?'dispatched':''}">${esc(brqIntercityStages[r.stage]||r.stage)}</span></td><td>${carrier}</td><td>${controls}</td></tr>`;
      }).join(''):rowEmpty(7,'ماكو طرود محافظات مسجّلة حالياً.');
    }
    $('brqRefreshIntercity').addEventListener('click',brqRefreshIntercity);
    document.addEventListener('click',async e=>{
      const receive=e.target.closest('[data-brq-intercity-receive]');
      const dispatch=e.target.closest('[data-brq-intercity-dispatch]');
      if(!receive&&!dispatch)return;
      const btn=receive||dispatch,id=receive?.dataset.brqIntercityReceive||dispatch.dataset.brqIntercityDispatch;
      const route=brqIntercityRoutes.find(r=>r.order_id===id);if(!route)return;
      if(!brqV26RouteOriginGovernorate(route)||!currentData.branches.length){
        setError('brqIntercityError','تحتاج تحديث بيانات الفروع لتحديد مسار الطلب.');return;
      }
      if(brqV26RouteOriginGovernorate(route)==='بغداد'){
        setError('brqIntercityError','هذا الطلب ينطلق من بغداد: استلامه يكون في تطبيق مدير فرع بغداد، ولا يجوز إرساله للبريد من مخزن البصرة.');return;
      }
      if(dispatch&&brqV26NeedsBranchTransfer(route)){
        setError('brqIntercityError','محافظة الوجهة فيها فرع فعال؛ يلزم تحويل بين الفروع قبل التسليم النهائي.');return;
      }
      if(dispatch&&brq22ActiveForOrder(id)){setError('brqIntercityError','الطلب مرتبط بتحويل داخلي إلى بغداد؛ لا تستخدم التسليم للبريد.');return;}
      let rpc,params;
      if(receive){
        const shelf=prompt('موقع تخزين الطرد داخل شركة برق (مثلاً رف A1):');if(shelf===null)return;
        if(!shelf.trim()){setError('brqIntercityError','حدد موقع الرف قبل الاستلام.');return}
        rpc='barq_admin_receive_intercity';params={p_order_id:id,p_shelf:shelf.trim(),p_condition:'good',p_notes:null};
      }else{
        const carrier=prompt('اكتب اسم شركة البريد أو الناقل:');if(carrier===null)return;
        const tracking=prompt('اكتب رقم تتبع الشحنة الصادر من شركة البريد:');if(tracking===null)return;
        if(carrier.trim().length<2||tracking.trim().length<3){setError('brqIntercityError','الناقل أو رقم التتبع غير صحيح.');return}
        if(!confirm('هل تأكدت أن الطرد سُلِّم فعلياً لشركة البريد؟'))return;
        rpc='barq_admin_dispatch_intercity';params={p_order_id:id,p_carrier_name:carrier.trim(),p_tracking_code:tracking.trim()};
      }
      btn.disabled=true;setError('brqIntercityError','');
      try{await verifiedAdmin();const {error}=await sb.rpc(rpc,params);if(error)throw error;
        await Promise.all([brqRefreshIntercity(),refreshLogistics(false)]);
        brqSetNotice(receive?'تم استلام الطرد في المخزن ✅':'تم توثيق إرسال الطرد عبر البريد ✅ — لم يُسجّل تسليم الزبون أو تحصيل الأموال','brqIntercityNotice');
      }catch(err){setError('brqIntercityError',err.message||String(err))}finally{btn.disabled=false}
    });


    // BARQ V20 — manager: scan receipt on physical parcel -> ONE atomic warehouse receive RPC.
    const brq20ScanModal=$('barq20ScanModal');
    const brq20ScanVideo=$('barq20ScanVideo');
    const brq20ScanCanvas=document.createElement('canvas');
    let brq20Stream=null,brq20Timer=null,brq20Reading=false,brq20Saving=false;
    const brq20Status=(message,kind='info')=>{const el=$('barq20ScanResult');el.textContent=message;el.style.color=kind==='err'?'#b22f38':kind==='ok'?'#087b54':'#345678';};
    function brq20StopCamera(){
      if(brq20Timer){clearTimeout(brq20Timer);brq20Timer=null}
      if(brq20Stream){for(const t of brq20Stream.getTracks())t.stop();brq20Stream=null}
      brq20ScanVideo.pause();brq20ScanVideo.srcObject=null;brq20ScanVideo.style.display='none';
    }
    function brq20OpenScan(){
      brq20ScanModal.classList.remove('hide');brq20Status('وجه الكاميرا على باركود الوصل الموجود على الطرد. التأكيد تلقائي بعد القراءة.');
    }
    function brq20CloseScan(){brq20StopCamera();brq20ScanModal.classList.add('hide');}
    function brq20Code(value){
      if(!value)return null;
      // The QR may contain a BRQ code or an HTTPS merchant deep link with that code.
      const match=String(value).toUpperCase().match(/BRQ-[0-9A-F]{32}/);
      return match?match[0]:null;
    }
    async function brq20ConfirmCode(raw){
      if(brq20Saving)return;
      const code=brq20Code(raw);
      if(!code){brq20Status('❌ هذا الرمز ليس من وصولات برق. حاول مرة ثانية.','err');return}
      brq20Saving=true;brq20StopCamera();brq20Status('⏳ جاري مطابقة الوصل وتأكيد استلامه في مخزن الشركة...');
      try{
        await verifiedAdmin();
        // V26: never book a Baghdad-origin pickup into the central/Basra receipt screen.
        const {data:labelRow,error:labelError}=await sb.from('barq_receipt_labels')
          .select('order_id').eq('code',code).maybeSingle();
        if(labelError)throw labelError;
        if(!labelRow?.order_id)throw Error('هذا الوصل غير مرتبط بطلب مفتوح؛ راجع إدارة الوصولات.');
        const {data:originOrder,error:orderError}=await sb.from('orders')
          .select('merchant_id,origin_branch_id').eq('id',labelRow.order_id).single();
        if(orderError)throw orderError;
        const {data:originShop,error:shopError}=await sb.from('merchants')
          .select('branch_id,governorate').eq('id',originOrder.merchant_id).single();
        if(shopError)throw shopError;
        const originId=originOrder.origin_branch_id||originShop.branch_id;
        if(!originId)throw Error('فرع انطلاق المحل غير محدد. راجع الإدارة قبل الاستلام.');
        const {data:originBranch,error:branchError}=await sb.from('barq_branches')
          .select('governorate').eq('id',originId).single();
        if(branchError)throw branchError;
        if(originBranch.governorate!=='البصرة')throw Error('هذا الطرد مصدره '+originBranch.governorate+'؛ يتم استلامه في مخزن فرع الانطلاق، مو مخزن البصرة.');
        const {data,error}=await sb.rpc('barq_admin_receive_intercity_by_qr',{
          p_code:code,p_shelf:'منطقة استلام المحافظات',p_condition:'good',p_notes:'تم تأكيد استلام الطرد بمسح باركود الوصل من لوحة المدير'
        });
        if(error)throw error;
        brq20Status('✅ تم استلام الطرد وتسجيله بالمخزن بنجاح. معرّف حركة الطرد: '+String(data).slice(0,8),'ok');
        brqSetNotice('✅ تم تأكيد استلام طرد المحافظات بمسح QR وإدخاله إلى منطقة استلام المحافظات.','brqIntercityNotice');
        await Promise.all([brqRefreshIntercity(),refreshLogistics(false)]);
      }catch(e){brq20Status('❌ لم يتم التأكيد: '+(e.message||e),'err')}
      finally{brq20Saving=false}
    }
    async function brq20DecodeFrame(source){
      const w=source.videoWidth||source.naturalWidth||source.width, h=source.videoHeight||source.naturalHeight||source.height;
      if(!w||!h)return null;
      const scale=Math.min(1,1100/w),cw=Math.max(1,Math.round(w*scale)),ch=Math.max(1,Math.round(h*scale));
      const canvas=brq20ScanCanvas;canvas.width=cw;canvas.height=ch;
      const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(source,0,0,cw,ch);
      if('BarcodeDetector' in window){try{const d=new BarcodeDetector({formats:['qr_code']});const out=await d.detect(canvas);if(out.length)return out[0].rawValue}catch(_){}}
      if(typeof window.jsQR==='function'){
        const p=ctx.getImageData(0,0,cw,ch);return window.jsQR(p.data,cw,ch,{inversionAttempts:'attemptBoth'})?.data||null;
      }
      throw Error('قارئ QR لم يُحمّل. تأكد من الإنترنت أو أدخل الرمز يدوياً.');
    }
    async function brq20CameraTick(){
      if(!brq20Stream||brq20Saving)return;
      if(brq20Reading){brq20Timer=setTimeout(brq20CameraTick,220);return;}
      brq20Reading=true;
      try{const code=await brq20DecodeFrame(brq20ScanVideo);if(code){await brq20ConfirmCode(code);return}}
      catch(e){brq20Status('تعذر قراءة QR بالكاميرا: '+(e.message||e),'err');brq20StopCamera();return}
      finally{brq20Reading=false}
      if(brq20Stream)brq20Timer=setTimeout(brq20CameraTick,220);
    }
    async function brq20StartCamera(){
      if(brq20Saving)return;brq20StopCamera();
      try{
        if(!navigator.mediaDevices?.getUserMedia)throw Error('الكاميرا تتطلب HTTPS ومتصفحاً يدعمها.');
        brq20Stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false});
        brq20ScanVideo.srcObject=brq20Stream;brq20ScanVideo.style.display='block';
        await brq20ScanVideo.play();brq20Status('قرّب باركود الوصل إلى الكاميرا حتى يتم تأكيد استلامه تلقائياً.');
        brq20CameraTick();
      }catch(e){brq20StopCamera();brq20Status('تعذر فتح الكاميرا: '+(e.message||e)+'، استخدم صورة أو الرمز اليدوي.','err')}
    }
    $('barq20ScanOpen').addEventListener('click',brq20OpenScan);
    $('barq20ScanClose').addEventListener('click',brq20CloseScan);
    $('barq20CameraStart').addEventListener('click',brq20StartCamera);
    $('barq20CameraStop').addEventListener('click',brq20StopCamera);
    $('barq20ScanManual').addEventListener('click',()=>brq20ConfirmCode($('barq20ScanText').value.trim()));
    $('barq20ScanText').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();brq20ConfirmCode(e.currentTarget.value.trim())}});
    $('barq20ScanImage').addEventListener('change',async(e)=>{
      const input=e.target;const file=input.files?.[0];if(!file)return;brq20StopCamera();
      try{
        const url=URL.createObjectURL(file),image=new Image();
        try{await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=reject;image.src=url});}
        finally{URL.revokeObjectURL(url)}
        const code=await brq20DecodeFrame(image);
        if(!code)throw Error('لم أجد QR واضحاً بهذه الصورة.');
        await brq20ConfirmCode(code);
      }catch(err){brq20Status('❌ '+(err.message||err),'err')}finally{input.value=''}
    });
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!brq20ScanModal.classList.contains('hide'))brq20CloseScan()});

    // BARQ V42: Move an existing courier from one active branch to another.
    // Server RPC enforces admin role and checks ALL outstanding duties before transfer.
    document.addEventListener('click', event=>{
      const button=event.target.closest('[data-brq42-transfer]');if(!button)return;
      const d=(currentData.drivers||[]).find(x=>x.id===button.dataset.brq42Transfer);
      if(!d||!d.is_active||!d.branch_id)return;
      const p=(currentData.profiles||[]).find(x=>x.id===d.user_id)||{};
      const original=(currentData.branches||[]).find(b=>b.id===d.branch_id);
      const destinations=brq41ActiveBranches.filter(b=>b.id!==d.branch_id);
      $('brq42DriverId').value=d.id;
      $('brq42DriverDescription').textContent=(p.full_name||'مندوب بدون اسم')+' — الفرع الحالي: '+(original?.name||'غير معروف');
      const dropdown=$('brq42TargetBranch');
      dropdown.innerHTML='<option value="">'+(destinations.length?'اختر الفرع الجديد':'لا توجد فروع نشطة أخرى')+'</option>'
        +destinations.map(b=>'<option value="'+esc(b.code)+'">'+esc(brq41BranchName(b))+'</option>').join('');
      dropdown.disabled=!destinations.length;
      $('brq42TransferSubmit').disabled=!destinations.length;
      setError('brq42TransferError','');
      showModal('brq42TransferModal');
    });
    $('brq42TransferForm').addEventListener('submit',async ev=>{
      ev.preventDefault();setError('brq42TransferError','');
      const id=$('brq42DriverId').value,code=$('brq42TargetBranch').value;
      const driver=(currentData.drivers||[]).find(d=>d.id===id);
      const target=brq41ActiveBranches.find(b=>b.code===code);
      if(!driver||!driver.is_active||!target||target.id===driver.branch_id){
        setError('brq42TransferError','اختر مندوباً نشطاً وفرعاً مختلفاً وفعالاً.');return;
      }
      const p=(currentData.profiles||[]).find(x=>x.id===driver.user_id)||{};
      const source=(currentData.branches||[]).find(b=>b.id===driver.branch_id);
      if(!confirm('هل تؤكد نقل '+(p.full_name||'المندوب')+' من '+(source?.name||'فرعه الحالي')+' إلى '+brq41BranchName(target)+'؟\nهذا ينقل انتسابه الحالي فقط، ولا يغيّر سجلات الطلبات القديمة.'))return;
      const btn=$('brq42TransferSubmit');btn.disabled=true;btn.textContent='جارٍ نقل المندوب...';
      try{
        await verifiedAdmin();
        const {data,error}=await sb.rpc('barq_admin_transfer_driver_v42',{p_driver_id:id,p_target_branch_code:code});
        if(error)throw error;
        if(data!==target.id)throw Error('الفرع الذي أعادته قاعدة البيانات لا يطابق الفرع المطلوب؛ راجع النقل قبل التكرار.');
        closeModal('brq42TransferModal');
        await refreshData();
        const msg=$('brq42TransferResult');
        msg.textContent='✅ تم نقل '+(p.full_name||'المندوب')+' من '+(source?.name||'الفرع القديم')+' إلى '+brq41BranchName(target)+' وحُفظ النقل بقاعدة البيانات.';
        msg.classList.remove('hide');
      }catch(e){setError('brq42TransferError','تعذّر نقل المندوب: '+(e.message||String(e))+' — لا تحاول تجاوز رفض الطلبات الجارية.');}
      finally{btn.disabled=false;btn.textContent='تأكيد نقل المندوب';}
    });

    // BARQ V22 / Baghdad driver enrollment: admin-only, separate from Basra dispatch.
    function bgdUpdateDriverOptions(){
      const select=$('bgdDriverSelect'),button=$('bgdDriverAssign');
      if(!select||!button)return;
      const previous=select.value;
      const fresh=(currentData.drivers||[]).filter(d=>d.is_active&&d.branch_id==null);
      select.innerHTML='<option value="">'+(fresh.length?'اختار مندوباً جديداً بلا فرع':'لا توجد حسابات مندوبين بلا محافظة')+'</option>'
        +fresh.map(d=>`<option value="${esc(d.user_id)}">${getDriverLabel(d)}</option>`).join('');
      if(fresh.some(d=>d.user_id===previous))select.value=previous;
      button.disabled=!select.value;
    }
    $('bgdDriverSelect').addEventListener('change',()=>{$('bgdDriverAssign').disabled=!$('bgdDriverSelect').value||!$('bgdDriverTarget').value});
    $('bgdDriverTarget').addEventListener('change',()=>{$('bgdDriverAssign').disabled=!$('bgdDriverSelect').value||!$('bgdDriverTarget').value});
    $('bgdDriverAssign').addEventListener('click',async()=>{
      const userId=$('bgdDriverSelect').value,button=$('bgdDriverAssign'),msg=$('bgdDriverMessage');
      if(!userId)return;
      const code=$('bgdDriverTarget').value;
      const targetBranch=brq41ActiveBranches.find(b=>b.code===code);
      if(!targetBranch){msg.style.color='#af273b';msg.textContent='اختر فرعاً نشطاً أولاً.';return;}
      if(!confirm('تأكيد ربط هذا المندوب بفرع '+brq41BranchName(targetBranch)+'؟\nلن ننقل أي مندوب مرتبط بفرع آخر.'))return;
      button.disabled=true;msg.style.color='#1b4c75';msg.textContent='جاري تحديد محافظة المندوب...';
      try{
        await verifiedAdmin();
        const {error}=await sb.rpc('barq_admin_assign_new_driver_branch_v41',{p_user_id:userId,p_branch_code:code});
        if(error)throw error;
        msg.style.color='#097350';msg.textContent='تم ربط المندوب بفرع '+brq41BranchName(targetBranch)+' ✅';
        await refreshData();
      }catch(e){msg.style.color='#af273b';msg.textContent='تعذر الربط: '+(e.message||String(e))}
      finally{button.disabled=!$('bgdDriverSelect').value||!$('bgdDriverTarget').value}
    });
    // BARQ V23 | Admin branch management, with admin-guarded server-side RPCs.
    let brq23Branches = [];
    const brq23HasData = () => Array.isArray(brq23Branches) && brq23Branches.length > 0;
    function brq23Message(msg, good=false){
      setError('brq23Error', good ? '' : msg);
      const box=$('brq23Notice');box.textContent=good ? msg : '';box.classList.toggle('hide',!good||!msg);
    }
    $('brq23Governorate').innerHTML='<option value="">اختر المحافظة</option>'+
      BARQ_IRAQ_GOVERNORATES.map(g=>`<option value="${esc(g)}">${esc(g)}</option>`).join('');
    function brq23ResetForm(){
      $('brq23BranchForm').reset();$('brq23Id').value='';$('brq23Code').readOnly=false;
      $('brq23FormTitle').textContent='+ إضافة فرع جديد';$('brq23Governorate').disabled=false;$('brq23Status').checked=true;
    }
    function brq23Render(){
      $('brq23Total').textContent=money(brq23Branches.length);
      $('brq23Active').textContent=money(brq23Branches.filter(b=>b.is_active).length);
      $('brq23Inactive').textContent=money(brq23Branches.filter(b=>!b.is_active).length);
      $('brq23BranchRows').innerHTML=brq23HasData()?brq23Branches.map(b=>{
        const managers=(b.managers||[]).map(m=>{
          const p=currentData.profiles.find(p=>p.id===m.user_id);
          const n=m.name||p?.full_name||'بدون اسم ('+String(m.user_id).slice(0,8)+')';
          return `<div style="margin-bottom:5px;white-space:normal;min-width:160px">${esc(n)} <span class="pill ${m.active?'green':'red'}">${m.active?'فعّال':'موقوف'}</span> ${m.active?`<button class="tiny-action member-danger" type="button" data-brq23-unassign="${esc(b.branch_id)}" data-brq23-user="${esc(m.user_id)}">إلغاء التعيين</button>`:''}</div>`;
        }).join('');
        return `<tr><td><strong>${esc(b.branch_name)}</strong><br><small dir="ltr">${esc(b.branch_code)}</small><br><small>${nice(b.address)}</small></td><td>${esc(b.governorate)}</td><td>${money(b.merchants_count)}</td><td>${money(b.drivers_count)}</td><td>${money(b.orders_count)}</td><td>${money(b.staff_count)}</td><td>${managers||'—'}</td><td><span class="pill ${b.is_active?'green':'red'}">${b.is_active?'نشط':'متوقف'}</span></td><td><div class="member-actions"><button type="button" class="tiny-action" data-brq23-edit="${esc(b.branch_id)}">تعديل</button><button type="button" class="tiny-action ${b.is_active?'member-danger':''}" data-brq23-toggle="${esc(b.branch_id)}">${b.is_active?'إيقاف':'تفعيل'}</button></div></td></tr>`;
      }).join(''):'<tr><td colspan="9" class="empty">ماكو فروع مسجلة بعد.</td></tr>';
      const selectedBranch=$('brq23ManagerBranch').value;
      $('brq23ManagerBranch').innerHTML='<option value="">اختر الفرع</option>'+brq23Branches.map(b=>`<option value="${esc(b.branch_id)}">${esc(b.branch_name)} — ${esc(b.governorate)}</option>`).join('');
      if(brq23Branches.some(b=>b.branch_id===selectedBranch))$('brq23ManagerBranch').value=selectedBranch;
      const newBranch=$('brq37ManagerBranch');
      const previousNewBranch=newBranch.value;
      newBranch.innerHTML='<option value="">اختر الفرع</option>'+brq23Branches.filter(b=>b.is_active).map(b=>`<option value="${esc(b.branch_id)}">${esc(b.branch_name)} — ${esc(b.governorate)}</option>`).join('');
      if(brq23Branches.some(b=>b.is_active&&b.branch_id===previousNewBranch))newBranch.value=previousNewBranch;
      else if(brq23Branches.some(b=>b.is_active&&b.branch_id===selectedBranch))newBranch.value=selectedBranch;
      const selectedUser=$('brq23ManagerUser').value;
      const managers=(currentData.profiles||[]).filter(p=>['branch_manage','branch_manager'].includes(p.role));
      $('brq23ManagerUser').innerHTML='<option value="">'+(managers.length?'اختر حساب المدير':'لا توجد حسابات مديري فروع')+'</option>'+managers.map(p=>`<option value="${esc(p.id)}">${esc(p.full_name||'مدير فرع بدون اسم')} — ${esc(String(p.id).slice(0,8))}</option>`).join('');
      if(managers.some(p=>p.id===selectedUser))$('brq23ManagerUser').value=selectedUser;
    }
    async function brq23RefreshBranches(){
      const button=$('brq23Refresh');button.disabled=true;
      try{
        const {data,error}=await sb.rpc('barq_admin_branch_dashboard_v23');
        if(error)throw error;
        brq23Branches=data||[];
        currentData.branches=brq23Branches.map(b=>({id:b.branch_id,code:b.branch_code,name:b.branch_name,governorate:b.governorate,is_active:b.is_active}));
        brq41SetActiveBranches(currentData.branches);
        brq23Render();brq23Message('');
      }catch(e){brq23Message('تعذر تحميل إدارة الفروع: '+(e.message||e)+'. نفّذ ملف SQL الخاص بـ V23 أولاً.');}
      finally{button.disabled=false;}
    }
    $('brq23Refresh').addEventListener('click',brq23RefreshBranches);
    $('brq23CancelEdit').addEventListener('click',brq23ResetForm);
    $('brq23BranchForm').addEventListener('submit',async e=>{
      e.preventDefault();const button=$('brq23Save');button.disabled=true; brq23Message('');
      try{
        await verifiedAdmin();
        const params={
          p_branch_id:$('brq23Id').value||null,
          p_code:$('brq23Code').value.trim().toUpperCase(),
          p_name:$('brq23Name').value.trim(),
          p_governorate:$('brq23Governorate').value,
          p_address:$('brq23Address').value.trim()||null,
          p_is_active:$('brq23Status').checked
        };
        if(!BARQ_IRAQ_GOVERNORATES.includes(params.p_governorate))throw Error('اختر محافظة صحيحة');
        const {error}=await sb.rpc('barq_admin_save_branch_v23',params);
        if(error)throw error;
        brq23ResetForm();await brq23RefreshBranches();
        brq23Message('تم حفظ الفرع بنجاح ✅',true);
      }catch(e){brq23Message('تعذر حفظ الفرع: '+(e.message||e));}
      finally{button.disabled=false;}
    });
    $('branchesSection').addEventListener('click',async e=>{
      const edit=e.target.closest('[data-brq23-edit]');
      const toggle=e.target.closest('[data-brq23-toggle]');
      const unassign=e.target.closest('[data-brq23-unassign]');
      if(edit){
        const b=brq23Branches.find(b=>b.branch_id===edit.dataset.brq23Edit);if(!b)return;
        $('brq23Id').value=b.branch_id;$('brq23Code').value=b.branch_code;$('brq23Code').readOnly=true;
        $('brq23Name').value=b.branch_name;$('brq23Governorate').value=b.governorate;$('brq23Governorate').disabled=true;
        $('brq23Address').value=b.address||'';$('brq23Status').checked=b.is_active;
        $('brq23FormTitle').textContent='تعديل '+b.branch_name;
        $('brq23BranchForm').scrollIntoView({behavior:'smooth',block:'center'});
        return;
      }
      if(toggle){
        const b=brq23Branches.find(b=>b.branch_id===toggle.dataset.brq23Toggle);if(!b)return;
        if(!confirm('هل تريد '+(b.is_active?'إيقاف':'تفعيل')+' فرع '+b.branch_name+'؟\nالإيقاف لا يلغي أي طلب سابق ولا يحذف الحسابات.'))return;
        toggle.disabled=true;
        try{
          await verifiedAdmin();const {error}=await sb.rpc('barq_admin_save_branch_v23',{
            p_branch_id:b.branch_id,p_code:b.branch_code,p_name:b.branch_name,
            p_governorate:b.governorate,p_address:b.address,p_is_active:!b.is_active
          });if(error)throw error;
          await brq23RefreshBranches();brq23Message('تم تحديث حالة الفرع ✅',true);
        }catch(ex){brq23Message('تعذر تحديث الحالة: '+(ex.message||ex));}
        finally{toggle.disabled=false;}
        return;
      }
      if(unassign){
        const bid=unassign.dataset.brq23Unassign,uid=unassign.dataset.brq23User;
        if(!confirm('إلغاء صلاحية هذا المدير على الفرع؟ لن يُحذف حسابه.'))return;
        unassign.disabled=true;
        try{
          await verifiedAdmin();const {error}=await sb.rpc('barq_admin_set_branch_manager_v23',{
            p_branch_id:bid,p_user_id:uid,p_active:false
          });if(error)throw error;
          await brq23RefreshBranches();brq23Message('تم إيقاف تعيين مدير الفرع ✅',true);
        }catch(ex){brq23Message('تعذر إلغاء التعيين: '+(ex.message||ex));}
        finally{unassign.disabled=false;}
      }
    });
    $('brq23AssignManager').addEventListener('click',async()=>{
      const bid=$('brq23ManagerBranch').value,uid=$('brq23ManagerUser').value;
      if(!bid||!uid)return brq23Message('اختر الفرع وحساب المدير أولاً.');
      if(!confirm('تأكيد تعيين حساب المدير المحدد لهذا الفرع؟'))return;
      const button=$('brq23AssignManager');button.disabled=true;
      try{
        await verifiedAdmin();const {error}=await sb.rpc('barq_admin_set_branch_manager_v23',{
          p_branch_id:bid,p_user_id:uid,p_active:true
        });if(error)throw error;
        await brq23RefreshBranches();brq23Message('تم تعيين مدير الفرع بنجاح ✅',true);
      }catch(e){brq23Message('تعذر تعيين المدير: '+(e.message||e));}
      finally{button.disabled=false;}
    });


    // BARQ V37: protected creation of branch managers from Admin UI.
    // Only the server-side Edge Function creates Auth users and assigns the branch.
    let brq37CreatedCredentials=null;
    function brq37Error(message){setError('brq37ManagerError',message||'');}
    function brq37Reset(){
      $('brq37NewManagerForm').reset();
      if(brq23Branches.some(b=>b.is_active&&b.branch_id===$('brq23ManagerBranch').value))$('brq37ManagerBranch').value=$('brq23ManagerBranch').value;
      brq37CreatedCredentials=null;
      $('brq37CopyCredentials').classList.add('hide');
      $('brq37ManagerSuccess').textContent='';$('brq37ManagerSuccess').classList.add('hide');
      $('brq37CreateManager').disabled=false;$('brq37CreateManager').textContent='إنشاء الحساب وربطه بالفرع';
      brq37Error('');
    }
    $('brq37ToggleNewManager').addEventListener('click',()=>{
      const panel=$('brq37CreatePanel');const show=panel.classList.contains('hide');
      panel.classList.toggle('hide',!show);
      $('brq37ToggleNewManager').setAttribute('aria-expanded',String(show));
      brq37Reset();if(show)panel.scrollIntoView({behavior:'smooth',block:'nearest'});
    });
    $('brq37NewManagerReset').addEventListener('click',brq37Reset);
    $('brq37GeneratePassword').addEventListener('click',()=>{
      const password=createSecurePassword();
      $('brq37ManagerPassword').value=password;$('brq37ManagerConfirm').value=password;
      $('brq37ManagerPassword').type='text';$('brq37ManagerConfirm').type='text';
    });
    $('brq37CopyCredentials').addEventListener('click',async()=>{
      if(!brq37CreatedCredentials)return;
      const message='برق للتوصيل السريع — حساب مدير فرع\nالفرع: '+brq37CreatedCredentials.branch+'\nالبريد: '+brq37CreatedCredentials.email+'\nكلمة المرور: '+brq37CreatedCredentials.password;
      try{await navigator.clipboard.writeText(message);$('brq37ManagerSuccess').textContent='تم نسخ بيانات الدخول. سلّمها للمدير بطريقة آمنة ثم امسحها من الحقول.';}
      catch{brq37Error('تعذّر النسخ تلقائياً. انسخ البريد وكلمة المرور يدوياً قبل إغلاق النموذج.');}
    });
    $('brq37NewManagerForm').addEventListener('submit',async e=>{
      e.preventDefault();brq37Error('');
      if(brq37CreatedCredentials)return brq37Error('تم إنشاء هذا الحساب. اضغط «مسح الحقول / مدير آخر» لإضافة حساب مختلف.');
      const branchId=$('brq37ManagerBranch').value;
      const branch=brq23Branches.find(b=>b.branch_id===branchId&&b.is_active);
      if(!branch)return brq37Error('اختر فرعاً فعالاً من القائمة.');
      const fullName=$('brq37ManagerName').value.trim();
      const email=$('brq37ManagerEmail').value.trim().toLowerCase();
      const phone=$('brq37ManagerPhone').value.trim();
      const password=$('brq37ManagerPassword').value;
      if(fullName.length<2||fullName.length>120)return brq37Error('اسم المدير يجب أن يكون من حرفين إلى 120 حرفاً.');
      if(password.length<10||password.length>128)return brq37Error('كلمة المرور يجب أن تكون من 10 إلى 128 حرفاً.');
      if(password!==$('brq37ManagerConfirm').value)return brq37Error('تأكيد كلمة المرور غير مطابق.');
      const button=$('brq37CreateManager');button.disabled=true;button.textContent='جاري إنشاء المدير...';
      try{
        await verifiedAdmin();
        const {data,error}=await sb.functions.invoke('barq-create-branch-manager-v37',{
          body:{branch_id:branchId,full_name:fullName,email,phone,password}
        });
        if(error){
          let reason=error.message||'تعذّر الاتصال بخدمة إضافة المدير';
          if(error.context && typeof error.context.json==='function'){
            try{const info=await error.context.json();reason=info.error||info.message||reason;}catch{}
          }
          throw Error(reason);
        }
        if(!data?.ok||!data?.user_id)throw Error(data?.error||'لم يؤكد السيرفر إنشاء الحساب وربطه بالفرع. لا تعِد العملية قبل مراجعة قائمة المديرين.');
        brq37CreatedCredentials={email,password,branch:branch.branch_name};
        $('brq37ManagerSuccess').textContent='✅ تم إنشاء الحساب وربطه بالفرع ('+branch.branch_name+') بنجاح. احتفظ ببيانات الدخول قبل إغلاق النموذج.';
        $('brq37ManagerSuccess').classList.remove('hide');
        $('brq37CopyCredentials').classList.remove('hide');
        button.textContent='تمت الإضافة';
        try{
          await refreshData();
          $('brq23ManagerBranch').value=branchId;
          $('brq23ManagerUser').value=data.user_id;
        }catch(refreshError){
          $('brq37ManagerSuccess').textContent+=' الحساب تم إنشاؤه؛ لو لم يظهر بالجدول اضغط «تحديث الفروع». لا تعِد الإنشاء.';
        }
      }catch(ex){brq37Error('تعذّر إنشاء مدير الفرع: '+(ex.message||String(ex)));}
      finally{if(!brq37CreatedCredentials){button.disabled=false;button.textContent='إنشاء الحساب وربطه بالفرع';}}
    });


    // BARQ V33: salary payroll is a separate company expense, NOT a per-order courier fee.
    const brq33NowMonth = () => {
      const parts = new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Baghdad',year:'numeric',month:'2-digit'}).formatToParts(new Date());
      const get=t=>parts.find(p=>p.type===t)?.value||'';
      return get('year')+'-'+get('month');
    };
    const brq33NextMonth = m => {
      const [y,mm]=m.split('-').map(Number);
      const d=new Date(Date.UTC(y,mm,1));return d.toISOString().slice(0,7);
    };
    const brq33Date = m => /^\d{4}-(0[1-9]|1[0-2])$/.test(m)?m+'-01':null;
    let brq33Rows=[];
    let brq33PaymentRequestId=null;
    $('brq33Month').value=brq33NowMonth();
    function brq33Message(msg){setError('brq33Error',msg||'');}
    function brq33Success(msg){$('brq33Success').textContent=msg||'';$('brq33Success').classList.toggle('hide',!msg);}
    async function brq33RefreshPayroll(){
      const month=brq33Date($('brq33Month').value);
      if(!sb||!month)return;
      $('brq33Refresh').disabled=true;
      try{
        const {data,error}=await sb.rpc('barq_admin_salary_dashboard_v33',{p_month:month});
        if(error)throw error;
        brq33Rows=Array.isArray(data?.drivers)?data.drivers:[];
        brq33Message('');brq33Render();
      }catch(e){brq33Rows=[];brq33Render();brq33Message('تعذر تحميل رواتب بغداد. تأكد من تشغيل SQL V33: '+(e.message||String(e)));}
      finally{$('brq33Refresh').disabled=false;}
    }
    function brq33Render(){
      const rows=brq33Rows;
      const opened=rows.filter(r=>r.payroll_id);
      const sum=key=>opened.reduce((n,r)=>n+Number(r[key]||0),0);
      $('brq33Total').textContent=money(sum('payroll_salary_iqd'))+' د.ع';
      $('brq33Paid').textContent=money(sum('paid_iqd'))+' د.ع';
      $('brq33Due').textContent=money(sum('due_iqd'))+' د.ع';
      $('brq33Cards').innerHTML=rows.length?rows.map(r=>{
        const opened=!!r.payroll_id;
        const possible=!!r.salary_active&&Number(r.monthly_salary_iqd)>0;
        const due=Number(r.due_iqd||0);
        const status=opened?('كشف مثبت — '+$('brq33Month').value):(possible?'راتب محدد — كشف الشهر غير مفتوح':'الراتب غير مفعّل لهذا الشهر');
        return `<article class="brq33-card" data-brq33-driver="${esc(r.driver_id)}">
          <div class="brq33-card-header"><div><h5>${nice(r.driver_name)}</h5><small>${nice(r.phone)} · فرع بغداد ${!r.driver_active?'· حساب موقوف':''}</small></div><span class="brq33-chip">${esc(status)}</span></div>
          <div class="brq33-card-stats">
            <div><small>الراتب المتفق عليه للشهر</small><strong>${r.monthly_salary_iqd!=null?money(r.monthly_salary_iqd)+' د.ع':'—'}</strong></div>
            <div><small>الراتب المثبت</small><strong>${opened?money(r.payroll_salary_iqd)+' د.ع':'—'}</strong></div>
            <div><small>المصروف فعلياً</small><strong>${money(r.paid_iqd)} د.ع</strong></div>
            <div><small>المتبقي</small><strong>${opened?money(due)+' د.ع':'لم يفتح الكشف'}</strong></div>
          </div>
          ${!opened?'<div class="brq33-warning">فتح كشف الشهر يثبت الراتب كاملاً لهذا الشهر ولا يعتبره مدفوعاً.</div>':''}
          <div class="brq33-card-actions">
            <button class="btn btn-outline" type="button" data-brq33-edit="${esc(r.driver_id)}">⚙ تعديل الراتب</button>
            ${!opened&&possible?`<button class="btn btn-primary" type="button" data-brq33-open="${esc(r.driver_id)}">فتح كشف الشهر</button>`:''}
            ${opened&&due>0?`<button class="btn btn-primary" type="button" data-brq33-pay="${esc(r.driver_id)}">تسجيل صرف راتب</button>`:''}
            ${opened?`<button class="btn btn-outline" type="button" data-brq33-history="${esc(r.driver_id)}">سجل الدفعات</button>`:''}
          </div>
        </article>`;
      }).join(''):'<div class="notice">لا يوجد مندوب مرتبط بفرع بغداد حالياً. اربط المندوب بالفرع من قسم «المندوبين» أولاً.</div>';
    }
    $('brq33Month').addEventListener('change',()=>{brq33Success('');void brq33RefreshPayroll();});
    $('brq33Refresh').addEventListener('click',()=>void brq33RefreshPayroll());
    $('payrollSection').addEventListener('click',async e=>{
      const edit=e.target.closest('[data-brq33-edit]');
      const open=e.target.closest('[data-brq33-open]');
      const pay=e.target.closest('[data-brq33-pay]');
      const history=e.target.closest('[data-brq33-history]');
      const target=edit||open||pay||history;
      if(!target)return;
      const r=brq33Rows.find(x=>x.driver_id===target.dataset.brq33Edit||x.driver_id===target.dataset.brq33Open||x.driver_id===target.dataset.brq33Pay||x.driver_id===target.dataset.brq33History);
      if(!r)return;
      if(edit){
        $('brq33SalaryDriver').textContent='مندوب: '+r.driver_name+' — بغداد';
        $('brq33SalaryDriverId').value=r.driver_id;
        $('brq33SalaryValue').value=String(r.monthly_salary_iqd??500000);
        const thisMonth=brq33NowMonth();
        // Previously opened payroll snapshots must never be rewritten.
        const start=r.payroll_id&&$('brq33Month').value===thisMonth?brq33NextMonth(thisMonth):thisMonth;
        $('brq33EffectiveMonth').min=thisMonth;
        $('brq33EffectiveMonth').value=start;
        $('brq33SalaryActive').value=r.salary_active===false?'false':'true';
        setError('brq33SalaryError','');showModal('brq33SalaryModal');return;
      }
      if(open){
        const month=brq33Date($('brq33Month').value);
        if(!month||!confirm('تثبيت راتب '+r.driver_name+' كاملاً عن '+$('brq33Month').value+' بمبلغ '+money(r.monthly_salary_iqd)+' د.ع؟\nهذه العملية لا تعني صرف المال.'))return;
        open.disabled=true;
        try{
          await verifiedAdmin();
          const {error}=await sb.rpc('barq_admin_open_salary_month_v33',{p_driver_id:r.driver_id,p_month:month});
          if(error)throw error;await brq33RefreshPayroll();brq33Success('تم تثبيت راتب الشهر كمستحق، ولم يُسجّل صرف نقدي بعد. ✅');
        }catch(ex){brq33Message('تعذر فتح كشف الراتب: '+(ex.message||ex));}
        finally{open.disabled=false;}
        return;
      }
      if(pay){
        if(!r.payroll_id||Number(r.due_iqd)<=0)return;
        $('brq33PayrollId').value=r.payroll_id;
        $('brq33PaySummary').textContent=r.driver_name+' · '+$('brq33Month').value+' · المتبقي '+money(r.due_iqd)+' د.ع';
        $('brq33PayAmount').value=String(r.due_iqd);
        $('brq33PayAmount').max=String(r.due_iqd);
        $('brq33PayNote').value='';brq33PaymentRequestId=crypto.randomUUID();setError('brq33PayError','');showModal('brq33PayModal');return;
      }
      if(history){
        $('brq33HistoryDriver').textContent=r.driver_name+' · '+$('brq33Month').value;
        $('brq33HistoryRows').textContent='جاري تحميل الدفعات...';showModal('brq33HistoryModal');
        try{
          const {data,error}=await sb.rpc('barq_admin_salary_payments_v33',{p_payroll_id:r.payroll_id});
          if(error)throw error;
          $('brq33HistoryRows').innerHTML=(data||[]).length?(data||[]).map(p=>`<div class="notice" style="margin-bottom:9px"><strong>${money(p.amount_iqd)} د.ع</strong> — ${new Date(p.paid_at).toLocaleString('ar-IQ',{timeZone:'Asia/Baghdad'})}<div>${nice(p.note)}</div></div>`).join(''):'<p class="notice">لا توجد دفعات راتب مسجلة حتى الآن.</p>';
        }catch(ex){$('brq33HistoryRows').textContent='تعذر قراءة السجل: '+(ex.message||ex);}
      }
    });
    $('brq33SalaryForm').addEventListener('submit',async e=>{
      e.preventDefault();const b=$('brq33SalarySave');b.disabled=true;
      setError('brq33SalaryError','');
      try{
        await verifiedAdmin();
        const salary=validDinars($('brq33SalaryValue').value,'الراتب الشهري');
        if(salary<1||salary>1000000000)throw Error('حدد راتباً صحيحاً أكبر من صفر');
        const month=brq33Date($('brq33EffectiveMonth').value);if(!month)throw Error('اختر شهر البدء');
        const {error}=await sb.rpc('barq_admin_set_salary_v33',{
          p_driver_id:$('brq33SalaryDriverId').value,
          p_monthly_salary_iqd:salary,
          p_effective_month:month,
          p_is_active:$('brq33SalaryActive').value==='true'
        });
        if(error)throw error;
        const changedMonth=$('brq33EffectiveMonth').value;closeModal('brq33SalaryModal');await brq33RefreshPayroll();brq33Success('تم حفظ الراتب ابتداءً من '+changedMonth+' ✅ إذا كان هذا شهراً مستقبلياً، اختره من القائمة لرؤية الراتب الجديد.');
      }catch(ex){setError('brq33SalaryError',ex.message||String(ex));}
      finally{b.disabled=false;}
    });
    $('brq33PayForm').addEventListener('submit',async e=>{
      e.preventDefault();const b=$('brq33PaySave');b.disabled=true;
      setError('brq33PayError','');
      try{
        await verifiedAdmin();
        const amount=validDinars($('brq33PayAmount').value,'المبلغ المصروف');
        if(amount<=0||amount>Number($('brq33PayAmount').max))throw Error('المبلغ يجب ألا يتجاوز الرصيد المتبقي');
        if(!confirm('هل صرفت '+money(amount)+' دينار فعلياً لهذا المندوب؟\nسيضاف إلى سجل المدفوعات ولا يمكن اعتباره مجرد وعد بالدفع.'))return;
        const {error}=await sb.rpc('barq_admin_pay_salary_v33',{
          p_payroll_id:$('brq33PayrollId').value,
          p_amount_iqd:amount,
          p_note:$('brq33PayNote').value.trim(),
          p_request_id:brq33PaymentRequestId
        });
        if(error)throw error;
        closeModal('brq33PayModal');brq33PaymentRequestId=null;await brq33RefreshPayroll();brq33Success('تم تسجيل صرف الراتب الفعلي في السجل. ✅');
      }catch(ex){setError('brq33PayError',ex.message||String(ex));}
      finally{b.disabled=false;}
    });



    // BARQ V35 — percent of delivery fee, with server-side snapshot at verified delivery.
    let brq35Data={rates:[],drivers:[],items:[]};
    $('brq35Month').value=brq33NowMonth();
    function brq35Message(error='',success=''){
      setError('brq35Error',error);$('brq35Success').textContent=success;
      $('brq35Success').classList.toggle('hide',!success);
    }
    function brq35Targets(){
      const scope=$('brq35Scope').value;
      $('brq35TargetWrap').classList.toggle('hide',scope==='global');
      const previous=$('brq35Target').value;
      if(scope==='branch')$('brq35Target').innerHTML='<option value="">اختر الفرع</option>'+(currentData.branches||[]).map(b=>`<option value="${esc(b.id)}">${esc(b.name)} — ${esc(b.governorate)}</option>`).join('');
      else if(scope==='driver')$('brq35Target').innerHTML='<option value="">اختر المندوب</option>'+(currentData.drivers||[]).map(d=>`<option value="${esc(d.id)}">${getDriverLabel(d)} — ${esc(brq25DriverBranchLabel(d))}</option>`).join('');
      if([...$('brq35Target').options].some(o=>o.value===previous))$('brq35Target').value=previous;
      brq35ApplyRate();
    }
    function brq35ApplyRate(){
      const scope=$('brq35Scope').value,target=$('brq35Target').value;
      if(scope!=='global'&&!target){$('brq35Pickup').value='';$('brq35Delivery').value='';return;}
      const find=role=>(brq35Data.rates||[]).find(r=>r.role===role&&
        (scope==='driver'?r.driver_id===target:scope==='branch'?r.branch_id===target&&!r.driver_id:!r.driver_id&&!r.branch_id));
      $('brq35Pickup').value=find('pickup')?.percent??'';
      $('brq35Delivery').value=find('delivery')?.percent??'';
    }
    function brq35Render(){
      brq35Targets();
      const drivers=brq35Data.drivers||[];
      $('brq35DriverCards').innerHTML=drivers.length?drivers.map(d=>`<article class="brq33-card">
        <header class="brq33-card-header"><h5>${nice(d.driver_name)}</h5><span class="pill blue">${nice(d.branch_name)}</span></header>
        <div class="brq33-card-stats">
          <div><small>استلام للمخزن</small><strong>${d.pickup_percent==null?'غير محددة':esc(d.pickup_percent)+'%'}</strong></div>
          <div><small>توصيل للزبون</small><strong>${d.delivery_percent==null?'غير محددة':esc(d.delivery_percent)+'%'}</strong></div>
          <div><small>مستحق من طلبات الشهر</small><strong>${money(d.earned_iqd)} د.ع</strong></div>
          <div><small>عمليات مثبتة / معلّقة</small><strong>${money(d.jobs)} / ${money(d.pending)}</strong></div>
        </div></article>`).join(''):'<p class="notice">لا توجد حسابات مندوبيـن.</p>';
      const items=brq35Data.items||[];
      $('brq35Rows').innerHTML=items.length?items.map(r=>`<tr>
        <td>${esc(shortId(r.order_id))}</td><td>${nice(r.driver_name)}</td><td>${nice(r.branch_name)}</td>
        <td>${r.role==='pickup'?'استلام للمخزن':'تسليم الزبون'}</td>
        <td>${money(r.fee)} د.ع</td><td>${r.percent===null?'—':esc(r.percent)+'%'}</td>
        <td>${r.amount===null?'<span class="pill orange">تحتاج تحديد نسبة</span>':money(r.amount)+' د.ع'}</td>
        <td>${r.amount===null?`<button type="button" class="tiny-action" data-brq35-finalize="${esc(r.order_id)}">تثبيت بعد تحديد النسب</button>`:'مُثبت'}</td></tr>`).join(''):rowEmpty(8,'لا توجد توصيلات جديدة مسجلة بعد تفعيل V35 لهذا الشهر');
    }
    async function brq35Refresh(){
      if(!sb)return;
      const month=brq33Date($('brq35Month').value);
      if(!month)return brq35Message('حدد شهر الكشف');
      $('brq35Refresh').disabled=true;
      try{
        const {data,error}=await sb.rpc('barq_admin_commissions_v35',{p_month:month});
        if(error)throw error;brq35Data=data||{rates:[],drivers:[],items:[]};
        brq35Message();brq35Render();
      }catch(e){brq35Data={rates:[],drivers:[],items:[]};brq35Render();brq35Message('تعذر تحميل النسب، تأكد من تشغيل SQL V35: '+(e.message||e));}
      finally{$('brq35Refresh').disabled=false;}
    }
    $('brq35Scope').addEventListener('change',brq35Targets);
    $('brq35Target').addEventListener('change',brq35ApplyRate);
    $('brq35Month').addEventListener('change',()=>void brq35Refresh());
    $('brq35Refresh').addEventListener('click',()=>void brq35Refresh());
    $('brq35RateForm').addEventListener('submit',async ev=>{
      ev.preventDefault();brq35Message();
      const btn=$('brq35Save');btn.disabled=true;
      try{
        await verifiedAdmin();
        const scope=$('brq35Scope').value,target=$('brq35Target').value;
        if(scope!=='global'&&!target)throw Error('اختار الفرع أو المندوب');
        const pickup=Number($('brq35Pickup').value),delivery=Number($('brq35Delivery').value);
        if(!Number.isFinite(pickup)||!Number.isFinite(delivery)||pickup<0||delivery<0||pickup>100||delivery>100||pickup+delivery>100)throw Error('مجموع النسبتين لا يتجاوز 100%');
        if(!confirm('تثبيت نسبة الاستلام '+pickup+'% ونسبة التسليم '+delivery+'%؟\nلن نعدّل عمولات طلبات مسلّمة وثُبتت سابقاً.'))return;
        const {error}=await sb.rpc('barq_admin_set_rates_v35',{
          p_branch_id:scope==='branch'?target:null,p_driver_id:scope==='driver'?target:null,
          p_pickup:pickup,p_delivery:delivery});
        if(error)throw error;
        await brq35Refresh();brq35Message('','تم حفظ النسب ✅ الطلبات الجديدة تعتمدها عند التسليم.');
      }catch(e){brq35Message(e.message||String(e));}
      finally{btn.disabled=false;}
    });
    $('brq35Rows').addEventListener('click',async ev=>{
      const btn=ev.target.closest('[data-brq35-finalize]');if(!btn)return;
      if(!confirm('حساب عمولة هذا الطلب المعلّق بالنسب المحددة حالياً؟'))return;
      btn.disabled=true;
      try{await verifiedAdmin();const {error}=await sb.rpc('barq_admin_finalize_commission_v35',{p_order_id:btn.dataset.brq35Finalize});
        if(error)throw error;await brq35Refresh();brq35Message('','تم تثبيت عمولة الطلب المعلّق ✅');
      }catch(e){brq35Message('تعذر تثبيت العمولة: '+(e.message||e));}finally{btn.disabled=false;}
    });

    // BARQ V35 — reconciled branch finance with percentage-based courier earnings.
    let brq34Report=null;
    let brq34ExpenseRequestId=null;
    const brq34Categories={transport:'النقل بين الفروع',fuel:'وقود',rent:'إيجار',utilities:'خدمات وفواتير',maintenance:'صيانة',other:'أخرى'};
    const brq34BaghdadToday=()=>{
      const pieces=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Baghdad',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());
      const get=t=>pieces.find(p=>p.type===t)?.value||'';
      return get('year')+'-'+get('month')+'-'+get('day');
    };
    $('brq34Month').value=brq33NowMonth();
    $('brq34ExpenseDate').value=brq34BaghdadToday();
    $('brq34ExpenseDate').max=brq34BaghdadToday();
    const brq34Amount=(v)=>money(Number(v||0))+' د.ع';
    const brq34Sum=(rows,k)=>rows.reduce((n,r)=>n+Number(r[k]||0),0);
    function brq34Message(err='',success=''){
      setError('brq34Error',err);
      $('brq34Success').textContent=success;
      $('brq34Success').classList.toggle('hide',!success);
    }
    async function brq34Refresh(){
      if(!sb)return;
      const month=brq33Date($('brq34Month').value);
      if(!month){brq34Message('اختر شهر تقرير صحيح');return;}
      $('brq34Refresh').disabled=true;
      try{
        const {data,error}=await sb.rpc('barq_admin_financial_report_v35',{p_month:month});
        if(error)throw error;
        brq34Report=data||{branches:[],expenses:[]};
        brq34Message();brq34Render();
      }catch(e){brq34Report=null;brq34Render();brq34Message('تعذر تحميل التقرير. تأكد من تنفيذ SQL الخاص بـ V34 ثم V35: '+(e.message||e));}
      finally{$('brq34Refresh').disabled=false;}
    }
    function brq34Render(){
      const branches=Array.isArray(brq34Report?.branches)?brq34Report.branches:[];
      const previous=$('brq34BranchFilter').value||'all';
      $('brq34BranchFilter').innerHTML='<option value="all">جميع الفروع</option>'+branches.map(b=>
        `<option value="${esc(b.branch_id||'hq')}">${esc(b.governorate==='غير محددة'?'المركز / بدون فرع':b.name)}</option>`).join('');
      if([...$('brq34BranchFilter').options].some(opt=>opt.value===previous))$('brq34BranchFilter').value=previous;
      const selected=$('brq34BranchFilter').value;
      const filtered=branches.filter(b=>selected==='all'||(b.branch_id||'hq')===selected);
      const values=[
        ['أجور التوصيل المعترف بها','fee_revenue'],
        ['حصص مندوبي التوصيل','delivery_commissions'],
        ['رواتب تاريخية غير ملغاة','salary_accrued'],
        ['مصاريف التشغيل','operating_cost'],
        ['النتيجة التشغيلية التقديرية','estimated_operating_result'],
        ['طلبات مسلّمة ناقصة الحساب','incomplete_count']
      ];
      $('brq34Stats').innerHTML=branches.length?values.map(([label,key])=>{
        const total=brq34Sum(filtered,key);
        const pending=brq34Sum(filtered,'commission_pending_count');
        return `<div class="brq34-stat ${total<0?'brq34-negative':''}"><span>${esc(label)}</span><strong>${key==='estimated_operating_result'&&pending>0?'غير مكتمل — نسب معلّقة':key==='incomplete_count'?money(total):brq34Amount(total)}</strong></div>`;
      }).join(''):'<div class="notice">لا توجد بيانات. اضغط تحديث التقرير.</div>';
      $('brq34Branches').innerHTML=filtered.length?filtered.map(b=>{
        return `<div class="brq34-entry"><div><strong>${nice(b.name)}</strong><small>${nice(b.governorate)} · ${money(b.delivered_count)} طلب مسلَّم · ${money(b.incomplete_count)} طلب ناقص الحساب</small>
          <small>${Number(b.approximate_date_count)>0?'⚠ تاريخ '+money(b.approximate_date_count)+' طلب تقديري (آخر تحديث)':''}</small></div>
          <div style="text-align:left"><strong class="${Number(b.estimated_operating_result)<0?'brq34-negative':''}">${b.estimated_operating_result===null?'نسب غير مكتملة':brq34Amount(b.estimated_operating_result)}</strong><small>نتيجة تقديرية</small></div></div>`;
      }).join(''):'<p class="hint">لا توجد فروع مطابقة للفلتر.</p>';
      const cash=[
        ['استلامات المندوبين النقدية','cash_driver_collections'],
        ['مدفوعات المحلات','cash_merchant_payments'],
        ['رواتب تاريخية صُرفت فعلياً خلال الشهر','cash_salary_payments'],
        ['مصاريف تشغيل مسجلة','operating_cost'],
        ['رواتب تاريخية غير مصروفة','salary_due']
      ];
      $('brq34Cash').innerHTML=cash.map(([label,key])=>{
        const total=key==='salary_due'?brq34Sum(filtered,'salary_accrued')-brq34Sum(filtered,'salary_paid_against_month'):brq34Sum(filtered,key);
        return `<div class="brq34-cell"><small>${esc(label)}</small><strong>${brq34Amount(total)}</strong></div>`;
      }).join('');
      const prevExpenseBranch=$('brq34ExpenseBranch').value;
      $('brq34ExpenseBranch').innerHTML='<option value="hq">المركز — مصروف عام</option>'+branches.filter(b=>b.branch_id).map(b=>`<option value="${esc(b.branch_id)}">${esc(b.name)}</option>`).join('');
      if([...$('brq34ExpenseBranch').options].some(opt=>opt.value===prevExpenseBranch))$('brq34ExpenseBranch').value=prevExpenseBranch;
      const allExpenses=Array.isArray(brq34Report?.expenses)?brq34Report.expenses:[];
      const visible=allExpenses.filter(e=>selected==='all'||(e.branch_id||'hq')===selected);
      $('brq34ExpenseRows').innerHTML=visible.length?visible.map(e=>`<div class="brq34-entry ${e.voided_at?'brq34-voided':''}">
        <div><strong>${brq34Amount(e.amount_iqd)} — ${esc(brq34Categories[e.category]||'أخرى')}</strong>
          <small>${nice(e.expense_date)} · ${nice(e.branch_name)}</small><small>${nice(e.description)}</small>
          ${e.voided_at?`<small>ملغي — ${nice(e.void_reason)}</small>`:''}</div>
        ${e.voided_at?'<span class="pill">ملغي</span>':`<button class="btn btn-outline" type="button" data-brq34-void="${esc(e.id)}">إلغاء بقيد تدقيق</button>`}
      </div>`).join(''):'<p class="hint">لا توجد مصروفات مسجّلة ضمن هذا الشهر والفرع.</p>';
    }
    $('brq34Month').addEventListener('change',()=>{brq34Message();void brq34Refresh();});
    $('brq34BranchFilter').addEventListener('change',brq34Render);
    $('brq34Refresh').addEventListener('click',()=>void brq34Refresh());
    $('brq34ExpenseForm').addEventListener('input',()=>{brq34ExpenseRequestId=null;});
    $('brq34ExpenseForm').addEventListener('submit',async ev=>{
      ev.preventDefault();brq34Message();const btn=$('brq34SaveExpense');btn.disabled=true;
      try{
        await verifiedAdmin();
        const amount=validDinars($('brq34ExpenseAmount').value,'المبلغ');
        if(amount<1||amount>1000000000)throw Error('المبلغ يجب أن يكون من 1 إلى مليار دينار');
        const day=$('brq34ExpenseDate').value;
        if(!/^\d{4}-\d{2}-\d{2}$/.test(day)||day>brq34BaghdadToday())throw Error('تاريخ المصروف غير صحيح');
        if(!confirm('هل تم دفع '+money(amount)+' دينار فعلياً لهذا المصروف؟\nسيظهر هذا المصروف في سجل الفرع.'))return;
        brq34ExpenseRequestId=brq34ExpenseRequestId||crypto.randomUUID();
        const {error}=await sb.rpc('barq_admin_add_expense_v34',{
          p_branch_id:$('brq34ExpenseBranch').value==='hq'?null:$('brq34ExpenseBranch').value,
          p_expense_date:day,p_category:$('brq34ExpenseCategory').value,p_amount_iqd:amount,
          p_description:$('brq34ExpenseDescription').value.trim(),p_request_id:brq34ExpenseRequestId
        });
        if(error)throw error;
        brq34ExpenseRequestId=null;$('brq34ExpenseAmount').value='';$('brq34ExpenseDescription').value='';
        $('brq34Month').value=day.slice(0,7);await brq34Refresh();brq34Message('','تم حفظ المصروف الفعلي مع سجل تدقيق ✅');
      }catch(e){brq34Message('تعذر تسجيل المصروف: '+(e.message||e));}
      finally{btn.disabled=false;}
    });
    $('brq34ExpenseRows').addEventListener('click',async ev=>{
      const b=ev.target.closest('[data-brq34-void]');if(!b)return;
      const reason=prompt('سبب إلغاء المصروف (5 أحرف على الأقل):');if(reason===null)return;
      if(reason.trim().length<5){brq34Message('اكتب سبباً واضحاً للإلغاء');return;}
      if(!confirm('تأكيد إلغاء المصروف من الحسابات مع حفظ سجل الإلغاء؟'))return;
      b.disabled=true;
      try{await verifiedAdmin();const {error}=await sb.rpc('barq_admin_void_expense_v34',{p_expense_id:b.dataset.brq34Void,p_reason:reason.trim()});if(error)throw error;
        await brq34Refresh();brq34Message('','تم إلغاء المصروف وحفظ سبب الإلغاء ✅');
      }catch(e){brq34Message('تعذر إلغاء المصروف: '+(e.message||e));}finally{b.disabled=false;}
    });

    boot();
  