-- BARQ V35 | Every branch / every courier: percentage of the DELIVERY FEE.
-- INSTALL: after the V34 SQL (V34 app need not be published). Back up your database.
-- No historical delivered order is repriced. New orders are captured when actually delivered.
-- No rate is silently assumed; set the company-wide pickup and delivery rates in V35 first.
-- Yusuf's UNPAID November 2026 payroll of 500,000 IQD is cancelled with an audit copy.
-- Actually paid payroll is NEVER deleted or cancelled by this migration.
BEGIN;

CREATE TABLE IF NOT EXISTS public.barq_commission_rates_v35 (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 role_type text NOT NULL CHECK (role_type IN ('pickup','delivery')),
 branch_id uuid REFERENCES public.barq_branches(id),
 driver_id uuid REFERENCES public.drivers(id),
 percent numeric(5,2) NOT NULL CHECK (percent BETWEEN 0 AND 100),
 updated_by uuid REFERENCES auth.users(id),
 updated_at timestamptz NOT NULL DEFAULT now(),
 CHECK (branch_id IS NULL OR driver_id IS NULL)
);
CREATE UNIQUE INDEX IF NOT EXISTS barq_v35_global_rate_uq ON public.barq_commission_rates_v35(role_type) WHERE branch_id IS NULL AND driver_id IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS barq_v35_branch_rate_uq ON public.barq_commission_rates_v35(role_type,branch_id) WHERE branch_id IS NOT NULL AND driver_id IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS barq_v35_driver_rate_uq ON public.barq_commission_rates_v35(role_type,driver_id) WHERE driver_id IS NOT NULL;
ALTER TABLE public.barq_commission_rates_v35 ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.barq_commission_rates_v35 FROM PUBLIC,anon,authenticated;

CREATE TABLE IF NOT EXISTS public.barq_commission_earnings_v35 (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE RESTRICT,
 driver_id uuid NOT NULL REFERENCES public.drivers(id) ON DELETE RESTRICT,
 branch_id uuid REFERENCES public.barq_branches(id),
 role_type text NOT NULL CHECK (role_type IN ('pickup','delivery')),
 base_fee_iqd bigint,
 percent numeric(5,2),
 amount_iqd bigint,
 earned_at timestamptz NOT NULL DEFAULT now(),
 CONSTRAINT barq_v35_one_role_per_order UNIQUE (order_id,role_type),
 CHECK (amount_iqd IS NULL OR amount_iqd >= 0),
 CHECK (percent IS NULL OR percent BETWEEN 0 AND 100)
);
CREATE INDEX IF NOT EXISTS barq_v35_earnings_month_idx ON public.barq_commission_earnings_v35(earned_at,branch_id,driver_id);
ALTER TABLE public.barq_commission_earnings_v35 ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.barq_commission_earnings_v35 FROM PUBLIC,anon,authenticated;

CREATE TABLE IF NOT EXISTS public.barq_payroll_cancellations_v35 (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 old_payroll_id uuid NOT NULL UNIQUE,
 driver_id uuid NOT NULL,
 branch_id uuid NOT NULL,
 salary_month date NOT NULL,
 salary_amount_iqd bigint NOT NULL,
 reason text NOT NULL,
 cancelled_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.barq_payroll_cancellations_v35 ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.barq_payroll_cancellations_v35 FROM PUBLIC,anon,authenticated;

-- Archive then delete ONLY Yusuf's confirmed unpaid Nov-2026 opened payroll.
WITH candidate AS (
 SELECT pm.* FROM public.barq_driver_payroll_months_v33 pm
 JOIN public.drivers d ON d.id=pm.driver_id
 JOIN public.profiles p ON p.id=d.user_id
 JOIN public.barq_branches b ON b.id=pm.branch_id
 WHERE b.code='BGD' AND p.full_name='يوسف'
  AND pm.salary_month=DATE '2026-11-01' AND pm.salary_amount_iqd=500000
  AND NOT EXISTS (SELECT 1 FROM public.barq_driver_salary_payments_v33 x WHERE x.payroll_id=pm.id)
), archived AS (
 INSERT INTO public.barq_payroll_cancellations_v35
 (old_payroll_id,driver_id,branch_id,salary_month,salary_amount_iqd,reason)
 SELECT id,driver_id,branch_id,salary_month,salary_amount_iqd,
        'V35: change to percentage; unpaid Yusuf Nov-2026 payroll cancelled'
 FROM candidate ON CONFLICT (old_payroll_id) DO NOTHING RETURNING old_payroll_id
)
DELETE FROM public.barq_driver_payroll_months_v33 pm
USING archived a
WHERE pm.id=a.old_payroll_id AND NOT EXISTS (
 SELECT 1 FROM public.barq_driver_salary_payments_v33 x WHERE x.payroll_id=pm.id
);
-- Disable old Baghdad salary schedules (keep historical rate records).
UPDATE public.barq_driver_salary_rates_v33 SET is_active=false WHERE is_active=true;
-- Old salary RPCs remain in DB for historic traceability, but aren't callable from the app.
REVOKE EXECUTE ON FUNCTION public.barq_admin_set_salary_v33(uuid,bigint,date,boolean) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_admin_open_salary_month_v33(uuid,date) FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.barq_admin_pay_salary_v33(uuid,bigint,text,uuid) FROM PUBLIC,anon,authenticated;

CREATE OR REPLACE FUNCTION public.barq_v35_rate(p_role text,p_driver uuid,p_branch uuid)
RETURNS numeric LANGUAGE sql STABLE SECURITY DEFINER SET search_path='' AS $fn$
 SELECT r.percent FROM public.barq_commission_rates_v35 r
 WHERE r.role_type=p_role
   AND (r.driver_id=p_driver OR (r.driver_id IS NULL AND r.branch_id=p_branch)
         OR (r.driver_id IS NULL AND r.branch_id IS NULL))
 ORDER BY CASE WHEN r.driver_id IS NOT NULL THEN 1
               WHEN r.branch_id IS NOT NULL THEN 2 ELSE 3 END
 LIMIT 1;
$fn$;
REVOKE ALL ON FUNCTION public.barq_v35_rate(text,uuid,uuid) FROM PUBLIC,anon,authenticated;

-- Secure, idempotent snapshot after an actual delivered transition only.
CREATE OR REPLACE FUNCTION public.barq_v35_capture_delivered()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $fn$
DECLARE v_final uuid; v_pickup uuid; v_final_branch uuid; v_pickup_branch uuid;
        v_final_pct numeric; v_pickup_pct numeric; v_valid boolean;
BEGIN
 IF OLD.status IS NOT DISTINCT FROM 'delivered' OR NEW.status <> 'delivered' THEN RETURN NEW; END IF;
 SELECT coalesce(lm.driver_id,NEW.driver_id),lm.original_driver_id
 INTO v_final,v_pickup
 FROM (SELECT 1) one
 LEFT JOIN public.barq_last_mile_v28 lm ON lm.order_id=NEW.id;
 IF v_final IS NULL THEN v_final:=NEW.driver_id; END IF;
 IF v_pickup IS NULL AND v_final IS NOT NULL THEN
  SELECT r.driver_id INTO v_pickup FROM public.barq_order_routes r
  WHERE r.order_id=NEW.id AND r.driver_id IS NOT NULL AND r.driver_id<>v_final
  ORDER BY r.created_at ASC LIMIT 1;
 END IF;
 IF v_final IS NULL THEN RETURN NEW; END IF;
 IF v_pickup=v_final THEN v_pickup:=NULL; END IF;
 SELECT d.branch_id INTO v_final_branch FROM public.drivers d WHERE d.id=v_final;
 IF v_pickup IS NOT NULL THEN SELECT d.branch_id INTO v_pickup_branch FROM public.drivers d WHERE d.id=v_pickup; END IF;
 v_final_pct:=public.barq_v35_rate('delivery',v_final,v_final_branch);
 IF v_pickup IS NOT NULL THEN v_pickup_pct:=public.barq_v35_rate('pickup',v_pickup,v_pickup_branch); END IF;
 v_valid := NEW.delivery_fee_iqd IS NOT NULL AND NEW.delivery_fee_iqd>=0 AND
           v_final_pct IS NOT NULL AND (v_pickup IS NULL OR v_pickup_pct IS NOT NULL)
           AND v_final_pct+coalesce(v_pickup_pct,0)<=100;
 -- If percentages are not yet configured, leave both allocations pending (NULL).
 IF v_pickup IS NOT NULL THEN
  INSERT INTO public.barq_commission_earnings_v35
   (order_id,driver_id,branch_id,role_type,base_fee_iqd,percent,amount_iqd)
  VALUES (NEW.id,v_pickup,v_pickup_branch,'pickup',NEW.delivery_fee_iqd,
    CASE WHEN v_valid THEN v_pickup_pct ELSE NULL END,
    CASE WHEN v_valid THEN floor(NEW.delivery_fee_iqd*v_pickup_pct/100)::bigint ELSE NULL END)
  ON CONFLICT (order_id,role_type) DO NOTHING;
 END IF;
 INSERT INTO public.barq_commission_earnings_v35
  (order_id,driver_id,branch_id,role_type,base_fee_iqd,percent,amount_iqd)
 VALUES (NEW.id,v_final,v_final_branch,'delivery',NEW.delivery_fee_iqd,
   CASE WHEN v_valid THEN v_final_pct ELSE NULL END,
   CASE WHEN v_valid THEN floor(NEW.delivery_fee_iqd*v_final_pct/100)::bigint ELSE NULL END)
 ON CONFLICT (order_id,role_type) DO NOTHING;
 RETURN NEW;
END;
$fn$;
DROP TRIGGER IF EXISTS barq_v35_capture_delivered_trigger ON public.orders;
CREATE TRIGGER barq_v35_capture_delivered_trigger
AFTER UPDATE OF status ON public.orders FOR EACH ROW
WHEN (OLD.status IS DISTINCT FROM NEW.status AND NEW.status='delivered')
EXECUTE FUNCTION public.barq_v35_capture_delivered();
REVOKE ALL ON FUNCTION public.barq_v35_capture_delivered() FROM PUBLIC,anon,authenticated;

CREATE OR REPLACE FUNCTION public.barq_admin_set_rates_v35(
 p_branch_id uuid,p_driver_id uuid,p_pickup numeric,p_delivery numeric)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $fn$
DECLARE v_role text; v_pct numeric;
BEGIN
 IF auth.uid() IS NULL OR NOT EXISTS
 (SELECT 1 FROM public.profiles p WHERE p.id=auth.uid() AND p.role='admin')
 THEN RAISE EXCEPTION 'الإدارة العامة فقط' USING ERRCODE='42501'; END IF;
 IF p_branch_id IS NOT NULL AND p_driver_id IS NOT NULL THEN RAISE EXCEPTION 'حدد فرعاً أو مندوباً، مو الاثنين' USING ERRCODE='22023'; END IF;
 IF p_branch_id IS NOT NULL AND NOT EXISTS
 (SELECT 1 FROM public.barq_branches b WHERE b.id=p_branch_id)
 THEN RAISE EXCEPTION 'الفرع غير موجود' USING ERRCODE='22023'; END IF;
 IF p_driver_id IS NOT NULL AND NOT EXISTS
 (SELECT 1 FROM public.drivers d WHERE d.id=p_driver_id)
 THEN RAISE EXCEPTION 'المندوب غير موجود' USING ERRCODE='22023'; END IF;
 IF p_pickup IS NULL OR p_delivery IS NULL OR p_pickup<0 OR p_delivery<0
    OR p_pickup>100 OR p_delivery>100 OR p_pickup+p_delivery>100
    OR p_pickup<>round(p_pickup,2) OR p_delivery<>round(p_delivery,2)
 THEN RAISE EXCEPTION 'حدد نسبتين مجموعهما لا يتجاوز 100%%' USING ERRCODE='22023'; END IF;
 FOREACH v_role IN ARRAY ARRAY['pickup','delivery'] LOOP
  v_pct:=CASE WHEN v_role='pickup' THEN p_pickup ELSE p_delivery END;
  UPDATE public.barq_commission_rates_v35 r SET percent=v_pct,updated_by=auth.uid(),updated_at=now()
  WHERE r.role_type=v_role AND r.branch_id IS NOT DISTINCT FROM p_branch_id
   AND r.driver_id IS NOT DISTINCT FROM p_driver_id;
  IF NOT FOUND THEN
   INSERT INTO public.barq_commission_rates_v35(role_type,branch_id,driver_id,percent,updated_by)
   VALUES(v_role,p_branch_id,p_driver_id,v_pct,auth.uid());
  END IF;
 END LOOP;
END;
$fn$;

-- Resolve old "pending rate" snapshots only when the admin explicitly requests it.
CREATE OR REPLACE FUNCTION public.barq_admin_finalize_commission_v35(p_order_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $fn$
DECLARE v_fee bigint; v_pick numeric; v_final numeric; v_has_pick boolean;
BEGIN
 IF auth.uid() IS NULL OR NOT EXISTS
 (SELECT 1 FROM public.profiles WHERE id=auth.uid() AND role='admin')
 THEN RAISE EXCEPTION 'الإدارة العامة فقط' USING ERRCODE='42501'; END IF;
 SELECT o.delivery_fee_iqd INTO v_fee FROM public.orders o
 WHERE o.id=p_order_id AND o.status='delivered' FOR UPDATE;
 IF NOT FOUND OR v_fee IS NULL OR v_fee<0 THEN RAISE EXCEPTION 'الطلب غير مسلّم أو أجرة التوصيل غير محددة' USING ERRCODE='22023'; END IF;
 IF NOT EXISTS (SELECT 1 FROM public.barq_commission_earnings_v35 WHERE order_id=p_order_id)
 THEN RAISE EXCEPTION 'الطلب قديم قبل V35 ولا يُعاد حسابه تلقائياً' USING ERRCODE='22023'; END IF;
 SELECT public.barq_v35_rate('pickup',driver_id,branch_id) INTO v_pick
 FROM public.barq_commission_earnings_v35 WHERE order_id=p_order_id AND role_type='pickup';
 v_has_pick:=FOUND;
 SELECT public.barq_v35_rate('delivery',driver_id,branch_id) INTO v_final
 FROM public.barq_commission_earnings_v35 WHERE order_id=p_order_id AND role_type='delivery';
 IF v_final IS NULL OR (v_has_pick AND v_pick IS NULL) OR v_final+coalesce(v_pick,0)>100 THEN
  RAISE EXCEPTION 'نسب المندوبين غير مكتملة أو مجموع النسب يتجاوز 100%%' USING ERRCODE='22023'; END IF;
 UPDATE public.barq_commission_earnings_v35 c
 SET percent=CASE WHEN c.role_type='pickup' THEN v_pick ELSE v_final END,
     amount_iqd=floor(v_fee*(CASE WHEN c.role_type='pickup' THEN v_pick ELSE v_final END)/100)::bigint
 WHERE c.order_id=p_order_id AND c.amount_iqd IS NULL;
END;
$fn$;

CREATE OR REPLACE FUNCTION public.barq_admin_commissions_v35(p_month date)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $fn$
DECLARE v_rates jsonb; v_drivers jsonb; v_items jsonb;
BEGIN
 IF auth.uid() IS NULL OR NOT EXISTS
 (SELECT 1 FROM public.profiles WHERE id=auth.uid() AND role='admin')
 THEN RAISE EXCEPTION 'الإدارة العامة فقط' USING ERRCODE='42501'; END IF;
 IF p_month IS NULL OR EXTRACT(day FROM p_month)<>1 THEN
  RAISE EXCEPTION 'اختر شهراً صحيحاً' USING ERRCODE='22023'; END IF;
 SELECT coalesce(jsonb_agg(jsonb_build_object('role',r.role_type,
   'branch_id',r.branch_id,'driver_id',r.driver_id,'percent',r.percent)),'[]'::jsonb)
 INTO v_rates FROM public.barq_commission_rates_v35 r;
 SELECT coalesce(jsonb_agg(jsonb_build_object('driver_id',d.id,
    'driver_name',coalesce(nullif(btrim(p.full_name),''),'بدون اسم'),
    'branch_id',d.branch_id,'branch_name',coalesce(b.name,'بدون فرع'),
    'pickup_percent',public.barq_v35_rate('pickup',d.id,d.branch_id),
    'delivery_percent',public.barq_v35_rate('delivery',d.id,d.branch_id),
    'earned_iqd',coalesce(t.total,0),'jobs',coalesce(t.jobs,0),
    'pending',coalesce(t.pending,0)) ORDER BY b.name,p.full_name,d.id::text),'[]'::jsonb)
 INTO v_drivers
 FROM public.drivers d LEFT JOIN public.profiles p ON p.id=d.user_id
 LEFT JOIN public.barq_branches b ON b.id=d.branch_id
 LEFT JOIN LATERAL (SELECT sum(c.amount_iqd)::bigint AS total,
   count(*) FILTER(WHERE c.amount_iqd IS NOT NULL) AS jobs,
   count(*) FILTER(WHERE c.amount_iqd IS NULL) AS pending
   FROM public.barq_commission_earnings_v35 c
   WHERE c.driver_id=d.id AND (c.earned_at AT TIME ZONE 'Asia/Baghdad')::date>=p_month
     AND (c.earned_at AT TIME ZONE 'Asia/Baghdad')::date<(p_month+INTERVAL '1 month')::date) t ON true;
 SELECT coalesce(jsonb_agg(jsonb_build_object(
  'order_id',c.order_id,'driver_id',c.driver_id,
  'driver_name',coalesce(nullif(btrim(p.full_name),''),'بدون اسم'),
  'role',c.role_type,'branch_id',c.branch_id,'branch_name',coalesce(b.name,'—'),
  'fee',c.base_fee_iqd,'percent',c.percent,'amount',c.amount_iqd,
  'earned_at',c.earned_at) ORDER BY c.earned_at DESC),'[]'::jsonb)
 INTO v_items
 FROM (SELECT * FROM public.barq_commission_earnings_v35
   WHERE (earned_at AT TIME ZONE 'Asia/Baghdad')::date>=p_month
     AND (earned_at AT TIME ZONE 'Asia/Baghdad')::date<(p_month+interval '1 month')::date
   ORDER BY earned_at DESC LIMIT 250) c
 JOIN public.drivers d ON d.id=c.driver_id
 LEFT JOIN public.profiles p ON p.id=d.user_id
 LEFT JOIN public.barq_branches b ON b.id=c.branch_id;
 RETURN jsonb_build_object('month',to_char(p_month,'YYYY-MM'),
   'rates',v_rates,'drivers',v_drivers,'items',v_items,
   'items_limit',250);
END;
$fn$;

-- Reconcile V34 branch financial result with authoritative V35 commissions.
-- Remove the old fixed delivery earning ONLY for orders with a V35 snapshot;
-- replace it with the sum of V35 pickup + final delivery commissions.
CREATE OR REPLACE FUNCTION public.barq_admin_financial_report_v35(p_month date)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $fn$
DECLARE v_report jsonb; v_branches jsonb;
BEGIN
 IF auth.uid() IS NULL OR NOT EXISTS
 (SELECT 1 FROM public.profiles WHERE id=auth.uid() AND role='admin')
 THEN RAISE EXCEPTION 'الإدارة العامة فقط' USING ERRCODE='42501'; END IF;
 v_report:=public.barq_admin_financial_report_v34(p_month);
 WITH old_comm AS (
  SELECT coalesce(o.destination_branch_id,
    (SELECT min(b.id) FROM public.barq_branches b
     WHERE b.governorate=o.delivery_governorate HAVING count(*)=1)) AS branch_id,
   sum(o.driver_earning_iqd)::bigint AS old_amount
  FROM public.orders o
  LEFT JOIN public.barq_last_mile_v28 lm ON lm.order_id=o.id
  WHERE o.status='delivered'
    AND date_trunc('month',(coalesce(lm.delivered_at,o.updated_at) AT TIME ZONE 'Asia/Baghdad'))::date=p_month
    AND o.collection_method IN ('full_cod','delivery_fee_only')
    AND o.driver_earning_iqd IS NOT NULL AND o.delivery_fee_iqd IS NOT NULL
    AND o.driver_earning_iqd BETWEEN 0 AND o.delivery_fee_iqd
    AND EXISTS(SELECT 1 FROM public.barq_commission_earnings_v35 c WHERE c.order_id=o.id)
  GROUP BY 1
 ), new_comm AS (
  SELECT c.branch_id,sum(c.amount_iqd)::bigint AS new_amount,
    count(*) FILTER (WHERE c.amount_iqd IS NULL)::int AS pending_count
  FROM public.barq_commission_earnings_v35 c
  WHERE date_trunc('month',(c.earned_at AT TIME ZONE 'Asia/Baghdad'))::date=p_month
  GROUP BY c.branch_id
 )
 SELECT coalesce(jsonb_agg(
  b || jsonb_build_object(
    'delivery_commissions',greatest(0,(b->>'delivery_commissions')::bigint-coalesce(oc.old_amount,0)+coalesce(nc.new_amount,0)),
    'commission_pending_count',coalesce(nc.pending_count,0),
    'estimated_operating_result',CASE WHEN coalesce(nc.pending_count,0)>0 THEN NULL
      ELSE (b->>'estimated_operating_result')::bigint+coalesce(oc.old_amount,0)-coalesce(nc.new_amount,0) END
  ) ORDER BY b->>'code'),'[]'::jsonb) INTO v_branches
 FROM jsonb_array_elements(v_report->'branches') b
 LEFT JOIN old_comm oc ON oc.branch_id IS NOT DISTINCT FROM nullif(b->>'branch_id','')::uuid
 LEFT JOIN new_comm nc ON nc.branch_id IS NOT DISTINCT FROM nullif(b->>'branch_id','')::uuid;
 RETURN jsonb_set(v_report,'{branches}',v_branches)
   || jsonb_build_object('v35_note','عمولات V35 من أجرة التوصيل. الحسابات ذات النسبة غير المحددة لا يظهر لها ربح نهائي.');
END;
$fn$;

REVOKE ALL ON FUNCTION public.barq_admin_set_rates_v35(uuid,uuid,numeric,numeric) FROM PUBLIC,anon,authenticated;
REVOKE ALL ON FUNCTION public.barq_admin_finalize_commission_v35(uuid) FROM PUBLIC,anon,authenticated;
REVOKE ALL ON FUNCTION public.barq_admin_commissions_v35(date) FROM PUBLIC,anon,authenticated;
REVOKE ALL ON FUNCTION public.barq_admin_financial_report_v35(date) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_set_rates_v35(uuid,uuid,numeric,numeric) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_finalize_commission_v35(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_commissions_v35(date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.barq_admin_financial_report_v35(date) TO authenticated;
COMMIT;

-- Read-only installation check (all TRUE):
SELECT
 to_regclass('public.barq_commission_rates_v35') IS NOT NULL AS rates_ready,
 to_regclass('public.barq_commission_earnings_v35') IS NOT NULL AS earnings_ready,
 to_regclass('public.barq_payroll_cancellations_v35') IS NOT NULL AS payroll_audit_ready,
 to_regprocedure('public.barq_admin_set_rates_v35(uuid,uuid,numeric,numeric)') IS NOT NULL AS setup_ready,
 to_regprocedure('public.barq_admin_commissions_v35(date)') IS NOT NULL AS summary_ready,
 to_regprocedure('public.barq_admin_finalize_commission_v35(uuid)') IS NOT NULL AS pending_ready,
 to_regprocedure('public.barq_admin_financial_report_v35(date)') IS NOT NULL AS finance_ready,
 EXISTS(SELECT 1 FROM pg_catalog.pg_trigger WHERE tgname='barq_v35_capture_delivered_trigger' AND NOT tgisinternal) AS capture_ready;

-- Optional read-only check of Yusuf's payroll reset:
SELECT p.full_name,pm.salary_month,pm.salary_amount_iqd,
  (SELECT coalesce(sum(x.amount_iqd),0) FROM public.barq_driver_salary_payments_v33 x WHERE x.payroll_id=pm.id) AS paid_iqd
FROM public.barq_driver_payroll_months_v33 pm
JOIN public.drivers d ON d.id=pm.driver_id JOIN public.profiles p ON p.id=d.user_id
JOIN public.barq_branches b ON b.id=pm.branch_id
WHERE p.full_name='يوسف' AND b.code='BGD' AND pm.salary_month=DATE '2026-11-01';
