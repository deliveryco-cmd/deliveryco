برق للتوصيل السريع — V21

المشكلة الحمراء: الدالة barq_admin_dispatch_intercity غير موجودة.
1. نفّذ ملف barq-v21-01-fix-dispatch.sql كاملاً في Supabase SQL Editor.
2. بعد ظهور dispatch_function_ready=true، ملف barq-v21-configure.html ينشئ ZIP كامل للنشر.
3. أدخل Project URL و Publishable key فقط (لا تستخدم Secret / service_role).
4. Cloudflare Pages > barq-delivery > Create deployment > ارفع ZIP الناتج.
5. أعد فتح تطبيق المدير والمحل والمندوب؛ إذا بقي الشعار القديم أغلق PWA بالكامل وافتحه.

لشحن المحافظات: أدخل اسم شركة البريد الحقيقية ورقم التتبع الممنوح لك من إيصال شركة البريد.
لا تدخل رقماً عشوائياً ولا تُسلّم الطرد بالبريد قبل تسليمه فعلياً.
تسليم البريد لا يعني تسليم الزبون أو قبض المبلغ.
