// BARQ V37 — create an Auth user and assign a branch manager from Admin UI.
// Requires a SIGNED-IN general admin. Deploy with Verify JWT ON.
// Secret keys stay ONLY in Supabase Edge Function environment.
import { createClient } from 'npm:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info, x-supabase-api-version, x-client-version',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Cache-Control': 'no-store',
};
const respond = (payload: Record<string, unknown>, status = 200) =>
  new Response(JSON.stringify(payload), {
    status, headers: { ...cors, 'Content-Type': 'application/json; charset=utf-8' },
  });
const validUUID = (s: string) => /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(s);
const phoneOK = (p: string) => !p || /^(07\d{9}|\+9647\d{9}|009647\d{9})$/.test(p);

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
  if (req.method !== 'POST') return respond({ ok: false, error: 'طريقة الطلب غير مدعومة.' }, 405);

  const url = Deno.env.get('SUPABASE_URL');
  let secret = '';
  let publicKey = '';
  try {
    secret = JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}')?.default || '';
    publicKey = JSON.parse(Deno.env.get('SUPABASE_PUBLISHABLE_KEYS') || '{}')?.default || '';
  } catch { /* Legacy keys below are still supported. */ }
  secret ||= Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
  publicKey ||= Deno.env.get('SUPABASE_ANON_KEY') || '';
  // The public key may also arrive from the already-configured Supabase browser client.
  publicKey ||= req.headers.get('apikey') || '';
  if (!url || !secret || !publicKey) return respond({ ok: false, error: 'مفاتيح خدمة Supabase غير مكتملة.' }, 503);

  const authHeader = req.headers.get('authorization') || '';
  const jwt = authHeader.match(/^Bearer\s+([^\s]+)$/i)?.[1];
  if (!jwt) return respond({ ok: false, error: 'يجب تسجيل الدخول كمدير عام أولاً.' }, 401);

  // Validate user JWT server-side; the browser cannot assign itself admin privileges.
  const service = createClient(url, secret, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  });
  const { data: identity, error: authErr } = await service.auth.getUser(jwt);
  if (authErr || !identity?.user?.id) return respond({ ok: false, error: 'جلسة الإدارة غير صالحة.' }, 401);
  const adminId = identity.user.id;
  const { data: profile, error: adminErr } = await service.from('profiles')
    .select('role').eq('id', adminId).maybeSingle();
  if (adminErr || profile?.role !== 'admin')
    return respond({ ok: false, error: 'هذه العملية للمدير العام فقط.' }, 403);

  let body: Record<string, unknown>;
  try { body = await req.json(); }
  catch { return respond({ ok: false, error: 'بيانات الطلب غير صحيحة.' }, 400); }
  const branchId = String(body?.branch_id ?? '').trim();
  const fullName = String(body?.full_name ?? '').trim();
  const email = String(body?.email ?? '').trim().toLowerCase();
  const phone = String(body?.phone ?? '').replace(/[\s-]/g, '');
  const password = body?.password;
  if (!validUUID(branchId)) return respond({ ok: false, error: 'اختر فرعاً صحيحاً.' }, 400);
  if (fullName.length < 2 || fullName.length > 120)
    return respond({ ok: false, error: 'اسم المدير يجب أن يكون من حرفين إلى 120 حرفاً.' }, 400);
  if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return respond({ ok: false, error: 'أدخل بريداً إلكترونياً صحيحاً.' }, 400);
  if (phone.length > 16 || !phoneOK(phone))
    return respond({ ok: false, error: 'رقم الهاتف غير صحيح. استخدم رقماً عراقياً بصيغة 07XXXXXXXXX.' }, 400);
  if (typeof password !== 'string' || password.length < 10 || password.length > 128)
    return respond({ ok: false, error: 'كلمة المرور يجب أن تكون من 10 إلى 128 حرفاً.' }, 400);

  const { data: branch, error: branchErr } = await service.from('barq_branches')
    .select('id,name,is_active').eq('id', branchId).maybeSingle();
  if (branchErr) return respond({ ok: false, error: 'تعذّر التحقق من الفرع.' }, 503);
  if (!branch?.id || branch.is_active !== true)
    return respond({ ok: false, error: 'هذا الفرع غير موجود أو غير فعّال.' }, 400);

  let createdId: string | null = null;
  try {
    // Admin SDK creates Auth account without signing out the current director.
    const { data: created, error: createErr } = await service.auth.admin.createUser({
      email, password, email_confirm: true,
      user_metadata: { full_name: fullName },
    });
    if (createErr || !created?.user?.id) {
      return respond({ ok: false, error: createErr?.message || 'تعذّر إنشاء حساب تسجيل الدخول.' }, 409);
    }
    createdId = created.user.id;

    // A profile trigger might have already created this row. Update it deterministically.
    const { error: profileErr } = await service.from('profiles').upsert({
      id: createdId, full_name: fullName, phone: phone || null, role: 'branch_manage',
    }, { onConflict: 'id' });
    if (profileErr) throw new Error('تعذّر حفظ ملف مدير الفرع: ' + profileErr.message);

    // Reuse existing V23 RPC to enforce authenticated admin, branch assignment,
    // audit (assigned_by), and the no-multi-branch rule.
    const userScoped = createClient(url, publicKey, {
      auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
      global: { headers: { Authorization: `Bearer ${jwt}` } },
    });
    const { error: assignErr } = await userScoped.rpc('barq_admin_set_branch_manager_v23', {
      p_branch_id: branchId, p_user_id: createdId, p_active: true,
    });
    if (assignErr) throw new Error('تعذّر ربط المدير بالفرع: ' + assignErr.message);
    return respond({ ok: true, user_id: createdId, branch_id: branchId, branch_name: branch.name }, 201);
  } catch (error) {
    // Compensating action; do not leave an Auth login without a branch assignment.
    if (createdId) {
      const { error: cleanupErr } = await service.auth.admin.deleteUser(createdId);
      if (cleanupErr) {
        return respond({ ok: false, error: 'تم إنشاء الحساب لكن تعذّر ربطه أو التراجع عنه. لا تعِد الإضافة. راجع الحساب بالمعرّف المعروض.', orphaned_account: true, user_id: createdId }, 500);
      }
    }
    return respond({ ok: false, error: error instanceof Error ? error.message : 'تعذّر إنشاء المدير.' }, 400);
  }
});
