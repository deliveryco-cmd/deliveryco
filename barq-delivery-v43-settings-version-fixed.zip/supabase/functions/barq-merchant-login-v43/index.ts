// BARQ V43 — merchant username / Iraqi phone + password sign-in.
// Deploy Verify JWT OFF: user is unauthenticated until this endpoint verifies the password.
// Secrets used server-side ONLY; never publish service role/secret key inside frontend files.
import {createClient} from 'npm:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-api-version, x-client-version',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Cache-Control': 'no-store',
};
const json=(body:Record<string,unknown>,status=200)=>
  new Response(JSON.stringify(body),{status,headers:{...cors,'Content-Type':'application/json; charset=utf-8'}});
function normalizePhone(input:string):string|null{
  const digits=input.replace(/\D/g,'');
  if(/^07\d{9}$/.test(digits))return '+964'+digits.slice(1);
  if(/^9647\d{9}$/.test(digits))return '+'+digits;
  if(/^009647\d{9}$/.test(digits))return '+'+digits.slice(2);
  return null;
}
async function sha(text:string){
  const raw=new TextEncoder().encode(text);
  return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',raw)))
    .map(n=>n.toString(16).padStart(2,'0')).join('');
}
Deno.serve(async(req:Request)=>{
  if(req.method==='OPTIONS')return new Response(null,{status:204,headers:cors});
  if(req.method!=='POST')return json({ok:false,error:'الطلب غير مسموح'},405);
  try{
    const url=Deno.env.get('SUPABASE_URL');
    const legacy=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    let modern='';try{modern=JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS')||'{}')?.default||'';}catch{}
    const secret=legacy||modern;
    if(!url||!secret)return json({ok:false,error:'إعدادات الدخول غير مكتملة'},503);

    const input=await req.json().catch(()=>null);
    const identifier=String(input?.identifier||'').trim().toLowerCase();
    const password=input?.password;
    if(identifier.length<4||identifier.length>254||typeof password!=='string'||password.length<1||password.length>256)
      return json({ok:false,error:'بيانات الدخول غير صحيحة'},401);
    if(identifier.includes('@'))return json({ok:false,error:'استخدم تسجيل الدخول بالبريد الإلكتروني'},400);
    const username=/^[a-z][a-z0-9_]{3,23}$/.test(identifier)?identifier:null;
    const phone=normalizePhone(identifier);
    if(!username&&!phone)return json({ok:false,error:'بيانات الدخول غير صحيحة'},401);

    const admin=createClient(url,secret,{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false}});
    const ip=(req.headers.get('cf-connecting-ip')||req.headers.get('x-forwarded-for')?.split(',')[0]||'unknown').slice(0,100);
    const fingerprints=[await sha('v43-merch-ip:'+ip),await sha('v43-merch-pair:'+ip+':'+identifier)];
    for(const [i,fingerprint] of fingerprints.entries()){
      const {data,error}=await admin.rpc('barq_v36_login_rate_limit',{p_fingerprint:fingerprint,p_limit:i===0?80:8});
      if(error)return json({ok:false,error:'تعذر فحص طلب الدخول حالياً'},503);
      if(!data)return json({ok:false,error:'محاولات كثيرة؛ حاول بعد 15 دقيقة'},429);
    }
    const query=admin.from('barq_merchant_login_aliases_v43').select('user_id');
    const {data:alias,error:aliasErr}=username
      ?await query.eq('username',username).maybeSingle()
      :await query.eq('phone_e164',phone).maybeSingle();
    if(aliasErr||!alias?.user_id)return json({ok:false,error:'بيانات الدخول غير صحيحة'},401);

    const [{data:profile,error:profileErr},{data:shops,error:shopsErr}]=await Promise.all([
      admin.from('profiles').select('role').eq('id',alias.user_id).maybeSingle(),
      admin.from('merchants').select('id').eq('owner_id',alias.user_id).eq('is_active',true).limit(1),
    ]);
    if(profileErr||shopsErr||profile?.role!=='merchant'||!shops?.length)
      return json({ok:false,error:'بيانات الدخول غير صحيحة'},401);

    const {data:account,error:userErr}=await admin.auth.admin.getUserById(alias.user_id);
    const email=account?.user?.email;
    if(userErr||!email)return json({ok:false,error:'بيانات الدخول غير صحيحة'},401);
    const {data:auth,error:authErr}=await admin.auth.signInWithPassword({email,password});
    if(authErr||!auth?.session||auth?.user?.id!==alias.user_id)
      return json({ok:false,error:'بيانات الدخول غير صحيحة'},401);
    return json({ok:true,access_token:auth.session.access_token,refresh_token:auth.session.refresh_token});
  }catch{
    return json({ok:false,error:'تعذر تسجيل الدخول حالياً'},500);
  }
});
