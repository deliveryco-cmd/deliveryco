// BARQ V36 — authenticated driver password sign-in using private username/phone aliases.
// Deploy as a Supabase Edge Function with "Verify JWT" OFF (login is unauthenticated).
// A service-role key is read ONLY from Supabase's secure server environment.
import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-api-version, x-client-version',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Cache-Control': 'no-store',
};
const json = (body: Record<string, unknown>, status=200) =>
  new Response(JSON.stringify(body), { status, headers: {...corsHeaders, 'Content-Type':'application/json; charset=utf-8'} });

function normalizePhone(input: string): string | null {
  const digits = input.replace(/\D/g,'');
  if (/^07\d{9}$/.test(digits)) return '+964'+digits.slice(1);
  if (/^9647\d{9}$/.test(digits)) return '+'+digits;
  if (/^009647\d{9}$/.test(digits)) return '+'+digits.slice(2);
  return null;
}
async function sha(value: string) {
  const bytes = new TextEncoder().encode(value);
  return [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))]
    .map(n=>n.toString(16).padStart(2,'0')).join('');
}

Deno.serve(async (req: Request) => {
  if(req.method==='OPTIONS') return new Response(null,{status:204,headers:corsHeaders});
  if(req.method!=='POST') return json({ok:false,error:'طريقة الطلب غير مدعومة'},405);
  try {
    const url=Deno.env.get('SUPABASE_URL');
    const legacySecret=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    let modernSecret='';
    try{modernSecret=JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS')||'{}')?.default||'';}catch{}
    const secret=legacySecret||modernSecret;
    if(!url||!secret) return json({ok:false,error:'إعدادات الخدمة غير مكتملة'},503);
    const payload=await req.json().catch(()=>null);
    const identifier=String(payload?.identifier??'').trim().toLowerCase();
    const password=payload?.password;
    if(identifier.length<4||identifier.length>254||typeof password!=='string'||password.length<1||password.length>256)
      return json({ok:false,error:'اسم الدخول أو كلمة المرور غير صحيحة'},401);
    // Email users continue to use native Supabase auth in the browser; this
    // endpoint accepts ONLY driver username or phone, never resolves an email publicly.
    if(identifier.includes('@')) return json({ok:false,error:'استخدم تسجيل الدخول بالبريد الإلكتروني'},400);
    const username=/^[a-z][a-z0-9_]{3,23}$/.test(identifier)?identifier:null;
    const phone=normalizePhone(identifier);
    if(!username && !phone) return json({ok:false,error:'اسم الدخول أو كلمة المرور غير صحيحة'},401);
    const admin=createClient(url,secret,{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false}});

    // Best-effort per-IP and per-identifier limiting (15-min server-side counters).
    const ip=(req.headers.get('cf-connecting-ip') || req.headers.get('x-forwarded-for')?.split(',')[0] || 'unknown').slice(0,100);
    const [ipKey,pairKey]=await Promise.all([sha('barq36-ip:'+ip),sha('barq36-pair:'+ip+':'+identifier)]);
    for (const [fingerprint,limit] of [[ipKey,80],[pairKey,8]] as const) {
      const {data,error}=await admin.rpc('barq_v36_login_rate_limit',{p_fingerprint:fingerprint,p_limit:limit});
      if(error) return json({ok:false,error:'تعذر التحقق من المحاولات، حاول لاحقاً'},503);
      if(!data) return json({ok:false,error:'محاولات كثيرة. حاول بعد 15 دقيقة'},429);
    }
    const q=admin.from('barq_driver_login_aliases_v36').select('user_id');
    const {data:alias,error:aliasError}=username
      ?await q.eq('username',username).maybeSingle()
      :await q.eq('phone_e164',phone!).maybeSingle();
    if(aliasError||!alias?.user_id) return json({ok:false,error:'اسم الدخول أو كلمة المرور غير صحيحة'},401);
    const [{data:profile,error:profileError},{data:driver,error:driverError}]=await Promise.all([
      admin.from('profiles').select('role').eq('id',alias.user_id).maybeSingle(),
      admin.from('drivers').select('is_active').eq('user_id',alias.user_id).maybeSingle(),
    ]);
    if(profileError||driverError||profile?.role!=='driver'||driver?.is_active!==true)
      return json({ok:false,error:'اسم الدخول أو كلمة المرور غير صحيحة'},401);
    const {data:userResult,error:userError}=await admin.auth.admin.getUserById(alias.user_id);
    const email=userResult?.user?.email;
    if(userError||!email) return json({ok:false,error:'اسم الدخول أو كلمة المرور غير صحيحة'},401);
    const {data:authResult,error:authError}=await admin.auth.signInWithPassword({email,password});
    if(authError||!authResult.session) return json({ok:false,error:'اسم الدخول أو كلمة المرور غير صحيحة'},401);
    return json({ok:true,access_token:authResult.session.access_token,refresh_token:authResult.session.refresh_token});
  } catch {
    return json({ok:false,error:'تعذر تسجيل الدخول حالياً'},500);
  }
});
